#!/usr/bin/env bash
# AFK-Dashboard direkt auf diesem Rechner starten - ohne Docker.
#
#   ./run-local.sh build     # einmalig: Server + Frontend bauen
#   ./run-local.sh start     # im Hintergrund starten
#   ./run-local.sh stop
#   ./run-local.sh restart
#   ./run-local.sh logs      # Logverlauf mitverfolgen
#   ./run-local.sh status    # laeuft es?
#   ./run-local.sh password  # erstes Login-Passwort anzeigen
#
# Java-Accounts brauchen ein JDK 21 auf dem PATH. Ohne JDK starten
# ZenithProxy-Instanzen nicht; das Dashboard selbst laeuft auch ohne.

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
RUN_DIR="$ROOT/.run"
PID_FILE="$RUN_DIR/server.pid"
LOG_FILE="$RUN_DIR/server.log"
ENV_FILE="$ROOT/.env"

# Fuer ZenithProxy: ein JDK 21 auf dem PATH. Entweder global installiert
#   (sudo pacman -S jre21-openjdk-headless)
# oder in .env eintragen:
#   JAVA_HOME_DIR=/home/DEIN-NAME/.jdks/jdk-21
# Ohne JDK starten ZenithProxy-Instanzen nicht; das Dashboard selbst laeuft
# auch ohne.

log()  { printf '\033[36m==>\033[0m %s\n' "$*"; }
fail() { printf '\033[31mFehler:\033[0m %s\n' "$*" >&2; exit 1; }

ensure_env() {
  [[ -f "$ENV_FILE" ]] || { cp "$ROOT/.env.example" "$ENV_FILE"
    log ".env aus .env.example erzeugt"; }
  if grep -q '^ENCRYPTION_KEY=$' "$ENV_FILE"; then
    local key; key="$(openssl rand -hex 32)"
    sed -i "s/^ENCRYPTION_KEY=\$/ENCRYPTION_KEY=$key/" "$ENV_FILE"
    log "ENCRYPTION_KEY erzeugt"
  fi
}

# Alles exportieren, was in .env steht (Kommentare und Leerzeilen ignorieren).
load_env() {
  local line key value
  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ "$line" =~ ^[[:space:]]*# ]] && continue
    [[ "$line" =~ ^[[:space:]]*$ ]] && continue
    key="${line%%=*}"
    value="${line#*=}"
    value="${value%\"}"; value="${value#\"}"
    value="${value%\'}"; value="${value#\'}"
    export "$key=$value"
  done < "$ENV_FILE"
  # JAVA_HOME_DIR kommt gegebenenfalls aus .env, ist also erst jetzt gesetzt.
  if [[ -n "${JAVA_HOME_DIR:-}" && -d "${JAVA_HOME_DIR}/bin" ]]; then
    export PATH="$JAVA_HOME_DIR/bin:$PATH"
  fi
  return 0
}

is_running() {
  [[ -f "$PID_FILE" ]] || return 1
  local pid; pid="$(cat "$PID_FILE")"
  [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null
}

do_build() {
  log "baue Backend"
  (cd "$ROOT/server" && pnpm install --frozen-lockfile && pnpm run build)
  log "baue Frontend"
  (cd "$ROOT/web" && pnpm install --frozen-lockfile && pnpm run build)
  log "fertig"
}

do_start() {
  is_running && fail "laeuft bereits (PID $(cat "$PID_FILE")) - erst ./run-local.sh stop"
  [[ -f "$ROOT/server/dist/index.js" ]] || fail "nicht gebaut - erst ./run-local.sh build"
  mkdir -p "$RUN_DIR"
  ensure_env
  load_env
  # --env-file haengt daran, was load_env schon exportiert hat; wir nutzen die
  # geladene Umgebung direkt, damit lokale Overrides in .env greifen.
  nohup node --enable-source-maps "$ROOT/server/dist/index.js" \
    >>"$LOG_FILE" 2>&1 &
  echo $! >"$PID_FILE"
  sleep 2
  if is_running; then
    log "laeuft (PID $(cat "$PID_FILE")) auf http://${DASHBOARD_HOST:-0.0.0.0}:${DASHBOARD_PORT:-3000}"
    grep -qa 'ERSTER START' "$LOG_FILE" \
      && do_password \
      || log "kein Erstpasswort (Nutzer existiert schon) - ggf. ./run-local.sh password"
  else
    fail "Start fehlgeschlagen - letzte Zeilen aus $LOG_FILE:"
  fi
}

do_stop() {
  is_running || { log "laeuft nicht"; rm -f "$PID_FILE"; return 0; }
  local pid; pid="$(cat "$PID_FILE")"
  log "stoppe PID $pid"
  kill "$pid" 2>/dev/null || true
  for _ in $(seq 1 20); do is_running || break; sleep 0.5; done
  is_running && { log "SIGKILL"; kill -9 "$pid" 2>/dev/null || true; }
  rm -f "$PID_FILE"
  log "gestoppt"
}

do_password() {
  grep -a -A4 'ERSTER START' "$LOG_FILE" 2>/dev/null \
    || fail "im Log steht kein Erstpasswort - wurde der Nutzer schon angelegt?"
}

case "${1:-start}" in
  build)   ensure_env; do_build ;;
  start)   do_start ;;
  stop)    do_stop ;;
  restart) do_stop; do_start ;;
  logs)    touch "$LOG_FILE"; tail -f "$LOG_FILE" ;;
  status)  is_running && log "laeuft (PID $(cat "$PID_FILE"))" || log "gestoppt" ;;
  password) do_password ;;
  *)       sed -n '2,20p' "${BASH_SOURCE[0]}"; exit 1 ;;
esac
