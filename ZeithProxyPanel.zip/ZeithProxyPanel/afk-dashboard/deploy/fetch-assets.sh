#!/usr/bin/env bash
#
# Laedt die beiden Artefakte, die das Dashboard zur Laufzeit braucht, in ./seed:
#   launcher.zip   - ZenithProxy-Launcher (offizielles Release)
#   web-api.jar    - WebAPI-Plugin (neuestes Release)
#
# Zweck: der Container muss nicht bei jedem frischen Start GitHub erreichen.
# Einmal ausfuehren, seed/ mit ins Deployment nehmen, Image bauen - fertig.
#
# Aufruf:  ./deploy/fetch-assets.sh
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SEED="$HERE/seed"
mkdir -p "$SEED"

LAUNCHER_URL="https://github.com/rfresh2/ZenithProxy/releases/download/launcher-v3/ZenithProxy-launcher-linux-amd64.zip"
PLUGIN_REPO="rfresh2/ZenithProxyWebAPI"

if [ -f "$SEED/launcher.zip" ]; then
  echo "launcher.zip vorhanden - uebersprungen"
else
  echo "-> Lade ZenithProxy-Launcher"
  curl -fL --progress-bar -o "$SEED/launcher.zip" "$LAUNCHER_URL"
fi

# Neuestes Release des Plugins ueber die GitHub-API ermitteln, damit keine
# Version im Skript feststeht und veralten kann.
if [ -f "$SEED/web-api.jar" ]; then
  echo "web-api.jar vorhanden - uebersprungen"
else
  echo "-> Ermittle neuestes WebAPI-Plugin-Release"
  URL=$(curl -fsSL "https://api.github.com/repos/$PLUGIN_REPO/releases/latest" \
    | python3 -c "import json,sys; r=json.load(sys.stdin); print(next(a['browser_download_url'] for a in r['assets'] if a['name'].endswith('.jar')))")
  echo "   $URL"
  curl -fL --progress-bar -o "$SEED/web-api.jar" "$URL"
fi

echo
echo "Fertig. Inhalt von seed/:"
ls -lh "$SEED"
echo
echo "Nicht vergessen: seed/ ist in .gitignore - die Dateien sollen nicht ins Repo."
