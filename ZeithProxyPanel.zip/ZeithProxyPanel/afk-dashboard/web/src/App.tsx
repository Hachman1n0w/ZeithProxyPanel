import { lazy, Suspense, useCallback, useEffect, useMemo, useState } from 'react';
import { api, subscribeAccounts } from './lib/api';
import type { Account, Edition, Ports } from './lib/types';
import Login from './components/Login';
import AccountCard from './components/AccountCard';
import NewAccountDialog from './components/NewAccountDialog';
import ConfirmDelete from './components/ConfirmDelete';

/**
 * Der Detail-Dialog zieht die Diagramme mit, und die wiegen ~450 kB. Sie
 * werden erst gebraucht, wenn jemand einen Account oeffnet - deshalb werden
 * sie erst dann nachgeladen. Das haelt den ersten Aufruf klein.
 */
const AccountModal = lazy(() => import('./components/AccountModal'));

export default function App() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [ports, setPorts] = useState<Ports | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | Edition>('all');

  // Erste Prüfung, ob eine Session existiert.
  useEffect(() => {
    api
      .me()
      .then(() => setAuthed(true))
      .catch(() => setAuthed(false));
  }, []);

  const refresh = useCallback(async (): Promise<void> => {
    try {
      const { accounts: list, ports: p } = await api.accounts();
      setAccounts(list);
      setPorts(p);
    } catch (err) {
      // 401 bedeutet: Session abgelaufen -> zurück zum Login.
      if ((err as { status?: number }).status === 401) setAuthed(false);
    }
  }, []);

  useEffect(() => {
    if (!authed) return;
    void refresh();
    // Live-Feed. Beim Anmelden wird neu verbunden, beim Abmelden beendet.
    const unsubscribe = subscribeAccounts(setAccounts);
    return unsubscribe;
  }, [authed, refresh]);

  const act = async (id: string, fn: () => Promise<unknown>): Promise<void> => {
    setBusyId(id);
    setError(null);
    try {
      await fn();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusyId(null);
    }
  };

  /**
   * Account loeschen. Der Bestaetigungsdialog steht in deleteId, hier laeuft
   * nur die tatsaechliche Aktion.
   *
   * Wichtig: das Geloeschte wird sofort lokal aus der Liste entfernt und der
   * Live-Feed nicht abgewartet. Der SSE-Push traegt die Loeschung zwar mit,
   * aber wenn er ausbleibt, wuerde die Karte sonst bis zum naechsten Reload
   * weiter dastehen - und der Nutzer haelt sie fuer noch existent.
   */
  const confirmDelete = async (id: string): Promise<void> => {
    const label = accounts.find((a) => a.id === id)?.label;
    setDeleteId(null);
    setBusyId(id);
    setError(null);
    // Optimistisch entfernen, damit die Karte sofort verschwindet.
    setAccounts((prev) => prev.filter((a) => a.id !== id));
    setOpenId((cur) => (cur === id ? null : cur));
    try {
      await api.deleteAccount(id);
    } catch (err) {
      setError(
        `${label ?? 'Account'} konnte nicht gelöscht werden: ${(err as Error).message}`,
      );
      // Liste wieder aus dem Server holen, damit der Zustand nicht schief bleibt.
      void refresh();
    } finally {
      setBusyId(null);
    }
  };

  const logout = async (): Promise<void> => {
    await api.logout().catch(() => {});
    setAuthed(false);
    setAccounts([]);
  };

  const visible = useMemo(
    () => (filter === 'all' ? accounts : accounts.filter((a) => a.edition === filter)),
    [accounts, filter],
  );

  const counts = useMemo(
    () => ({
      total: accounts.length,
      online: accounts.filter((a) => a.status.state === 'online').length,
      queued: accounts.filter((a) => a.status.state === 'queued').length,
      problems: accounts.filter((a) => a.status.state === 'error' || Boolean(a.status.lastError))
        .length,
    }),
    [accounts],
  );

  if (authed === null) {
    return <div className="flex min-h-full items-center justify-center text-slate-600">Lade…</div>;
  }

  if (!authed) {
    return <Login onDone={() => setAuthed(true)} />;
  }

  return (
    <div className="min-h-full">
      <header className="sticky top-0 z-40 border-b border-base-750 bg-base-900/85 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-4 px-5 py-3.5">
          <h1 className="text-base font-semibold text-slate-100">AFK-Dashboard</h1>

          <div className="flex items-center gap-3 text-xs text-slate-500">
            <Stat value={`${counts.online}/${counts.total}`} label="online" good={counts.online > 0} />
            {counts.queued > 0 && <Stat value={String(counts.queued)} label="in Queue" />}
            {counts.problems > 0 && (
              <Stat value={String(counts.problems)} label="mit Problem" bad />
            )}
          </div>

          <div className="ml-auto flex items-center gap-2">
            <FilterButton active={filter === 'all'} onClick={() => setFilter('all')}>
              Alle
            </FilterButton>
            <FilterButton active={filter === 'java'} onClick={() => setFilter('java')}>
              Java
            </FilterButton>
            <FilterButton active={filter === 'bedrock'} onClick={() => setFilter('bedrock')}>
              Bedrock
            </FilterButton>

            <button className="btn-primary btn-sm ml-2" onClick={() => setShowNew(true)}>
              + Account
            </button>
            <button className="btn-ghost btn-sm" onClick={() => void logout()}>
              Abmelden
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-5 py-6">
        {error && (
          <p className="mb-4 rounded-lg border border-rose-800 bg-rose-950/40 px-4 py-2.5 text-sm text-rose-300">
            {error}
          </p>
        )}

        {ports && (
          <p className="mb-5 text-xs text-slate-600">
            Java-Ports: {ports.mc.used}/{ports.mc.total} belegt · Web-API: {ports.api.used}/
            {ports.api.total} belegt
          </p>
        )}

        {visible.length === 0 ? (
          <EmptyState onAdd={() => setShowNew(true)} filtered={filter !== 'all'} />
        ) : (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {visible.map((a) => (
              <AccountCard
                key={a.id}
                account={a}
                busy={busyId === a.id}
                onStart={() => void act(a.id, () => api.start(a.id))}
                onStop={() => void act(a.id, () => api.stop(a.id))}
                onRestart={() => void act(a.id, () => api.restart(a.id))}
                onOpen={() => setOpenId(a.id)}
                onDelete={() => setDeleteId(a.id)}
              />
            ))}
          </div>
        )}
      </main>

      {openId && (
        <Suspense
          fallback={
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 text-sm text-slate-500 backdrop-blur-sm">
              Lade Details…
            </div>
          }
        >
          <AccountModal id={openId} onClose={() => setOpenId(null)} />
        </Suspense>
      )}
      {showNew && (
        <NewAccountDialog
          onClose={() => setShowNew(false)}
          onCreated={() => {
            setShowNew(false);
            void refresh();
          }}
        />
      )}
      {deleteId &&
        (() => {
          // Aus der Liste lesen, nicht aus einer zweiten Anfrage: bis der
          // Dialog bestaetigt wird, ist die Karte noch da.
          const target = accounts.find((a) => a.id === deleteId);
          if (!target) return null;
          const running = target.status.state !== 'stopped' && target.status.state !== 'error';
          return (
            <ConfirmDelete
              label={target.label}
              edition={target.edition}
              running={running}
              onCancel={() => setDeleteId(null)}
              onConfirm={() => void confirmDelete(deleteId)}
            />
          );
        })()}
    </div>
  );
}

function Stat({
  value,
  label,
  good,
  bad,
}: {
  value: string;
  label: string;
  good?: boolean;
  bad?: boolean;
}) {
  const color = bad ? 'text-rose-400' : good ? 'text-emerald-400' : 'text-slate-400';
  return (
    <span>
      <span className={`font-mono font-medium ${color}`}>{value}</span>{' '}
      <span className="text-slate-600">{label}</span>
    </span>
  );
}

function FilterButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-lg px-2.5 py-1 text-xs font-medium transition-colors ${
        active ? 'bg-base-750 text-slate-200' : 'text-slate-500 hover:text-slate-300'
      }`}
    >
      {children}
    </button>
  );
}

function EmptyState({ onAdd, filtered }: { onAdd: () => void; filtered: boolean }) {
  return (
    <div className="card flex flex-col items-center justify-center px-6 py-20 text-center">
      <h2 className="mb-2 text-base font-medium text-slate-300">
        {filtered ? 'Keine Accounts dieser Art' : 'Noch keine Accounts'}
      </h2>
      <p className="mb-6 max-w-md text-sm text-slate-500">
        {filtered
          ? 'Wechsle den Filter oder lege ein Account der anderen Art an.'
          : 'Lege deinen ersten Account an. Für Java startet eine ZenithProxy-Instanz, für Bedrock verbindet sich ein Bot direkt über das RakNet-Protokoll.'}
      </p>
      {!filtered && (
        <button className="btn-primary" onClick={onAdd}>
          + Account anlegen
        </button>
      )}
    </div>
  );
}
