import type {
  AccessLevel,
  AccessLists,
  Account,
  AccountDetail,
  AuthState,
  AuthType,
  CommandResult,
  Edition,
  ModuleState,
  PlayersInfo,
  Ports,
  StatusSample,
} from './types';

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  // Content-Type nur setzen, wenn es wirklich einen Body gibt. Fastify lehnt
  // einen POST mit application/json und leerem Body ab ("Body cannot be empty
  // when content-type is set to 'application/json'") - das trifft alle
  // Aktions-Buttons wie Start, Stop, Neustart und Abmelden, die keinen Body
  // mitsenden.
  const hasBody = init?.body !== undefined && init.body !== null;
  const res = await fetch(path, {
    credentials: 'same-origin',
    ...init,
    headers: {
      ...(hasBody ? { 'Content-Type': 'application/json' } : {}),
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) {
    let message = `HTTP ${res.status}`;
    try {
      const body = (await res.json()) as { error?: string };
      if (body?.error) message = body.error;
    } catch {
      /* Antwort war kein JSON */
    }
    throw new ApiError(message, res.status);
  }
  return (await res.json()) as T;
}

export const api = {
  login: (username: string, password: string) =>
    request<{ ok: boolean }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
    }),

  logout: () => request<{ ok: boolean }>('/api/auth/logout', { method: 'POST' }),

  me: () => request<{ ok: boolean }>('/api/auth/me'),

  accounts: () => request<{ accounts: Account[]; ports: Ports }>('/api/accounts'),

  detail: (id: string) => request<AccountDetail>(`/api/accounts/${id}`),

  createAccount: (body: {
    label: string;
    edition: Edition;
    username: string;
    serverHost?: string;
    serverPort?: number;
    /** Nur Java. */
    authType?: AuthType;
    /** Nur Java mit authType "prism". */
    password?: string;
  }) => request<{ account: Account }>('/api/accounts', { method: 'POST', body: JSON.stringify(body) }),

  deleteAccount: (id: string) =>
    request<{ ok: boolean }>(`/api/accounts/${id}`, { method: 'DELETE' }),

  start: (id: string) => request<{ ok: boolean }>(`/api/accounts/${id}/start`, { method: 'POST' }),

  stop: (id: string) => request<{ ok: boolean }>(`/api/accounts/${id}/stop`, { method: 'POST' }),

  restart: (id: string) => request<{ ok: boolean }>(`/api/accounts/${id}/restart`, { method: 'POST' }),

  setEnabled: (id: string, enabled: boolean) =>
    request<{ ok: boolean }>(`/api/accounts/${id}/enabled`, {
      method: 'POST',
      body: JSON.stringify({ enabled }),
    }),

  command: (id: string, command: string) =>
    request<CommandResult>(`/api/accounts/${id}/command`, {
      method: 'POST',
      body: JSON.stringify({ command }),
    }),

  auth: (id: string) => request<{ auth: AuthState }>(`/api/accounts/${id}/auth`),

  reauth: (id: string) =>
    request<{ ok: boolean; auth: AuthState }>(`/api/accounts/${id}/reauth`, { method: 'POST' }),

  history: (id: string, hours = 24) =>
    request<{ history: StatusSample[] }>(`/api/accounts/${id}/history?hours=${hours}`),

  players: (id: string) => request<PlayersInfo>(`/api/accounts/${id}/players`),

  access: (id: string) => request<AccessLists>(`/api/accounts/${id}/access`),

  setAccess: (id: string, player: string, level: AccessLevel) =>
    request<{ ok: boolean }>(`/api/accounts/${id}/access`, {
      method: 'POST',
      body: JSON.stringify({ player, level }),
    }),

  modules: (id: string) => request<{ modules: ModuleState[] }>(`/api/accounts/${id}/modules`),

  setModule: (id: string, module: string, enabled: boolean) =>
    request<{ ok: boolean }>(`/api/accounts/${id}/modules/${module}`, {
      method: 'POST',
      body: JSON.stringify({ enabled }),
    }),
};

/**
 * Live-Feed per Server-Sent-Events. Liefert eine Abmeldefunktion, damit React
 * sauber aufraeumen kann - sonst laeuft der alte Stream beim Rendern weiter.
 *
 * Wichtig: EventSource kann keine Header setzen und haengt deshalb an einem
 * Session-Cookie. Wir kennen den Cookie-Wert nicht (httpOnly), also schickt der
 * Browser ihn nur dann mit, wenn dieselbe Origin verwendet wird - was hier der
 * Fall ist, weil Frontend und API aus demselben Container kommen.
 *
 * Zusaetzlich wird `?token=` unterstuetzt, falls das Dashboard doch mal hinter
 * einer anderen Origin laeuft.
 */
export function subscribeAccounts(onAccounts: (accounts: Account[]) => void): () => void {
  const source = new EventSource('/api/events', { withCredentials: true });
  source.onmessage = (event) => {
    try {
      onAccounts(JSON.parse(event.data) as Account[]);
    } catch {
      /* kaputter Frame - ueberspringen */
    }
  };
  return () => source.close();
}
