/** Spiegelt die Typen aus server/src/types.ts. */

export type Edition = 'java' | 'bedrock';

/** Anmeldeweg fuer Java-Instanzen. */
export type AuthType = 'deviceCode' | 'prism';

export type AccountState =
  | 'stopped'
  | 'starting'
  | 'connecting'
  | 'queued'
  | 'online'
  | 'error';

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface QueueInfo {
  priority: number | null;
  regular: number | null;
  position: number | null;
  estimatedWaitSec: number | null;
}

export interface AccountStatus {
  state: AccountState;
  connectedPlayer: string | null;
  /**
   * Nur Java: Adresse, auf der der Proxy lauscht, so wie ZenithProxy sie selbst
   * meldet. Nicht die konfigurierte Portnummer, sondern der tatsaechlich
   * belegte - das ist die, die man zum Verbinden braucht.
   */
  proxyIp: string | null;
  /**
   * Nur Java: Spieler in Sichtweite des Bots. count ist die Anzahl, names die
   * ersten paar Namen für die Kartenansicht. null = keine Daten (gestoppt,
   * Bedrock, oder Web-API antwortet nicht).
   */
  nearby: { count: number; names: string[] } | null;
  ping: number | null;
  health: number | null;
  position: Vec3 | null;
  dimension: string | null;
  queue: QueueInfo | null;
  playtimeSec: number | null;
  source: 'webapi' | 'logtail' | 'bedrock' | 'process' | 'none';
  /**
   * Nur Java: Anmeldelink von ZenithProxy, solange die Anmeldung offen ist.
   * Steht direkt auf der Karte, nicht nur in der Detailansicht - wer auf
   * Starten drueckt und sonst nichts klickt, muss ihn trotzdem sehen.
   */
  authUrl: string | null;
  lastError: string | null;
  updatedAt: number;
}

export interface Account {
  id: string;
  label: string;
  edition: Edition;
  /** Java: Microsoft-E-Mail. Bedrock: Gamertag. */
  username: string;
  serverHost: string;
  serverPort: number;
  enabled: boolean;
  autoReconnect: boolean;
  mcPort: number | null;
  webapiPort: number | null;
  /** Nur Java: wie ZenithProxy sich anmeldet. */
  authType?: AuthType;
  createdAt: number;
  status: AccountStatus;
  pid: number | null;
  uptimeSec: number | null;
  bedrockAuthed: boolean;
}

export interface Ports {
  mc: { used: number; total: number; free: number[] };
  api: { used: number; total: number; free: number[] };
}

export interface DeviceCode {
  userCode: string;
  verificationUri: string;
  verificationUriComplete: string | null;
  expiresAt: number;
}

export interface AuthState {
  status: 'unknown' | 'waiting' | 'ready' | 'failed';
  deviceCode: DeviceCode | null;
  error: string | null;
  profileName: string | null;
}

export interface StatusSample {
  ts: number;
  online: boolean;
  ping: number | null;
  health: number | null;
  queuePosition: number | null;
  playtimeSec: number | null;
}

export type AccessLevel = 'full' | 'watch' | 'blocked' | 'none';

export interface AccessLists {
  /** Vollzugriff: steuern + zusehen. */
  whitelist: string[];
  /** Nur zusehen. */
  spectator: string[];
  /**
   * Blockierte Spieler. Immer leer: die Blacklist hat keinen list-Befehl,
   * sie ist nur schreibbar (blockieren/entblocken geht, anzeigen nicht).
   */
  blacklist: string[];
  /** true, wenn ZenithProxy die Zuschauer-Liste verweigert (Not Authorized). */
  spectatorBlocked: boolean;
  /** Immer false - siehe blacklist. */
  blacklistReadable: boolean;
}

export interface PlayersInfo {
  nearby: string[];
  server: string[];
  truncated: boolean;
}

export interface ModuleState {
  id: string;
  /** null = Zustand unbekannt (Antwort unverständlich oder Befehl scheiterte). */
  enabled: boolean | null;
}

export interface AccountDetail {
  account: Account;
  auth: AuthState;
  log: string[];
  bedrockAuthed: boolean;
  ticks: { ticks: number; lastError: string | null } | null;
}

export interface CommandResult {
  ok: boolean;
  output: string;
  error?: string;
}
