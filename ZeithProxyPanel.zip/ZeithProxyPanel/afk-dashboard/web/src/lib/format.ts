import type { AccountState } from './types';

/** Sekunden als "3h 12m" - kompakt, aber lesbar. */
export function formatDuration(totalSec: number | null | undefined): string {
  if (totalSec === null || totalSec === undefined || !Number.isFinite(totalSec)) return '—';
  const s = Math.max(0, Math.floor(totalSec));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const rest = s % 60;
  if (d > 0) return `${d}d ${h}h`;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${rest}s`;
  return `${rest}s`;
}

export function formatPing(ms: number | null | undefined): string {
  if (ms === null || ms === undefined || !Number.isFinite(ms)) return '—';
  return `${Math.round(ms)} ms`;
}

export function formatCoords(p: { x: number; y: number; z: number } | null): string {
  if (!p) return '—';
  const f = (n: number): string => Math.round(n).toLocaleString('de-DE');
  return `${f(p.x)} / ${f(p.y)} / ${f(p.z)}`;
}

export const STATE_LABEL: Record<AccountState, string> = {
  stopped: 'Gestoppt',
  starting: 'Startet',
  connecting: 'Verbinde',
  queued: 'In der Queue',
  online: 'Online',
  error: 'Fehler',
};

export const STATE_STYLE: Record<AccountState, string> = {
  stopped: 'bg-slate-700/40 text-slate-400',
  starting: 'bg-sky-900/60 text-sky-300',
  connecting: 'bg-amber-900/50 text-amber-300',
  queued: 'bg-violet-900/50 text-violet-300',
  online: 'bg-emerald-900/60 text-emerald-300',
  error: 'bg-rose-900/60 text-rose-300',
};

export const DOT_STYLE: Record<AccountState, string> = {
  stopped: 'bg-slate-500',
  starting: 'bg-sky-400',
  connecting: 'bg-amber-400',
  queued: 'bg-violet-400',
  online: 'bg-emerald-400',
  error: 'bg-rose-400',
};

/**
 * Herkunft der Daten kennzeichnen. Ein aus dem Log geratener Status sieht
 * sonst genauso aus wie einer aus der Web-API - und das ist ein Unterschied,
 * der wichtig ist, wenn man sich auf eine Zahl verlässt.
 */
export const SOURCE_LABEL: Record<string, string> = {
  webapi: 'Web-API',
  logtail: 'aus Log geschätzt',
  bedrock: 'Bedrock-Protokoll',
  process: 'Prozess',
  none: 'keine Daten',
};

export function formatTime(ts: number): string {
  return new Date(ts).toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
}
