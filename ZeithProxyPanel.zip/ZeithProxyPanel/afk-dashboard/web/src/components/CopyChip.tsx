import { useEffect, useRef, useState } from 'react';

/**
 * Ein Wert, den man mit einem Klick kopiert.
 *
 * Bewusst als Tap und nicht als ausgegrautes Textfeld: die Adresse ist etwas,
 * das man in einen Minecraft-Server-Eintrag oder einen playit-Dialog
 * einfuegen will, und da ist Kopieren der Normalfall, Tippen die Ausnahme.
 * Fuer Screenreader bleibt der Wert echter Text, nicht nur ein Icon.
 */
export default function CopyChip({
  value,
  label,
  title,
  className = '',
}: {
  value: string;
  label?: string;
  title?: string;
  className?: string;
}) {
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Wenn die Komponente verschwindet, darf kein Timer mehr zurueckfeuern und
  // kurz vor dem Unmount noch den State aendern.
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );

  const copy = async (): Promise<void> => {
    const ok = await writeClipboard(value);
    if (!ok) return;
    setCopied(true);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setCopied(false), 1400);
  };

  return (
    <button
      type="button"
      onClick={() => void copy()}
      title={title ?? 'Zum Kopieren antippen'}
      className={`group flex w-full min-w-0 items-center gap-2 rounded-md px-1.5 py-0.5 text-left transition-colors hover:bg-base-750 ${className}`}
    >
      {label && (
        <span className="shrink-0 text-[10px] uppercase tracking-wide text-slate-600">
          {label}
        </span>
      )}
      <span className="min-w-0 flex-1 truncate font-mono text-xs text-slate-300 group-hover:text-slate-100">
        {value}
      </span>
      <span
        aria-hidden="true"
        className={`shrink-0 text-xs transition-colors ${copied ? 'text-emerald-400' : 'text-slate-500 group-hover:text-slate-300'}`}
      >
        {copied ? '✓' : '⧉'}
      </span>
      {/* Für Screenreader: das Ergebnis des Kopierens mitteilen. */}
      <span role="status" className="sr-only">
        {copied ? `${value} kopiert` : ''}
      </span>
    </button>
  );
}

/**
 * In die Zwischenablage schreiben.
 *
 * `navigator.clipboard` ist die saubere Variante, braucht aber eine
 * sichere Umgebung - also HTTPS oder localhost. Auf einem plain-HTTP-Zugriff
 * aus dem LAN, etwa http://192.168.178.57:3000, ist die API schlicht nicht
 * vorhanden. Genau das ist hier der Normalfall, deshalb der Rueckfall auf ein
 * verstecktes Textfeld plus document.execCommand.
 */
async function writeClipboard(value: string): Promise<boolean> {
  if (navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(value);
      return true;
    } catch {
      /* faellt unten auf execCommand zurueck */
    }
  }

  const el = document.createElement('textarea');
  el.value = value;
  // Nicht display:none - ein verstecktes Element laesst sich nicht auswaehlen,
  // und execCommand scheitert dann still.
  el.setAttribute('readonly', '');
  el.style.position = 'fixed';
  el.style.top = '0';
  el.style.left = '-9999px';
  el.style.opacity = '0';
  document.body.appendChild(el);
  el.select();
  el.setSelectionRange(0, value.length);
  let ok = false;
  try {
    ok = document.execCommand('copy');
  } catch {
    ok = false;
  }
  document.body.removeChild(el);
  return ok;
}
