import { useEffect, useRef } from 'react';

interface Props {
  /** Was geloescht wird - im Klartext, damit man bei mehreren Konten sieht,
   *  welches gemeint ist. */
  label: string;
  edition: 'java' | 'bedrock';
  /** Laeuft die Instanz gerade? Dann sagt der Dialog es, weil das Loeschen
   *  den Prozess beendet. */
  running: boolean;
  onConfirm: () => void;
  onCancel: () => void;
}

/**
 * Rueckfrage vor dem Loeschen eines Accounts.
 *
 * Das Loeschen ist nicht rueckgaengig zu machen: der Account fliegt aus der
 * Datenbank, und fuer Java verschwindet mit ihm das komplette Instanzverzeichnis
 * samt Log und gespeicherter Anmeldung. Deshalb gibt es diesen Dialog mit dem
 * Namen im Titel und zwei klar benannten Knoepfen - aber bewusst ohne
 * Namens-Abtipperei: die war laestig und schuetzt vor nichts, wovor der Dialog
 * nicht schon schuetzt.
 *
 * Der Fokus liegt beim Oeffnen auf "Abbrechen", nicht auf "Loeschen": wer aus
 * Versehen auf den Papierkorb kam und blind Enter drueckt, soll nicht loeschen.
 */
export default function ConfirmDelete({ label, edition, running, onConfirm, onCancel }: Props) {
  const cancelRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    cancelRef.current?.focus();
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === 'Escape') onCancel();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onCancel]);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onCancel}
    >
      <div
        className="card w-full max-w-md overflow-hidden"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-delete-title"
      >
        <div className="p-5">
          <h3 id="confirm-delete-title" className="text-base font-semibold text-slate-100">
            {label} löschen?
          </h3>
          <p className="mt-2 text-sm text-slate-400">
            {running ? (
              <>Der Account läuft gerade. Beim Löschen wird der Prozess beendet.</>
            ) : (
              <>Der Account ist gestoppt.</>
            )}{' '}
            {edition === 'java' && (
              <>Dabei verschwinden auch das Instanzverzeichnis mit dem Log und die gespeicherte Anmeldung.</>
            )}
            <> Das lässt sich nicht rückgängig machen.</>
          </p>
        </div>

        <div className="flex justify-end gap-2 border-t border-base-750 p-4">
          <button ref={cancelRef} className="btn-ghost" onClick={onCancel}>
            Abbrechen
          </button>
          <button className="btn-danger" onClick={onConfirm}>
            Löschen
          </button>
        </div>
      </div>
    </div>
  );
}
