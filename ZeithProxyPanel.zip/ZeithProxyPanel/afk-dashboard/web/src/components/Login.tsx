import { useState, type FormEvent } from 'react';
import { api, ApiError } from '../lib/api';

export default function Login({ onDone }: { onDone: () => void }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent): Promise<void> => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.login(username, password);
      onDone();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Anmeldung fehlgeschlagen');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-full items-center justify-center px-4">
      <form onSubmit={submit} className="card w-full max-w-sm p-8">
        <h1 className="mb-1 text-xl font-semibold text-slate-100">AFK-Dashboard</h1>
        <p className="mb-6 text-sm text-slate-500">
          Das Passwort steht beim ersten Start im Container-Log.
        </p>

        <label className="label" htmlFor="u">
          Benutzername
        </label>
        <input
          id="u"
          className="field mb-4"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          autoComplete="username"
          autoFocus
        />

        <label className="label" htmlFor="p">
          Passwort
        </label>
        <input
          id="p"
          type="password"
          className="field mb-6"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          autoComplete="current-password"
        />

        {error && (
          <p className="mb-4 rounded-lg border border-rose-800 bg-rose-950/40 px-3 py-2 text-sm text-rose-300">
            {error}
          </p>
        )}

        <button className="btn-primary w-full" disabled={busy || !username || !password}>
          {busy ? 'Anmelden…' : 'Anmelden'}
        </button>
      </form>
    </div>
  );
}
