import type { Account } from '../lib/types';
import CopyChip from './CopyChip';
import {
  DOT_STYLE,
  SOURCE_LABEL,
  STATE_LABEL,
  STATE_STYLE,
  formatCoords,
  formatDuration,
  formatPing,
} from '../lib/format';

interface Props {
  account: Account;
  busy: boolean;
  onStart: () => void;
  onStop: () => void;
  onRestart: () => void;
  onOpen: () => void;
  onDelete: () => void;
}

export default function AccountCard({
  account: a,
  busy,
  onStart,
  onStop,
  onRestart,
  onOpen,
  onDelete,
}: Props) {
  const s = a.status;
  const running = s.state !== 'stopped' && s.state !== 'error';

  return (
    <div className="card flex flex-col overflow-hidden transition-colors hover:border-base-600">
      {/* Kopfleiste */}
      <button onClick={onOpen} className="flex items-start gap-3 p-4 text-left">
        <span className={`mt-1.5 h-2.5 w-2.5 shrink-0 rounded-full ${DOT_STYLE[s.state]} ${s.state === 'online' ? 'dot-online' : ''}`} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <h3 className="truncate font-semibold text-slate-100">{a.label}</h3>
            <span
              className={`pill ${a.edition === 'bedrock' ? 'bg-sky-900/50 text-sky-300' : 'bg-base-750 text-slate-400'}`}
              title={a.edition === 'bedrock' ? 'Bedrock-Protokoll' : 'ZenithProxy (Java)'}
            >
              {a.edition === 'bedrock' ? 'BE' : 'JV'}
            </span>
          </div>
          <p className="truncate text-xs text-slate-500">
            {a.username} · {a.serverHost}
          </p>
        </div>
        <span className={`pill shrink-0 ${STATE_STYLE[s.state]}`}>{STATE_LABEL[s.state]}</span>
      </button>

      {/* Werte */}
      <div className="grid grid-cols-3 gap-px border-y border-base-750 bg-base-750 text-center">
        <Stat label="Ping" value={formatPing(s.ping)} />
        <Stat
          label="Spielzeit"
          value={formatDuration(s.playtimeSec ?? a.uptimeSec)}
          title="Wie lange der Account gerade durchgehend verbunden ist"
        />
        <Stat label="Position" value={formatCoords(s.position)} />
      </div>

      {/* Proxy-Adresse, ein einziger Kopier-Button ueber die volle Breite.
          Bewusst ohne zusaetzlichen Hinweistext daneben: auf schmalen Karten
          haben zwei Elemente nebeneinander keinen Platz und der Text wird
          abgeschnitten. Das Kopier-Icon steht immer da, nicht erst bei Hover -
          auf dem Handy gibt es kein Hover. */}
      {s.proxyIp && (
        <div className="border-b border-base-750 px-3 py-1.5">
          <CopyChip
            value={s.proxyIp}
            label="Proxy"
            title="Adresse, auf der dieser Proxy lauscht. Antippen zum Kopieren."
          />
        </div>
      )}

      {/* Spieler in der Nähe. Tippen öffnet die Details mit der vollen Liste,
          Whitelist und Modulen. Die Zeile steht nur da, wenn es Daten gibt -
          bei gestoppten Instanzen weiss niemand, wer daneben steht. */}
      {s.nearby && (
        <button
          onClick={onOpen}
          className="flex items-center gap-2 border-b border-base-750 px-4 py-1.5 text-left text-xs transition-colors hover:bg-base-800"
          title="Spieler in Sichtweite des Bots. Antippen für Details, Whitelist und Module."
        >
          <span aria-hidden="true" className="text-slate-500">👁</span>
          {s.nearby.count === 0 ? (
            <span className="text-slate-600">Niemand in der Nähe</span>
          ) : (
            <span className="min-w-0 truncate text-slate-300">
              <span className="font-medium text-slate-200">{s.nearby.count} in der Nähe: </span>
              <span className="font-mono">{s.nearby.names.join(', ')}</span>
              {s.nearby.count > s.nearby.names.length && <span className="text-slate-500"> …</span>}
            </span>
          )}
        </button>
      )}

      {/* Anmeldung noetig. Steht absichtlich hier auf der Karte und nicht nur
          in der Detailansicht: nach "Starten" wartet die Instanz auf genau
          diesen Klick, und ohne sichtbaren Link sieht sie grundlos aus.

          Nur der Link, kein Code zum Abtippen - Microsoft steckt den Code
          schon in der URL, und ein zweiter Weg kann nur schiefgehen. */}
      {s.authUrl && (
        <div className="border-b border-amber-800 bg-amber-950/40 px-4 py-3 text-xs">
          <p className="mb-2 text-amber-200">Anmeldung bei Microsoft nötig</p>
          <a
            className="btn-primary btn-sm block w-full text-center"
            href={s.authUrl}
            target="_blank"
            rel="noreferrer noopener"
          >
            Anmelden
          </a>
        </div>
      )}

      {/* Warteschlange */}
      {s.state === 'queued' && s.queue && (
        <div className="border-b border-base-750 bg-violet-950/20 px-4 py-2 text-xs text-violet-300">
          {s.queue.priority !== null && s.queue.priority > 0
            ? `Priority: ${s.queue.priority} vor dir`
            : s.queue.regular !== null
              ? `${s.queue.regular} vor dir`
              : 'In der Warteschlange'}
        </div>
      )}

      {/* Fusszeile */}
      <div className="mt-auto flex items-center justify-between gap-2 p-3">
        <span
          className="truncate text-[11px] text-slate-600"
          title={
            s.source === 'logtail'
              ? 'Die Web-API antwortet nicht - diese Werte wurden aus dem Log abgeleitet und sind ungenau.'
              : `Datenquelle: ${SOURCE_LABEL[s.source] ?? s.source}`
          }
        >
          {SOURCE_LABEL[s.source] ?? s.source}
        </span>

        <div className="flex items-center gap-1">
          <button
            className="btn-ghost btn-sm px-1.5 text-slate-600 transition-colors hover:text-rose-400"
            onClick={onDelete}
            disabled={busy}
            title={`${a.label} endgültig löschen`}
            aria-label={`${a.label} löschen`}
          >
            <svg viewBox="0 0 16 16" className="h-3.5 w-3.5" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
              <path d="M2.5 4h11M6.5 4V2.5h3V4M4 4l.6 9.2a1 1 0 0 0 1 .8h4.8a1 1 0 0 0 1-.8L12 4M6.6 6.6v4.8M9.4 6.6v4.8" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
          {running ? (
            <>
              <button className="btn-ghost btn-sm" onClick={onRestart} disabled={busy}>
                Neustart
              </button>
              <button className="btn-ghost btn-sm" onClick={onStop} disabled={busy}>
                Stopp
              </button>
            </>
          ) : (
            <button className="btn-primary btn-sm" onClick={onStart} disabled={busy}>
              Starten
            </button>
          )}
        </div>
      </div>

      {/* Fehlerzeile */}
      {s.lastError && (
        <p className="border-t border-rose-900/60 bg-rose-950/30 px-4 py-2 text-xs text-rose-300">
          {s.lastError}
        </p>
      )}
    </div>
  );
}

function Stat({ label, value, title }: { label: string; value: string; title?: string }) {
  return (
    <div className="bg-base-850 px-2 py-2.5" title={title}>
      <div className="text-[10px] uppercase tracking-wide text-slate-600">{label}</div>
      <div className="truncate font-mono text-sm text-slate-300">{value}</div>
    </div>
  );
}
