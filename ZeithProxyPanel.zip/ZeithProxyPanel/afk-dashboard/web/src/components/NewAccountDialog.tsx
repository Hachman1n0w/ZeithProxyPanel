import { useState, type FormEvent } from 'react';
import { api, ApiError } from '../lib/api';
import type { AuthType, Edition } from '../lib/types';

interface Props {
  onClose: () => void;
  onCreated: () => void;
}

export default function NewAccountDialog({ onClose, onCreated }: Props) {
  const [edition, setEdition] = useState<Edition>('java');
  const [label, setLabel] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [authType, setAuthType] = useState<AuthType>('deviceCode');
  const [host, setHost] = useState('2b2t.org');
  const [port, setPort] = useState(25565);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const switchEdition = (e: Edition): void => {
    setEdition(e);
    // 2b2t laeuft auf Java 25565 und Bedrock 19132 - die Standardwerte
    // unterscheiden sich, also mitdrehen.
    if (e === 'bedrock') {
      setPort(19132);
    } else {
      setPort(25565);
    }
  };

  const submit = async (e: FormEvent): Promise<void> => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.createAccount({
        label,
        username,
        edition,
        serverHost: host,
        serverPort: port,
        // Nur Java kennt diese Felder. Bei Bedrock wuerden sie nichts tun.
        ...(edition === 'java' ? { authType, ...(authType === 'prism' ? { password } : {}) } : {}),
      });
      onCreated();
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Konto konnte nicht angelegt werden');
    } finally {
      setBusy(false);
    }
  };

  const needsPassword = edition === 'java' && authType === 'prism';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <form onClick={(e) => e.stopPropagation()} onSubmit={submit} className="card w-full max-w-md p-6">
        <h2 className="mb-5 text-lg font-semibold text-slate-100">Account hinzufügen</h2>

        <div className="mb-5 grid grid-cols-2 gap-2">
          <EditionButton
            active={edition === 'java'}
            onClick={() => switchEdition('java')}
            title="Java (ZenithProxy)"
            subtitle="Voll steuerbar, ca. 600 MB"
          />
          <EditionButton
            active={edition === 'bedrock'}
            onClick={() => switchEdition('bedrock')}
            title="Bedrock"
            subtitle="Leichter, ca. 150 MB"
          />
        </div>

        <label className="label">Anzeigename</label>
        <input
          className="field mb-4"
          placeholder="z.B. AFK-1"
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          autoFocus
        />

        {edition === 'java' && (
          <>
            <label className="label">Anmeldung</label>
            <div className="mb-3 grid grid-cols-2 gap-2">
              <EditionButton
                active={authType === 'deviceCode'}
                onClick={() => setAuthType('deviceCode')}
                title="Bestätigungscode"
                subtitle="Kein Passwort nötig"
              />
              <EditionButton
                active={authType === 'prism'}
                onClick={() => setAuthType('prism')}
                title="E-Mail + Passwort"
                subtitle="Vollautomatisch"
              />
            </div>
          </>
        )}

        <label className="label">
          {edition === 'bedrock' ? 'Gamertag' : 'Microsoft-E-Mail'}
        </label>
        <input
          className="field mb-4"
          type="email"
          autoComplete="off"
          placeholder={edition === 'bedrock' ? 'Xbox-Gamertag' : 'name@example.com'}
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />

        {needsPassword && (
          <>
            <label className="label">Microsoft-Passwort</label>
            <input
              className="field mb-4"
              type="password"
              autoComplete="new-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </>
        )}

        <div className="mb-2 grid grid-cols-3 gap-2">
          <div className="col-span-2">
            <label className="label">Server</label>
            <input className="field" value={host} onChange={(e) => setHost(e.target.value)} />
          </div>
          <div>
            <label className="label">Port</label>
            <input
              className="field font-mono"
              type="number"
              value={port}
              onChange={(e) => setPort(Number(e.target.value))}
            />
          </div>
        </div>

        {edition === 'bedrock' && (
          <p className="mb-4 rounded-lg border border-sky-900 bg-sky-950/30 px-3 py-2 text-xs text-sky-300">
            Der Bedrock-Account muss beim ersten Start einmalig bei Microsoft angemeldet werden.
            Das Dashboard zeigt dir danach den Bestätigungscode an.
          </p>
        )}

        {edition === 'java' && authType === 'deviceCode' && (
          <p className="mb-4 rounded-lg border border-sky-900 bg-sky-950/30 px-3 py-2 text-xs text-sky-300">
            Beim ersten Start meldet sich ZenithProxy mit einem Microsoft-Bestätigungscode an.
            Der Code steht danach im Log des Accounts - einmal bestätigen, dann läuft es
            ohne Eingriff. Auf dem Server wird kein Passwort gespeichert.
          </p>
        )}

        {needsPassword && (
          <p className="mb-4 rounded-lg border border-amber-900 bg-amber-950/30 px-3 py-2 text-xs text-amber-300">
            Das Passwort wird verschlüsselt in der Datenbank abgelegt und nie wieder
            angezeigt. Microsoft kann bei ungewöhnlichen Anmeldungen trotzdem eine
            Bestätigung per Mail verlangen.
          </p>
        )}

        {error && (
          <p className="mb-4 rounded-lg border border-rose-800 bg-rose-950/40 px-3 py-2 text-sm text-rose-300">
            {error}
          </p>
        )}

        <div className="flex justify-end gap-2">
          <button type="button" className="btn-ghost" onClick={onClose}>
            Abbrechen
          </button>
          <button
            className="btn-primary"
            disabled={busy || !label || !username || (needsPassword && !password)}
          >
            {busy ? 'Wird angelegt…' : 'Anlegen'}
          </button>
        </div>
      </form>
    </div>
  );
}

function EditionButton({
  active,
  onClick,
  title,
  subtitle,
}: {
  active: boolean;
  onClick: () => void;
  title: string;
  subtitle: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-lg border px-3 py-2.5 text-left transition-colors ${
        active
          ? 'border-emerald-600 bg-emerald-950/40'
          : 'border-base-700 bg-base-800 hover:border-base-600'
      }`}
    >
      <div className={`text-sm font-medium ${active ? 'text-emerald-300' : 'text-slate-300'}`}>
        {title}
      </div>
      <div className="text-[11px] text-slate-500">{subtitle}</div>
    </button>
  );
}
