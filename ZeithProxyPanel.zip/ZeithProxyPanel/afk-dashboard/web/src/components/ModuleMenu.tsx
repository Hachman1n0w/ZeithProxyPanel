import { useCallback, useEffect, useState } from 'react';
import { api } from '../lib/api';
import type { ModuleState } from '../lib/types';

/**
 * Anzeigenamen und Erklaerungen zu den ZenithProxy-Modulen.
 *
 * Der Server kennt nur die Befehlsnamen (antiAFK, autoEat, ...), die
 * Beschriftung liegt hier: sie ist reine Darstellung und gehoert nicht in die
 * API. Die Reihenfolge ist dieselbe wie auf dem Server.
 */
const MODULE_INFO: { id: string; label: string; hint: string }[] = [
  { id: 'antiAFK', label: 'Anti-AFK', hint: 'Bewegt den Bot, damit 2b2t ihn nicht wegen Inaktivität kickt.' },
  { id: 'antiKick', label: 'Anti-Kick', hint: 'Kickt untätige steuernde Spieler vom Proxy.' },
  { id: 'antiLeak', label: 'Anti-Leak', hint: 'Blockt Chat-Nachrichten, die Koordinaten verraten könnten.' },
  { id: 'coordObf', label: 'Koordinaten-Verschleierung', hint: 'Zeigt Zuschauern gefälschte Koordinaten und Biome.' },
  { id: 'autoEat', label: 'Auto-Essen', hint: 'Isst automatisch bei wenig Leben oder Hunger.' },
  { id: 'autoFish', label: 'Auto-Angeln', hint: 'Angelt von selbst. Zählt als Anti-AFK - nicht mit Anti-AFK kombinieren.' },
  { id: 'autoArmor', label: 'Auto-Rüstung', hint: 'Zieht die beste Rüstung aus dem Inventar an.' },
  { id: 'autoFish', label: 'Auto-Angeln', hint: 'Angelt von selbst. Zählt als Anti-AFK - nicht mit Anti-AFK kombinieren.' },
  // autoArmor fehlt bewusst: ohne Argument meldet es keinen Zustand, nur Hilfe.
  { id: 'autoTotem', label: 'Auto-Totem', hint: 'Steckt bei wenig Leben ein Totem in die Zweithand.' },
  { id: 'autoMend', label: 'Auto-Mending', hint: 'Hält Mending-Items zum Reparieren in der Hand.' },
  { id: 'autoRespawn', label: 'Auto-Respawn', hint: 'Respawnt automatisch nach dem Tod.' },
  { id: 'autoReconnect', label: 'Auto-Reconnect', hint: 'Verbindet nach einem Disconnect von selbst neu.' },
  { id: 'autoDisconnect', label: 'Auto-Disconnect', hint: 'Trennt bei Gefahr (wenig Leben, fremde Spieler, Totem-Pop).' },
  { id: 'autoDrop', label: 'Auto-Drop', hint: 'Wirft konfigurierte Items automatisch weg.' },
  { id: 'spectator', label: 'Zuschauer-Modus', hint: 'Lässt Spieler der Zuschauer-Liste durch Bot-Augen zusehen.' },
  { id: 'visualRange', label: 'Sichtweiten-Melder', hint: 'Meldet Spieler, die in Sichtweite kommen oder gehen.' },
];

/**
 * Schalterleiste fuer die ZenithProxy-Module.
 *
 * Die Zustaende kommen live aus der Instanz (`<modul>` ohne Argument meldet
 * sie), nicht aus unserer Datenbank - was man ueber die Konsole umstellt,
 * steht hier beim naechsten Oeffnen richtig. Umschalten schickt
 * `<modul> on/off` an die Instanz und liest danach den Zustand neu, statt ihn
 * zu raten: was ZenithProxy ablehnt, springt sichtbar zurueck.
 */
export default function ModuleMenu({ accountId }: { accountId: string }) {
  const [states, setStates] = useState<ModuleState[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);

  const load = useCallback(async (): Promise<void> => {
    try {
      const res = await api.modules(accountId);
      setStates(res.modules);
      setError(null);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [accountId]);

  useEffect(() => {
    void load();
  }, [load]);

  const toggle = async (id: string, current: boolean | null): Promise<void> => {
    // Unbekannter Zustand: erst neu laden statt blind zu schalten.
    if (current === null) {
      await load();
      return;
    }
    setBusy(id);
    try {
      await api.setModule(accountId, id, !current);
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(null);
    }
  };

  return (
    <section>
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-300">Module</h3>
        <button className="btn-ghost btn-sm" onClick={() => void load()}>
          Neu laden
        </button>
      </div>
      {error && (
        <p className="mb-2 rounded-lg border border-rose-800 bg-rose-950/40 px-3 py-2 text-xs text-rose-300">
          {error}
        </p>
      )}
      {!states ? (
        <p className="text-xs text-slate-600">Lade Modulzustände…</p>
      ) : (
        <ul className="divide-y divide-base-750 rounded-lg border border-base-750 bg-base-800">
          {MODULE_INFO.map((info) => {
            const state = states.find((s) => s.id === info.id)?.enabled ?? null;
            const on = state === true;
            const unknown = state === null;
            return (
              <li key={info.id} className="flex items-center gap-3 px-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-slate-200">{info.label}</p>
                  <p className="truncate text-xs text-slate-500" title={info.hint}>
                    {info.hint}
                  </p>
                </div>
                <span
                  className={`shrink-0 text-[11px] ${unknown ? 'text-slate-600' : on ? 'text-emerald-400' : 'text-slate-500'}`}
                >
                  {unknown ? '?' : on ? 'an' : 'aus'}
                </span>
                <button
                  role="switch"
                  aria-checked={on}
                  aria-label={info.label}
                  disabled={busy === info.id}
                  onClick={() => void toggle(info.id, state)}
                  title={unknown ? 'Zustand unbekannt - antippen zum neu laden' : `Zum ${on ? 'Aus' : 'Ein'}schalten antippen`}
                  className={`relative h-6 w-11 shrink-0 rounded-full transition-colors ${
                    on ? 'bg-emerald-600' : 'bg-base-600'
                  } ${busy === info.id ? 'opacity-50' : ''}`}
                >
                  <span
                    className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
                      on ? 'left-[22px]' : 'left-0.5'
                    }`}
                  />
                </button>
              </li>
            );
          })}
        </ul>
      )}
      <p className="mt-2 text-[11px] text-slate-600">
        Feineinstellungen (z.B. antiAFK walkDistance, autoEat hunger) sowie autoArmor, stalk,
        autoReply und weitere Befehle über die Konsole unten.
      </p>
    </section>
  );
}
