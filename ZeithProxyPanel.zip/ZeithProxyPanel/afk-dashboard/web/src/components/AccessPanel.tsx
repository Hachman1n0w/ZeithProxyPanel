import { useCallback, useEffect, useState } from 'react';
import { api } from '../lib/api';
import type { AccessLevel, AccessLists, PlayersInfo } from '../lib/types';

/**
 * Spieler in der Naehe plus Zugriffsverwaltung (Whitelist).
 *
 * Zwei getrennte Bereiche, eine Sache: wer darf an den Bot heran.
 * Oben steht, wer gerade da ist (`visualRange list` plus Tablist), unten, wer
 * darf (`whitelist`, `spectator whitelist`, `blacklist`).
 *
 * Zu den Stufen, ehrlich: ZenithProxy kennt keine feinen Rechte pro Spieler.
 * Es gibt genau drei Listen - Vollzugriff (steuern und zusehen), Zuschauer
 * (nur zusehen) und Blockiert. "Permissions aendern" heisst hier also: einen
 * Spieler von einer Liste auf eine andere setzen. Wer feinere Rechte
 * erwartet, sucht sie in ZenithProxy vergebens.
 */
export default function AccessPanel({ accountId }: { accountId: string }) {
  const [players, setPlayers] = useState<PlayersInfo | null>(null);
  const [access, setAccess] = useState<AccessLists | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [name, setName] = useState('');
  const [level, setLevel] = useState<Exclude<AccessLevel, 'none'>>('full');

  const load = useCallback(async (): Promise<void> => {
    try {
      const [p, a] = await Promise.all([api.players(accountId), api.access(accountId)]);
      setPlayers(p);
      setAccess(a);
      setError(null);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [accountId]);

  useEffect(() => {
    void load();
  }, [load]);

  const valid = /^[A-Za-z0-9_]{3,16}$/.test(name.trim());

  const add = async (): Promise<void> => {
    const player = name.trim();
    if (!valid) return;
    setBusy(true);
    try {
      await api.setAccess(accountId, player, level);
      setName('');
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const move = async (player: string, to: AccessLevel): Promise<void> => {
    setBusy(true);
    try {
      await api.setAccess(accountId, player, to);
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="space-y-4">
      <div>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-slate-300">Spieler in der Nähe</h3>
          <button className="btn-ghost btn-sm" onClick={() => void load()} disabled={busy}>
            Neu laden
          </button>
        </div>
        {error && (
          <p className="mb-2 rounded-lg border border-rose-800 bg-rose-950/40 px-3 py-2 text-xs text-rose-300">
            {error}
          </p>
        )}
        {!players ? (
          <p className="text-xs text-slate-600">Lade…</p>
        ) : players.nearby.length === 0 ? (
          <p className="text-xs text-slate-500">Niemand in Sichtweite des Bots.</p>
        ) : (
          <ul className="flex flex-wrap gap-1.5">
            {players.nearby.map((n) => (
              <li key={n} className="rounded-md bg-base-750 px-2 py-1 font-mono text-xs text-slate-200">
                {n}
              </li>
            ))}
          </ul>
        )}
        {players && players.server.length > 0 && (
          <details className="mt-2">
            <summary className="cursor-pointer text-xs text-slate-500 hover:text-slate-300">
              {players.server.length} auf dem Server{players.truncated ? ' (gekürzt)' : ''} - alle ansehen
            </summary>
            <ul className="thin-scroll mt-2 flex max-h-32 flex-wrap gap-1.5 overflow-auto">
              {players.server.map((n) => (
                <li key={n} className="rounded bg-base-800 px-1.5 py-0.5 font-mono text-[11px] text-slate-400">
                  {n}
                </li>
              ))}
            </ul>
          </details>
        )}
      </div>

      <div>
        <h3 className="mb-1 text-sm font-semibold text-slate-300">Zugriff (Whitelist)</h3>
        <p className="mb-2 text-[11px] text-slate-600">
          Vollzugriff steuert den Account und sieht zu, Zuschauer sehen nur zu,
          Blockierte kommen nicht drauf.
        </p>
        <div className="flex flex-wrap gap-2">
          <input
            className="field min-w-0 flex-1 font-mono"
            placeholder="Spielername"
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') void add();
            }}
            disabled={busy}
            autoComplete="off"
            spellCheck={false}
          />
          <select
            className="field w-auto shrink-0"
            value={level}
            onChange={(e) => setLevel(e.target.value as typeof level)}
            disabled={busy}
            aria-label="Zugriffsstufe"
          >
            <option value="full">Vollzugriff</option>
            <option value="watch">Nur zusehen</option>
            <option value="blocked">Blockiert</option>
          </select>
          <button className="btn-primary btn-sm shrink-0" onClick={() => void add()} disabled={busy || !valid}>
            Hinzufügen
          </button>
        </div>

        {!access ? (
          <p className="mt-2 text-xs text-slate-600">Lade Listen…</p>
        ) : (
          <div className="mt-3 space-y-2">
            <AccessList
              title="Vollzugriff"
              names={access.whitelist}
              empty="Niemand - ausser dir über das Dashboard."
              busy={busy}
              onMove={(p, to) => void move(p, to)}
              levels={['watch', 'blocked', 'none']}
            />
            <AccessList
              title="Zuschauer"
              names={access.spectator}
              empty={access.spectatorBlocked ? 'Nicht lesbar - Instanz neu starten, damit die Berechtigung greift.' : 'Keine Zuschauer.'}
              busy={busy}
              onMove={(p, to) => void move(p, to)}
              levels={['full', 'blocked', 'none']}
            />
            <AccessList
              title="Blockiert"
              names={access.blacklist}
              empty="Die Blacklist lässt sich nicht anzeigen - ZenithProxy hat dafür keinen Befehl. Blockieren und Entblocken unten funktioniert trotzdem."
              busy={busy}
              onMove={(p, to) => void move(p, to)}
              levels={['full', 'watch', 'none']}
            />
          </div>
        )}
      </div>
    </section>
  );
}

const LEVEL_LABEL: Record<AccessLevel, string> = {
  full: 'Vollzugriff',
  watch: 'Zusehen',
  blocked: 'Blockieren',
  none: 'Entfernen',
};

function AccessList({
  title,
  names,
  empty,
  busy,
  onMove,
  levels,
}: {
  title: string;
  names: string[];
  empty: string;
  busy: boolean;
  onMove: (player: string, to: AccessLevel) => void;
  levels: AccessLevel[];
}) {
  return (
    <div className="rounded-lg border border-base-750 bg-base-800 px-3 py-2">
      <p className="mb-1.5 text-[11px] uppercase tracking-wide text-slate-500">
        {title} ({names.length})
      </p>
      {names.length === 0 ? (
        <p className="text-xs text-slate-600">{empty}</p>
      ) : (
        <ul className="space-y-1">
          {names.map((n) => (
            <li key={n} className="flex items-center gap-2">
              <span className="min-w-0 flex-1 truncate font-mono text-xs text-slate-200">{n}</span>
              {levels.map((to) => (
                <button
                  key={to}
                  className="btn-ghost btn-sm shrink-0 px-1.5"
                  disabled={busy}
                  title={`${n} → ${LEVEL_LABEL[to]}`}
                  onClick={() => onMove(n, to)}
                >
                  {LEVEL_LABEL[to]}
                </button>
              ))}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
