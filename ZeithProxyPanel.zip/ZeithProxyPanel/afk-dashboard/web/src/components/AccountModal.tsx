import { useCallback, useEffect, useRef, useState } from 'react';
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { api } from '../lib/api';
import CopyChip from './CopyChip';
import AccessPanel from './AccessPanel';
import ModuleMenu from './ModuleMenu';
import type { AccountDetail, CommandResult, StatusSample } from '../lib/types';
import { STATE_LABEL, STATE_STYLE, formatDuration, formatTime } from '../lib/format';

interface Props {
  id: string;
  onClose: () => void;
}

export default function AccountModal({ id, onClose }: Props) {
  const [detail, setDetail] = useState<AccountDetail | null>(null);
  const [history, setHistory] = useState<StatusSample[]>([]);
  const [command, setCommand] = useState('');
  const [result, setResult] = useState<CommandResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const logRef = useRef<HTMLPreElement>(null);

  const load = useCallback(async (): Promise<void> => {
    try {
      const [d, h] = await Promise.all([api.detail(id), api.history(id, 6)]);
      setDetail(d);
      setHistory(h.history);
    } catch (err) {
      setError((err as Error).message);
    }
  }, [id]);

  useEffect(() => {
    void load();
    const timer = setInterval(() => void load(), 10_000);
    return () => clearInterval(timer);
  }, [load]);

  // Log automatisch ans Ende scrollen, sonst verliert man bei langen Logs
  // den Faden, genau wenn etwas passiert.
  useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [detail?.log.length]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const run = async (): Promise<void> => {
    const cmd = command.trim();
    if (!cmd) return;
    setBusy(true);
    setResult(null);
    try {
      setResult(await api.command(id, cmd));
      setCommand('');
    } catch (err) {
      setResult({ ok: false, output: '', error: (err as Error).message });
    } finally {
      setBusy(false);
    }
  };

  const reauth = async (): Promise<void> => {
    setBusy(true);
    try {
      await api.reauth(id);
      await load();
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  if (!detail) {
    return (
      <Overlay onClose={onClose}>
        <div className="card p-6 text-sm text-slate-500">
          {error ?? 'Lade…'}
        </div>
      </Overlay>
    );
  }

  const a = detail.account;
  const chartData = history.map((h) => ({
    time: formatTime(h.ts),
    ping: h.ping,
    queue: h.queuePosition,
    health: h.health,
  }));

  return (
    <Overlay onClose={onClose}>
      <div className="card flex max-h-[88vh] w-full max-w-4xl flex-col overflow-hidden">
        {/* Kopf */}
        <div className="flex items-start justify-between gap-4 border-b border-base-750 p-5">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-semibold text-slate-100">{a.label}</h2>
              <span className={`pill ${STATE_STYLE[a.status.state]}`}>
                {STATE_LABEL[a.status.state]}
              </span>
            </div>
            <p className="mt-0.5 text-sm text-slate-500">
              {a.username} · {a.serverHost}:{a.serverPort}
              {a.mcPort !== null && <span className="ml-2 text-slate-600">MC-Port {a.mcPort}</span>}
              {a.pid !== null && <span className="ml-2 text-slate-600">PID {a.pid}</span>}
            </p>
          </div>
          <button className="btn-ghost btn-sm" onClick={onClose}>
            Schließen
          </button>
        </div>

        <div className="thin-scroll flex-1 space-y-5 overflow-y-auto p-5">
          {/* Bedrock-Anmeldung */}
          {a.edition === 'bedrock' && <AuthPanel detail={detail} onReauth={reauth} busy={busy} />}

          {/* Java: der Anmeldelink steht auf der Karte, damit er direkt nach
              dem Start auffaellt. Hier nur der Hinweis, was zu tun ist. */}
          {a.edition === 'java' && a.status.authUrl && (
            <p className="rounded-lg border border-amber-900 bg-amber-950/30 px-3 py-2 text-xs text-amber-300">
              ZenithProxy wartet auf die Microsoft-Anmeldung. Über „Anmelden“ auf der
              Karte bestätigen - danach läuft die Instanz ohne Eingriff weiter.
            </p>
          )}

          {/* Java: wer in der Naehe ist und wer an den Bot darf. */}
          {a.edition === 'java' && <AccessPanel accountId={a.id} />}

          {/* Java: Schutz- und Automatik-Module schalten. */}
          {a.edition === 'java' && <ModuleMenu accountId={a.id} />}

          {/* Zustandsuebersicht */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Metric label="Laufzeit" value={formatDuration(a.uptimeSec)} />
            <Metric label="Spielzeit" value={formatDuration(a.status.playtimeSec)} />
            <Metric label="Ping" value={a.status.ping !== null ? `${a.status.ping} ms` : '—'} />
            <Metric
              label="Ticks gesendet"
              value={detail.ticks ? String(detail.ticks.ticks) : '—'}
              title="Wie viele Bewegungs-Pakete der Bedrock-Bot gesendet hat"
            />
          </div>

          {/* Proxy-Adresse. Hier mit mehr Raum als auf der Karte, und sie ist
              das, was man in einen Tunnel-Dialog oder zu einem Freund schickt. */}
          {a.status.proxyIp && (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-base-750 bg-base-800 px-3 py-2.5">
              <div className="min-w-0">
                <div className="text-[10px] uppercase tracking-wide text-slate-600">
                  Proxy-Adresse
                </div>
                <p className="mt-0.5 text-xs text-slate-500">
                  Adresse, auf der die Instanz lauscht. Für den Zugriff von außen
                  nötig — etwa als Ziel eines Tunnels.
                </p>
              </div>
              <CopyChip
                value={a.status.proxyIp}
                className="shrink-0 border border-base-750 bg-base-900 px-2.5 py-1.5 text-sm"
                title="Zum Kopieren antippen"
              />
            </div>
          )}

          {a.status.lastError && (
            <p className="rounded-lg border border-rose-800 bg-rose-950/40 px-3 py-2 text-sm text-rose-300">
              {a.status.lastError}
            </p>
          )}

          {/* Verlauf */}
          <section>
            <h3 className="mb-2 text-sm font-semibold text-slate-300">Ping der letzten 6 Stunden</h3>
            <div className="h-48 rounded-lg border border-base-750 bg-base-900 p-2">
              {chartData.length > 1 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={chartData}>
                    <CartesianGrid stroke="#232b3d" strokeDasharray="3 3" />
                    <XAxis
                      dataKey="time"
                      tick={{ fill: '#64748b', fontSize: 10 }}
                      minTickGap={30}
                    />
                    <YAxis tick={{ fill: '#64748b', fontSize: 10 }} width={40} unit=" ms" />
                    <Tooltip
                      contentStyle={{
                        background: '#151a24',
                        border: '1px solid #232b3d',
                        borderRadius: 8,
                        fontSize: 12,
                      }}
                      labelStyle={{ color: '#94a3b8' }}
                    />
                    <Line
                      type="monotone"
                      dataKey="ping"
                      stroke="#34d399"
                      strokeWidth={2}
                      dot={false}
                      isAnimationActive={false}
                      connectNulls
                    />
                  </LineChart>
                </ResponsiveContainer>
              ) : (
                <p className="flex h-full items-center justify-center text-xs text-slate-600">
                  Noch nicht genug Datenpunkte.
                </p>
              )}
            </div>
          </section>

          {/* Konsole - nur Java */}
          {a.edition === 'java' && (
            <section>
              <h3 className="mb-2 text-sm font-semibold text-slate-300">Befehl senden</h3>
              <div className="flex gap-2">
                <input
                  className="field font-mono"
                  placeholder="z.B. status, queueStatus, chat ..."
                  value={command}
                  onChange={(e) => setCommand(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') void run();
                  }}
                  disabled={busy}
                />
                <button className="btn-primary" onClick={() => void run()} disabled={busy || !command.trim()}>
                  Senden
                </button>
              </div>
              {result && (
                <pre className="thin-scroll mt-2 max-h-48 overflow-auto rounded-lg border border-base-750 bg-base-900 p-3 font-mono text-xs text-slate-300">
                  {result.ok ? result.output : result.error}
                </pre>
              )}
            </section>
          )}

          {/* Log */}
          <section>
            <h3 className="mb-2 text-sm font-semibold text-slate-300">Log</h3>
            <pre
              ref={logRef}
              className="thin-scroll max-h-72 overflow-auto rounded-lg border border-base-750 bg-base-900 p-3 font-mono text-[11px] leading-relaxed text-slate-400"
            >
              {detail.log.length > 0
                ? detail.log.join('\n')
                : 'Noch keine Logausgabe. Für Java-Accounts erscheint sie, sobald die Instanz läuft.'}
            </pre>
          </section>
        </div>
      </div>
    </Overlay>
  );
}

function AuthPanel({
  detail,
  onReauth,
  busy,
}: {
  detail: AccountDetail;
  onReauth: () => void;
  busy: boolean;
}) {
  const { auth } = detail;
  if (auth.status === 'ready') {
    return (
      <div className="rounded-lg border border-emerald-900 bg-emerald-950/30 px-4 py-3 text-sm text-emerald-300">
        Angemeldet{auth.profileName ? ` als ${auth.profileName}` : ''}.
      </div>
    );
  }

  if (auth.status === 'waiting' && auth.deviceCode) {
    const expired = Date.now() > auth.deviceCode.expiresAt;
    return (
      <div className="rounded-lg border border-amber-800 bg-amber-950/30 p-4">
        <h3 className="mb-2 text-sm font-semibold text-amber-200">
          {expired ? 'Anmeldecode abgelaufen' : 'Anmeldung nötig'}
        </h3>
        {expired ? (
          <>
            <p className="mb-3 text-xs text-amber-300/80">
              Der Code ist abgelaufen. Fordere einen neuen an.
            </p>
            <button className="btn-ghost btn-sm" onClick={onReauth} disabled={busy}>
              Neuen Code holen
            </button>
          </>
        ) : (
          <>
            <p className="mb-3 text-xs text-amber-300/80">
              Öffne den Link, trag den Code ein und bestätige bei Microsoft. Der Bot wartet.
            </p>
            <div className="flex flex-wrap items-center gap-3">
              <code className="rounded-lg bg-base-900 px-4 py-2 font-mono text-xl tracking-widest text-amber-100">
                {auth.deviceCode.userCode}
              </code>
              <a
                className="btn-primary btn-sm"
                href={auth.deviceCode.verificationUriComplete ?? auth.deviceCode.verificationUri}
                target="_blank"
                rel="noreferrer"
              >
                Microsoft-Anmeldung öffnen
              </a>
              <button className="btn-ghost btn-sm" onClick={onReauth} disabled={busy}>
                Neu anmelden
              </button>
            </div>
          </>
        )}
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-base-700 bg-base-800 p-4">
      <h3 className="mb-1 text-sm font-semibold text-slate-300">Xbox-Anmeldung</h3>
      <p className="mb-3 text-xs text-slate-500">
        {auth.status === 'failed'
          ? (auth.error ?? 'Die Anmeldung ist fehlgeschlagen.')
          : 'Dieser Account ist noch nicht bei Microsoft angemeldet.'}
      </p>
      <button className="btn-primary btn-sm" onClick={onReauth} disabled={busy}>
        Anmeldung starten
      </button>
    </div>
  );
}

function Metric({ label, value, title }: { label: string; value: string; title?: string }) {
  return (
    <div className="rounded-lg border border-base-750 bg-base-800 px-3 py-2" title={title}>
      <div className="text-[10px] uppercase tracking-wide text-slate-600">{label}</div>
      <div className="font-mono text-sm text-slate-300">{value}</div>
    </div>
  );
}

function Overlay({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div onClick={(e) => e.stopPropagation()}>{children}</div>
    </div>
  );
}
