import path from 'node:path';

function env(key: string, fallback: string): string {
  const v = process.env[key];
  return v === undefined || v === '' ? fallback : v;
}

function envInt(key: string, fallback: number): number {
  const v = process.env[key];
  if (v === undefined || v === '') return fallback;
  const n = Number.parseInt(v, 10);
  return Number.isFinite(n) ? n : fallback;
}

const dataDir = path.resolve(env('DATA_DIR', '/data'));

export const config = {
  dataDir,
  /** Alles Instanzspezifische liegt hier, nicht im Image. */
  instanceRoot: env('INSTANCE_ROOT', path.join(dataDir, 'instances')),
  /** Optionales Verzeichnis mit bereits entpackten ZenithProxy-Launchern. */
  launcherCacheDir: env('LAUNCHER_CACHE_DIR', path.join(dataDir, 'launcher-cache')),

  /**
   * Optionales Verzeichnis mit den Artefakten, die sonst aus dem Netz
   * geholt wuerden. Liegt dort eine `launcher.zip` oder eine `web-api.jar`,
   * wird sie benutzt und nichts heruntergeladen - praktisch fuer Server ohne
   * Internetzugang oder wenn GitHub nicht erreichbar ist.
   */
  seedDir: env('SEED_DIR', '/app/seed'),

  port: envInt('DASHBOARD_PORT', 3000),
  host: env('DASHBOARD_HOST', '0.0.0.0'),
  timezone: env('TZ', 'Europe/Berlin'),

  /** 32-Byte-Key (hex oder base64) fuer die Verschluesselung der Login-Secrets. */
  encryptionKey: env('ENCRYPTION_KEY', ''),

  /** Wo das gebaute Frontend liegt. */
  webDist: path.resolve(env('WEB_DIST', path.resolve(__dirname, '../../web/dist'))),

  /** Erste Anmeldung: Passwort wird erzeugt und ins Log geschrieben. */
  bootstrapUser: env('BOOTSTRAP_USER', 'admin'),

  /** Intervall fuer den Statusabruf pro Instanz (ZenithProxy erlaubt 30/min). */
  statusPollMs: envInt('STATUS_POLL_MS', 60_000),
  /** Wie lange ein Instanzprozess tot sein darf, bevor der Watchdog eingreift. */
  watchdogIntervalMs: envInt('WATCHDOG_INTERVAL_MS', 30_000),
  sessionTtlMs: envInt('SESSION_TTL_MS', 7 * 24 * 60 * 60 * 1000),

  zenith: {
    launcherZipUrl: env(
      'ZENITH_LAUNCHER_URL',
      'https://github.com/rfresh2/ZenithProxy/releases/download/launcher-v3/ZenithProxy-launcher-linux-amd64.zip',
    ),
    mcVersion: env('ZENITH_MC_VERSION', '1.21.4'),
    // "java" ist zwingend: nur dieser Channel unterstuetzt Plugins, und das
    // WebAPI-Plugin ist ein Plugin. "linux" waere 250 MB statt 600 MB,
    // laesst sich aber nicht per HTTP steuern.
    platform: env('ZENITH_PLATFORM', 'java'),
    /** Plugin-Id laut registerConfig() in WebApiPlugin.java */
    webApiPluginId: 'web-api',
    /** Wie lange wir auf eine antwortende Web-API warten, bevor wir auf
     *  Log-Parsing zurueckfallen. */
    startupProbeMs: envInt('ZENITH_STARTUP_PROBE_MS', 90_000),
  },

  bedrock: {
    defaultHost: env('BEDROCK_DEFAULT_HOST', '2b2t.org'),
    defaultPort: envInt('BEDROCK_DEFAULT_PORT', 19132),
    /**
     * RakNet-Backend von bedrock-protocol:
     *   jsp-raknet    - reine JS-Implementierung, kein Build noetig (Standard)
     *   raknet-native - C++-Modul, schneller, braucht aber einen Compiler
     *   raknet-node   - Rust-Port
     *
     * Wir nehmen bewusst die JS-Variante: ein nativer Build im Docker-Image
     * ist eine Fehlerquelle, die sich erst beim Bauen zeigt. Wenn die
     * JS-Variante irgendwann zu langsam ist, hier umstellen.
     */
    raknetBackend: env('BEDROCK_RAKNET_BACKEND', 'jsp-raknet'),
    /** Wie oft der Bot sich bei Verlust neu verbindet. */
    reconnectDelayMs: envInt('BEDROCK_RECONNECT_DELAY_MS', 15_000),
    /**
     * Sehr dezentes Pendeln. ViaBedrock auf 2b2t macht Verhaltenspruefungen,
     * ein vollstaendig starrer Bot faellt auf. In Blocks pro Tick.
     */
    wanderAmplitude: Number(env('BEDROCK_WANDER_AMPLITUDE', '0.06')),
    wanderIntervalMs: envInt('BEDROCK_WANDER_INTERVAL_MS', 3000),
  },

  /** Reservierte Port-Bloecke pro Instanz. */
  ports: {
    mcStart: envInt('MC_PORT_START', 25565),
    mcEnd: envInt('MC_PORT_END', 25569),
    apiStart: envInt('API_PORT_START', 8081),
    apiEnd: envInt('API_PORT_END', 8085),
  },
} as const;

export const dbPath = path.join(config.dataDir, 'db.sqlite');
