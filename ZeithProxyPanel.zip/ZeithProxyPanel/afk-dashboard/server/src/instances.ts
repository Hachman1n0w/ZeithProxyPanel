/**
 * Aufraeumen des Instanzverzeichnisses beim Loeschen eines Accounts.
 *
 * Zugriffsdaten und Status liegen in SQLite, der Rest ist eine Datei pro
 * Instanz: <instanceRoot>/<accountId>/ mit dem entpackten ZenithProxy, dem Log
 * und - bei Java - dem Plugin-Cache samt Web-API-Token. Das Verzeichnis ist
 * nicht klein (rund 80 MB pro Instanz, weil der Launcher drinsteckt) und
 * enthaelt bei Bedrock die zwischengespeicherte Xbox-Anmeldung.
 *
 * `DELETE /api/accounts/:id` loescht bisher nur den Datenbankeintrag. Ohne
 * diese Funktion bliebe das Verzeichnis als Waisen zurueck: niemand kann es
 * noch erreichen, aber es belegt Plattenplatz und traegt ein vollstaendiges
 * Web-API-Token mit sich herum, das niemand mehr kennt, aber auch niemand
 * mehr widerrufen kann.
 */

import { promises as fs } from 'node:fs';
import path from 'node:path';
import { config } from './config';
import { reapInstanceProcesses } from './zenith/procs';

export interface PurgeResult {
  /** Wurde ueberhaupt ein Verzeichnis gefunden? */
  removed: boolean;
  /** Freigewordener Platz in Byte, soweit messbar. */
  freedBytes: number | null;
  /** Fehlermeldung, falls das Loeschen nicht durchging. */
  error: string | null;
}

/**
 * Verzeichnis einer Instanz entfernen, inklusive aller Prozesse darauf.
 *
 * Der Aufrufer hat den Driver bereits gestoppt. Trotzdem raeumen wir hier noch
 * einmal nach: zwischen Stopp und Loeschen kann der Watchdog den Account neu
 * gestartet haben, und ein ``rm -rf`` auf ein laufendes Instanzverzeichnis
 * liefert eine Instanz, deren JVM gerade ihre Dateien unter den Fuessen wegbekommt.
 */
export async function purgeInstance(id: string): Promise<PurgeResult> {
  // Pfad selbst bauen und nicht nur zusammenkleben: eine id aus dem Request
  // koennte "../.." enthalten, und dann waere config.instanceRoot keine
  // Schranke mehr, sondern ein Angriffspfad. Mit resolve und dem Prefix-Test
  // ist das ausgeschlossen.
  const root = path.resolve(config.instanceRoot);
  const dir = path.resolve(root, id);
  if (dir !== root && !dir.startsWith(root + path.sep)) {
    return { removed: false, freedBytes: null, error: 'Ungueltige Account-ID' };
  }

  try {
    await reapInstanceProcesses(dir);
  } catch {
    /* Prozesse liessen sich nicht immer finden - das Loeschen versuchen wir trotzdem. */
  }

  // Vorher nachsehen, statt es danach zu pruefen: `rm` mit `force: true`
  // schluckt ENOENT und meldet Erfolg, auch wenn nie ein Verzeichnis da war.
  // `removed` soll aber genau das aussagen - ein Account, der nie gestartet
  // wurde, hat keine Instanzdaten, und das ist ein Unterschied zur Loeschung.
  try {
    await fs.stat(dir);
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
      return { removed: false, freedBytes: null, error: null };
    }
    return {
      removed: false,
      freedBytes: null,
      error: `Instanzverzeichnis nicht lesbar: ${(err as Error).message}`,
    };
  }

  let freedBytes: number | null = null;
  try {
    freedBytes = await dirSize(dir);
    await fs.rm(dir, { recursive: true, force: true });
    return { removed: true, freedBytes, error: null };
  } catch (err) {
    return {
      removed: false,
      freedBytes: null,
      error: `Instanzverzeichnis konnte nicht entfernt werden: ${(err as Error).message}`,
    };
  }
}

/** Groesse eines Verzeichnisbaums, fuer die Anzeige nach dem Loeschen. */
async function dirSize(dir: string): Promise<number | null> {
  let total = 0;
  try {
    for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
      const p = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        const sub = await dirSize(p);
        if (sub !== null) total += sub;
      } else if (entry.isFile()) {
        const st = await fs.stat(p);
        total += st.size;
      }
    }
    return total;
  } catch {
    return null;
  }
}
