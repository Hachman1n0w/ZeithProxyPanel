import { execFile } from 'node:child_process';
import { createWriteStream } from 'node:fs';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { promisify } from 'node:util';
import { config } from '../config';
import { randomToken } from '../crypto';
import type { Account } from '../types';
import { patchTargetServer, writePluginConfig } from './plugin-config';

const execFileAsync = promisify(execFile);

/**
 * Verwaltung der ZenithProxy-Instanzen.
 *
 * Eine Instanz ist ein eigener Ordner mit eigener Kopie des Launchers, eigenem
 * config.json und eigenen Ports. Genau so beschreibt es das ZenithProxy-Wiki
 * unter "Running Multiple Instances".
 *
 * Das WebAPI-Plugin liest Port und authToken aus plugins/config/web-api.json
 * und legt sie beim ersten Start selbst an. Wir schreiben beides vor dem
 * Start und lesen es danach zurueck, statt zu raten - Details in
 * plugin-config.ts.
 */

export interface PluginConfig {
  enabled?: boolean;
  port?: number;
  authToken?: string;
}

export function instanceDir(account: Account): string {
  return account.authDir ?? path.join(config.instanceRoot, account.id);
}

export function configFile(dir: string): string {
  return path.join(dir, 'config.json');
}

// ------------------------------------------------------------- Launcher

let launcherReady: Promise<void> | null = null;

async function download(url: string, dest: string): Promise<void> {
  const res = await fetch(url, { redirect: 'follow' });
  if (!res.ok || !res.body) throw new Error(`Download ${url} fehlgeschlagen: HTTP ${res.status}`);
  await pipeline(Readable.fromWeb(res.body as never), createWriteStream(dest));
}

async function exists(p: string): Promise<boolean> {
  return Boolean(await fs.promises.stat(p).catch(() => null));
}

/**
 * Artefakt bereitstellen: erst der Seed (offline), sonst Download.
 *
 * Reihenfolge ist bewusst "Seed zuerst" - wer sich den Betrieb ohne Internet
 * vorbereitet hat, will nicht, dass trotzdem noch ein Netzzugriff versucht wird.
 */
async function provide(name: string, seedFile: string, url: string, dest: string): Promise<'seed' | 'download'> {
  if (await exists(seedFile)) {
    await fsp.copyFile(seedFile, dest);
    console.log(`[zenith] ${name} aus Seed-Verzeichnis: ${seedFile}`);
    return 'seed';
  }
  await download(url, dest);
  console.log(`[zenith] ${name} heruntergeladen: ${url}`);
  return 'download';
}

/** Launcher und Plugin-jar einmalig herunterladen, danach aus dem Cache kopieren. */
export function ensureAssets(): Promise<void> {
  if (launcherReady) return launcherReady;
  launcherReady = (async () => {
    await fsp.mkdir(config.launcherCacheDir, { recursive: true });

    const launcherDir = path.join(config.launcherCacheDir, 'launcher');
    if (!(await exists(path.join(launcherDir, 'launch')))) {
      const zip = path.join(config.launcherCacheDir, 'launcher.zip');
      await provide(
        'ZenithProxy-Launcher',
        path.join(config.seedDir, 'launcher.zip'),
        config.zenith.launcherZipUrl,
        zip,
      );
      await fsp.rm(launcherDir, { recursive: true, force: true });
      await fsp.mkdir(launcherDir, { recursive: true });
      await execFileAsync('unzip', ['-q', '-o', zip, '-d', launcherDir]);
      await fsp.chmod(path.join(launcherDir, 'launch'), 0o755).catch(() => {
        // Manche Packs haben den Launcher anders benannt - dann nehmen wir das
        // erste ausfuehrbare File im Ordner.
        throw new Error('launcher: Datei "launch" nicht gefunden oder nicht ausfuehrbar');
      });
    }

    const pluginJar = path.join(config.launcherCacheDir, 'web-api.jar');
    if (!(await exists(pluginJar))) {
      await provide(
        'WebAPI-Plugin',
        path.join(config.seedDir, 'web-api.jar'),
        await resolvePluginUrl(),
        pluginJar,
      );
    }
  })().catch((err) => {
    launcherReady = null; // beim naechsten Versuch erneut versuchen
    throw err;
  });
  return launcherReady;
}

/**
 * Aktuelles WebAPI-Plugin-Jar ermitteln. Standardmaessig das neueste Release;
 * per ZENITH_WEBAPI_PLUGIN_URL ueberschreibbar, falls eine feste Version
 * gewuenscht ist.
 */
async function resolvePluginUrl(): Promise<string> {
  const override = process.env.ZENITH_WEBAPI_PLUGIN_URL;
  if (override) return override;
  const api = process.env.ZENITH_WEBAPI_PLUGIN_API ?? 'https://api.github.com/repos/rfresh2/ZenithProxyWebAPI/releases/latest';
  const res = await fetch(api, { headers: { 'User-Agent': 'afk-dashboard' } });
  if (!res.ok) throw new Error(`Plugin-Release nicht ermittelbar: HTTP ${res.status}`);
  const json = (await res.json()) as { assets?: Array<{ name: string; browser_download_url: string }> };
  const asset = json.assets?.find((a) => a.name.endsWith('.jar'));
  if (!asset) throw new Error('Kein .jar im neuesten WebAPI-Plugin-Release gefunden');
  return asset.browser_download_url;
}

// -------------------------------------------------------------- Instanz

/**
 * Instanzordner vorbereiten: Launcher kopieren, Plugin installieren, Config
 * anlegen falls noch nicht vorhanden.
 */
export async function prepareInstance(account: Account, webapiToken: string): Promise<string> {
  await ensureAssets();
  const dir = instanceDir(account);
  await fsp.mkdir(path.join(dir, 'plugins'), { recursive: true });

  // Launcher-Dateien kopieren (ueberspringen was schon da ist)
  const launcherDir = path.join(config.launcherCacheDir, 'launcher');
  for (const entry of await fsp.readdir(launcherDir)) {
    const target = path.join(dir, entry);
    if (await fs.promises.stat(target).catch(() => null)) continue;
    await fsp.cp(path.join(launcherDir, entry), target, { recursive: true });
  }
  await fsp.chmod(path.join(dir, 'launch'), 0o755).catch(() => {});

  // Plugin-jar nach plugins/
  const jarSrc = path.join(config.launcherCacheDir, 'web-api.jar');
  await fsp.copyFile(jarSrc, path.join(dir, 'plugins', 'web-api.jar')).catch(() => {});

  // Plugin-Config schreiben. Wichtig: das Plugin liest
  // plugins/config/web-api.json, nicht config.json. Siehe plugin-config.ts.
  await writePluginConfig(dir, {
    port: account.webapiPort ?? 8080,
    token: webapiToken,
  });

  // Zielserver und Spielnamen in config.json hinterlegen, damit die Instanz
  // ueberhaupt dorthin verbindet, wo das Konto hin soll.
  await patchTargetServer(dir, {
    host: account.serverHost,
    port: account.serverPort,
    username: account.username,
  });

  return dir;
}

// ------------------------------------------------- Config auslesen

export async function readJson(file: string): Promise<Record<string, unknown> | null> {
  try {
    return JSON.parse(await fsp.readFile(file, 'utf8')) as Record<string, unknown>;
  } catch {
    return null;
  }
}

// readPluginConfig liegt bewusst in plugin-config.ts - dort steht auch, warum
// plugins/config/web-api.json die richtige Quelle ist und config.json nicht.
export { readPluginConfig } from './plugin-config';

// ---------------------------------------------------------------- Helfer

export function newWebapiToken(): string {
  return randomToken(24);
}

export async function instanceExists(dir: string): Promise<boolean> {
  return Boolean(await fs.promises.stat(path.join(dir, 'launch')).catch(() => null));
}

/** Log-Verzeichnis eines Instances - je nach ZenithProxy-Version `logs` oder `log`. */
export async function findLogFile(dir: string): Promise<string | null> {
  for (const sub of ['logs', 'log', '.']) {
    const full = path.join(dir, sub);
    const stat = await fs.promises.stat(full).catch(() => null);
    if (!stat?.isDirectory()) continue;
    const entries = await fsp.readdir(full).catch(() => []);
    const logs = entries.filter((e) => e.endsWith('.log')).sort();
    if (logs.length > 0) return path.join(full, logs[logs.length - 1]!);
  }
  return null;
}

/** stdout/stderr des Prozesses als Logdatei - immer verfuegbar, unabhaengig
 *  davon wo ZenithProxy selbst seine Logs ablegt. */
export function processLogPath(dir: string): string {
  return path.join(dir, 'instance.log');
}
