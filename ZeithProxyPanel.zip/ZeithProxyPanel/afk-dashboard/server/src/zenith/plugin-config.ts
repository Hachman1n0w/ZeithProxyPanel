import fsp from 'node:fs/promises';
import path from 'node:path';
import { config } from '../config';
import { readJson, type PluginConfig } from './launcher';

/**
 * Das WebAPI-Plugin liest seine Einstellungen NICHT aus config.json, sondern
 * aus einer eigenen Datei neben dem Jar:
 *
 *     <instanz>/plugins/config/web-api.json
 *
 * Das ist gegen die uebliche Erwartung und hat uns initially einen Stillstand
 * eingebrockt: Wir haben Port und Token nach config.json geschrieben, das
 * Plugin hat sie ignoriert, auf Port 8080 mit einem selbst erzeugten Token
 * gelauscht, und jede Anfrage aus dem Dashboard wurde mit "Invalid auth token"
 * abgelehnt - ohne dass irgendwo ein Fehler sichtbar gewesen waere.
 *
 * Deshalb liegt die Wahrheit hier an einer Stelle, und beides wird geschrieben:
 * plugins/config/web-api.json ist der Ort, an dem das Plugin wirklich liest.
 */

export function pluginConfigFile(dir: string): string {
  return path.join(dir, 'plugins', 'config', 'web-api.json');
}

/**
 * Port und Token in die Plugin-Config schreiben, ohne fremde Eintraege zu
 * verlieren. Das Plugin legt beim ersten Start selbst eine Datei an (mit
 * logRetentionEntries, commandsAccountOwnerPerms und Co.) - die Felder
 * uebernehmen wir und aendern nur, was uns gehoert.
 */
export async function writePluginConfig(
  dir: string,
  opts: { port: number; token: string },
): Promise<void> {
  const file = pluginConfigFile(dir);
  const existing = (await readJson(file)) ?? {};
  const merged = {
    ...existing,
    enabled: true,
    port: opts.port,
    authToken: opts.token,
    // Kein Web-UI: das waere eine zweite, ungeschuetzte Oberflaeche fuer
    // dieselben Befehle, die das Dashboard ohnehin ueber die API sendet.
    webUI: false,
    rateLimiter: true,
    rateLimitRequestsPerMinute: 30,
    // Ohne das verweigert die Web-API Befehle, die Account-Owner-Rechte
    // brauchen - etwa alles rund um die Zuschauer-Whitelist ("Not Authorized!
    // Web API is not authorized to execute this command!"). Das Token liegt
    // nur auf dem Server und kommt nie zum Browser; was das Dashboard darf,
    // darf es ganz.
    commandsAccountOwnerPerms: true,
  };
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(merged, null, 2), 'utf8');
  await fsp.rename(tmp, file);
}

/**
 * Port und Token der laufenden Instanz ermitteln.
 *
 * Reihenfolge: die echte Plugin-Datei zuerst. config.json dient nur noch als
 * Rueckfall, falls eine kuenftige ZenithProxy-Version das wieder umstellt -
 * dann finden wir den Token wenigstens und melden "nicht erreichbar" statt
 * still falsch zu liegen.
 */
export async function readPluginConfig(dir: string): Promise<PluginConfig | null> {
  const fromPlugin = await readJson(pluginConfigFile(dir));
  if (fromPlugin) {
    const hit = section(fromPlugin);
    if (hit) return hit;
  }

  // Rueckfallpfad: die Sektion steckt in config.json unter "plugin" oder
  // "plugins", je nach Version tief verschachtelt.
  const fromMain = await readJson(path.join(dir, 'config.json'));
  if (fromMain) {
    const hit = findSection(fromMain);
    if (hit) return hit;
  }
  return null;
}

function section(node: Record<string, unknown>): PluginConfig | null {
  const token = node.authToken;
  if (typeof token !== 'string' || token.length === 0) return null;
  return {
    enabled: node.enabled === undefined ? true : node.enabled === true,
    port: typeof node.port === 'number' ? node.port : undefined,
    authToken: token,
  };
}

function findSection(node: unknown): PluginConfig | null {
  if (Array.isArray(node)) {
    for (const item of node) {
      const hit = findSection(item);
      if (hit) return hit;
    }
    return null;
  }
  if (!node || typeof node !== 'object') return null;
  const obj = node as Record<string, unknown>;
  const direct = section(obj);
  if (direct) return direct;
  for (const value of Object.values(obj)) {
    const hit = findSection(value);
    if (hit) return hit;
  }
  return null;
}

/**
 * Zielserver und Spielname in config.json hinterlegen.
 *
 * ZenithProxy liest den Zielserver aus client.server - nicht aus dem, was wir
 * dem Plugin geben, und nicht aus einer Umgebungsvariablen. Ohne das hier
 * verbindet sich jede Instanz zu dem, was in der Datei steht (frisch
 * installiert: 2b2t.org), unabhaengig davon, was im Konto hinterlegt ist.
 */
export async function patchTargetServer(
  dir: string,
  target: { host: string; port: number; username?: string },
): Promise<void> {
  const file = path.join(dir, 'config.json');
  const cfg = (await readJson(file)) as Record<string, unknown> | null;
  if (!cfg) return;

  const client = (cfg.client ?? {}) as Record<string, unknown>;
  const server = (client.server ?? {}) as Record<string, unknown>;
  server.address = target.host;
  server.port = target.port;
  client.server = server;
  if (target.username) client.username = target.username;
  // autoConnect bleibt aus: connect steuern wir ueber die Web-API, damit der
  // Status sichtbar bleibt und wir nicht blind in die Queue springen.
  client.autoConnect = false;
  cfg.client = client;

  const tmp = `${file}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(cfg, null, 2), 'utf8');
  await fsp.rename(tmp, file);
}
