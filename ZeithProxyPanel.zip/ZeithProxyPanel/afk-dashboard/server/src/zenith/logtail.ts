import fs from 'node:fs';
import type { AccountStatus } from '../types';

/**
 * Notfall-Statusquelle: Status aus dem Logfile statt aus der Web-API.
 *
 * Warum das ueberhaupt noetig ist: das WebAPI ist ein *Plugin* und laeuft nur
 * auf dem "java"-Channel. Sollte es beim Start nicht laden (Version falsch,
 * Plugin nicht geladen, Port belegt), faellt der Treiber hier zurueck statt den
 * Account blind zu lassen.
 *
 * Die Erkennung ist bewusst zurueckhaltend - sie liefert weniger und
 * verlaesslicher. Genau das wird im UI als source: "logtail" angezeigt, damit
 * klar ist, dass die Werte geraten sind.
 */

interface Signal {
  state: AccountStatus['state'];
  matchedAt: number;
}

const PATTERNS: Array<{ re: RegExp; state: AccountStatus['state'] }> = [
  { re: /login (failed|error)/i, state: 'error' },
  { re: /\bexception\b|\bfatal\b/i, state: 'error' },
  { re: /you (were|have been) (kicked|banned)/i, state: 'stopped' },
  { re: /\bdisconnect(ing|ed)?\b/i, state: 'starting' },
  { re: /(connected to|successfully connected|joined the game|logged in)/i, state: 'online' },
  { re: /connecting to/i, state: 'connecting' },
  { re: /logging in/i, state: 'connecting' },
  { re: /waiting for (queue|connection)/i, state: 'queued' },
];

export class LogTailer {
  private buffer: string[] = [];
  private last: Signal | null = null;
  private watchers = new Map<string, fs.FSWatcher>();
  private static readonly MAX_LINES = 400;

  /** Neue Zeilen anhaengen. Wird auf stdout/stderr des Prozesses gefuehrt. */
  push(chunk: string): void {
    for (const line of chunk.split('\n')) {
      const trimmed = line.trim();
      if (!trimmed) continue;
      this.buffer.push(trimmed);
      if (this.buffer.length > LogTailer.MAX_LINES) this.buffer.shift();
      for (const p of PATTERNS) {
        if (p.re.test(trimmed)) {
          this.last = { state: p.state, matchedAt: Date.now() };
          break;
        }
      }
    }
  }

  /** Zusaetzlich eine Logdatei beobachten, falls ZenithProxy selbst loggt. */
  watch(file: string): void {
    if (this.watchers.has(file)) return;
    try {
      const watcher = fs.watch(file, { persistent: false }, (_event, change) => {
        if (change === 'rename') {
          this.unwatch(file);
          return;
        }
        const tail = readTail(file, 64);
        if (tail) this.push(tail);
      });
      this.watchers.set(file, watcher);
    } catch {
      /* Logdatei noch nicht da - unkritisch */
    }
  }

  unwatch(file: string): void {
    this.watchers.get(file)?.close();
    this.watchers.delete(file);
  }

  close(): void {
    for (const w of this.watchers.values()) w.close();
    this.watchers.clear();
    this.buffer = [];
    this.last = null;
  }

  recentLines(n = 80): string[] {
    return this.buffer.slice(-n);
  }

  status(running: boolean): AccountStatus {
    const now = Date.now();
    if (!running) {
      return {
        state: 'stopped',
        connectedPlayer: null,
        // Ohne laufenden Proxy gibt es keine Adresse, auf der etwas lauscht.
        proxyIp: null,
        nearby: null,
        ping: null,
        health: null,
        position: null,
        dimension: null,
        queue: null,
        playtimeSec: null,
        source: 'logtail',
        authUrl: null,
        lastError: null,
        updatedAt: now,
      };
    }

    // Ein Signal aelter als 5 Minuten gilt als unzuverlaessig.
    const fresh = this.last && now - this.last.matchedAt < 5 * 60_000 ? this.last : null;
    const state = fresh ? fresh.state : 'starting';
    return {
      state,
      connectedPlayer: null,
      // Aus dem Log laesst sich die Lauscher-Adresse nicht zuverlaessig
      // ablesen - da steht sie nicht drin.
      proxyIp: null,
      nearby: null,
      ping: null,
      health: null,
      position: null,
      dimension: null,
      queue: null,
      playtimeSec: null,
      source: 'logtail',
      authUrl: null,
      lastError: state === 'error' ? 'Im Log gefunden - siehe Account-Log' : null,
      updatedAt: now,
    };
  }
}

function readTail(file: string, bytes: number): string | null {
  try {
    const fd = fs.openSync(file, 'r');
    try {
      const size = fs.statSync(file).size;
      const len = Math.min(bytes, size);
      const buf = Buffer.alloc(len);
      fs.readSync(fd, buf, 0, len, size - len);
      return buf.toString('utf8');
    } finally {
      fs.closeSync(fd);
    }
  } catch {
    return null;
  }
}
