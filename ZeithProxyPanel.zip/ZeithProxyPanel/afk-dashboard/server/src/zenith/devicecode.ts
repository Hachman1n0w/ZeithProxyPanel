/**
 * Der Microsoft-Geraetecode aus dem ZenithProxy-Log.
 *
 * ZenithProxy schreibt bei `auth type deviceCode` unter anderem diese Zeile:
 *
 *   [Auth] [ERROR] Login Here: https://www.microsoft.com/link?otc=S57XKPFP with code: S57XKPFP
 *
 * Wir greifen die URL mit dem ?otc=-Parameter ab, weil sie den Code bereits
 * vollstaendig enthaelt - ein Klick genuegt, und der Code muss nicht abgetippt
 * werden. Die Zeile steht nur im Log der Instanz; ohne dieses Abgreifen muesste
 * man das Log aufklappen, um herauszufinden, worauf die Instanz gerade wartet.
 */

/** Muster fuer die Logzeile mit URL und Code. */
const CODE_LINE = /Login Here:\s*(\S+)\s+with code:\s*(\S+)/i;
/**
 * Variante ohne "with code": der Code steht dann nur als otc-Parameter in der
 * URL. Kommt vor, wenn die Zeile umbrochen wurde.
 */
const URL_ONLY_LINE = /Login Here:\s*(\S+)/i;

export interface ParsedDeviceCode {
  code: string;
  url: string;
  foundAt: number;
}

/**
 * Einen Geraetecode aus Logtext ziehen. Gibt null zurueck, wenn noch keiner
 * da ist - das ist der Normalfall direkt nach dem Start.
 */
export function parseDeviceCode(text: string): ParsedDeviceCode | null {
  const withCode = text.match(CODE_LINE);
  if (withCode?.[1] && withCode[2]) {
    return { url: withCode[1], code: withCode[2], foundAt: Date.now() };
  }
  const urlOnly = text.match(URL_ONLY_LINE);
  if (urlOnly?.[1]) {
    const code = codeFromUrl(urlOnly[1]);
    if (code) return { url: urlOnly[1], code, foundAt: Date.now() };
  }
  return null;
}

/** Den otc-Parameter aus der Microsoft-Link-URL ziehen. */
function codeFromUrl(url: string): string | null {
  try {
    return new URL(url).searchParams.get('otc');
  } catch {
    return null;
  }
}

/**
 * Logzeilen, die eine erfolgreiche Anmeldung melden. Ab da ist der Code
 * erledigt und darf aus dem Status verschwinden - sonst haengt er als
 * abgelaufener Hinweis weiter in der Kartenansicht, waehrend der Account
 * längst laeuft.
 */
const LOGGED_IN = /\[\s*Auth\s*\].*(Logged in|Login successful|Successfully logged in)/i;

/** true, sobald der Log eine fertige Anmeldung meldet. */
export function isLoggedIn(text: string): boolean {
  return LOGGED_IN.test(text);
}

/**
 * Status um den Anmeldelink ergaenzen.
 *
 * Der Link wandert bewusst nach `authUrl` und nicht nach `lastError`: er ist
 * kein Fehler, sondern eine noetige Nutzeraktion. In `lastError` wuerde er als
 * roter Fehler erscheinen und die echten Fehler daneben unauffindbar machen.
 *
 * Nur die URL, nicht der Code: die URL traegt den Code im otc-Parameter
 * bereits mit sich. Ein zusaetzlich angezeigter Code waere nur ein zweiter Weg,
 * der schiefgehen kann (abgetippt statt geklickt), ohne etwas zu gewinnen.
 */
export function withAuthUrl<T extends { authUrl: string | null }>(
  status: T,
  parsed: ParsedDeviceCode | null,
): T {
  if (!parsed) return status;
  return { ...status, authUrl: parsed.url };
}
