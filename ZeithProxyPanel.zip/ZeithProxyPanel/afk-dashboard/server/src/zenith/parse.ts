/**
 * Parser fuer die Ausgabe des ZenithProxy-Befehls `status`.
 *
 * Die Antwort kommt als Klartext in drei Formen:
 *   embed           - eine flache Textausgabe mit \n
 *   multiLineOutput - dasselbe als Array von Zeilen
 *   embedComponent  - Kyori-Adventure-JSON
 *
 * Wir nutzen multiLineOutput, sonst embed. Das Adventure-JSON muesste man mit
 * einem vollstaendigen Adventure-Parser zerlegen - dafuer ist der Klartext
 * deutlich robuster, solange man die Labels kennt.
 *
 * Format ist "Label\nWert", wobei ein Wert auch mehrere Zeilen haben kann
 * (z.B. "2b2t Queue" mit Priority und Regular). Deshalb parsen wir labelweise
 * statt paarweise.
 */

const LABELS = new Set<string>([
  'Status',
  'Connected Player',
  // "Online For" gab es in aelteren ZenithProxy-Versionen, "Online Duration"
  // ist der Name aus 3.7.x. Beide stehen hier, weil wir die Label-Liste nicht
  // an genau einer Version festnageln wollen.
  'Online For',
  'Online Duration',
  'Uptime',
  'Health',
  'Dimension',
  'Ping',
  'Proxy IP',
  'Server',
  'Priority Queue',
  'Spectators',
  '2b2t Queue',
  'Coordinates',
  'AutoUpdate',
  'Channel',
  'Version',
  'Spectator Entity',
  'Player Cam',
  'Tick Rate',
]);

/**
 * Werte, die nie ein Label einleiten, sondern immer zum Feld davor gehoeren.
 *
 * Das ist nur ein Rueckfallnetz fuer den Fall, dass ZenithProxy eine
 * unbekannte Label-Zeile ausgibt: eine reine Wortzeile wie "Uptime" soll dann
 * als neues Feld gelten und nicht den Wert des Vorgängerfeldes verfaelschen.
 * Bekannte Werte wie "Online" sehen genauso aus und muessen deshalb
 * ausdruecklich ausgenommen werden - sonst wuerde der Wert von "Status" sein
 * eigenes neues Feld werden.
 */
const KNOWN_VALUES = new Set<string>([
  'online',
  'connected',
  'disconnected',
  'connecting',
  'logged in',
  'not online',
  'none',
  'yes',
  'no',
  'on',
  'off',
]);

/**
 * Sieht eine Zeile wie ein Feldname aus? Nur Buchstaben, Ziffern und ein paar
 * Trennzeichen, kurz, und ohne Doppelpunkt - die typischen Werte sehen anders
 * aus ("29ms", "00:04:06", "Priority: 1 [00:03:19]", "[-217197, 99, 141060]").
 */
function looksLikeLabel(line: string): boolean {
  if (!/^[A-Za-z0-9][A-Za-z0-9 ._/-]{0,23}$/.test(line)) return false;
  if (!/[A-Za-z]/.test(line)) return false;
  return !KNOWN_VALUES.has(line.toLowerCase());
}

export type RawStatus = Record<string, string>;

export function parseZenithOutput(payload: {
  embed?: string;
  multiLineOutput?: string[];
  embedComponent?: string;
}): RawStatus {
  const lines: string[] = Array.isArray(payload.multiLineOutput)
    ? payload.multiLineOutput
    : typeof payload.embed === 'string'
      ? payload.embed.split('\n')
      : [];

  const out: RawStatus = {};
  let current: string | null = null;

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;

    if (LABELS.has(line) || (current !== null && out[current] && looksLikeLabel(line))) {
      // Bereits bekanntes Feld, oder eine unbekannte Label-Zeile. Letztere
      // faengt ZenithProxy-Versionen ab, die Felder ergaenzt haben, die wir
      // noch nicht kennen - sonst wuerde ihr Name im Wert des Vorgängers
      // landen und diesen unlesbar machen.
      current = line;
      if (!(line in out)) out[line] = '';
      continue;
    }

    // Die erste Zeile ist die Version-Kopfzeile ("ZenithProxy 1.2.3 - linux").
    if (current === null) {
      out.Version = line;
      continue;
    }
    out[current] = out[current] ? `${out[current]}\n${line}` : line;
  }

  return out;
}

// ------------------------------------------------------------- Einzelwerte

export function parsePing(raw: string | undefined): number | null {
  if (!raw) return null;
  const m = raw.match(/(\d+(?:\.\d+)?)\s*ms/i);
  return m ? Number.parseFloat(m[1]!) : null;
}

export function parseHealth(raw: string | undefined): number | null {
  if (!raw) return null;
  const n = Number.parseFloat(raw);
  return Number.isFinite(n) ? n : null;
}

/** "00:12:34" oder "1:02:03" -> Sekunden. */
export function parseDuration(raw: string | undefined): number | null {
  if (!raw) return null;
  if (/not online/i.test(raw)) return null;
  const parts = raw.trim().split(':').map((p) => Number.parseInt(p, 10));
  if (parts.some((n) => !Number.isFinite(n))) return null;
  if (parts.length === 3) return parts[0]! * 3600 + parts[1]! * 60 + parts[2]!;
  if (parts.length === 2) return parts[0]! * 60 + parts[1]!;
  if (parts.length === 1) return parts[0]!;
  return null;
}

/** "||[123, 64, -456]||" -> Vec3. */
export function parseCoords(raw: string | undefined): { x: number; y: number; z: number } | null {
  if (!raw) return null;
  const m = raw.match(/\[\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)\s*\]/);
  if (!m) return null;
  return { x: Number.parseFloat(m[1]!), y: Number.parseFloat(m[2]!), z: Number.parseFloat(m[3]!) };
}

export interface ParsedQueue {
  priority: number | null;
  regular: number | null;
  /**
   * 2b2t gibt in `status` nur die Anzahlen aus, nicht die eigene Position.
   * Wir nehmen den hoeheren Wert als grobe Naeherung und markieren das im UI.
   * Wer es genau braucht, nutzt den Befehl `queueStatus`.
   */
  position: number | null;
}

export function parseQueue(raw: string | undefined): ParsedQueue | null {
  if (!raw) return null;
  const priorityMatch = raw.match(/Priority:\s*(\d+)/i);
  const regularMatch = raw.match(/Regular:\s*(\d+)/i);
  const priority = priorityMatch ? Number.parseInt(priorityMatch[1]!, 10) : null;
  const regular = regularMatch ? Number.parseInt(regularMatch[1]!, 10) : null;
  if (priority === null && regular === null) return null;
  const position = Math.max(priority ?? 0, regular ?? 0) || null;
  return { priority, regular, position };
}

/** "no [unbanned]" / "yes" / "unknown" -> boolean|null */
export function parsePriorityQueue(raw: string | undefined): boolean | null {
  if (!raw) return null;
  if (/^yes/i.test(raw)) return true;
  if (/^no/i.test(raw)) return false;
  return null;
}

export function parseDimension(raw: string | undefined): string | null {
  if (!raw) return null;
  if (/^none$/i.test(raw.trim())) return null;
  return raw.trim();
}

export function parseConnectedPlayer(raw: string | undefined): string | null {
  if (!raw) return null;
  const v = raw.trim();
  if (!v || /^none$/i.test(v)) return null;
  return v;
}

/** Server-Adresse in host:port zerlegen, damit der Dashboard sie anzeigen kann. */
export function parseServerAddress(raw: string | undefined): { host: string; port: number } | null {
  if (!raw) return null;
  const m = raw.trim().match(/^(.+):(\d+)$/);
  if (!m) return { host: raw.trim(), port: 25565 };
  return { host: m[1]!, port: Number.parseInt(m[2]!, 10) };
}

/**
 * Die "Proxy IP" aus dem Status uebernehmen.
 *
 * ZenithProxy meldet sie selbst, meist als "127.0.0.1:25565". Wir nehmen
 * bewusst exakt diese Angabe und nicht die konfigurierte mcPort: die
 * konfigurierte Zahl ist nur der Wunsch, die gemeldete ist die Tatsache. Wenn
 * der Port belegt war und ZenithProxy auf einen ausgewichen ist, steht hier
 * der echte - und genau den muss ein Tunnel durchreichen.
 *
 * Ohne Port wird keiner ergaenzt: ein "127.0.0.1" ohne Port ist keine
 * brauchbare Adresse zum Kopieren, und stillschweigend 25565 anzunehmen
 * erzeugt eine Adresse, auf die sich niemand verbinden kann.
 */
export function parseProxyIp(raw: string | undefined): string | null {
  if (!raw) return null;
  const v = raw.trim();
  if (!v || /^none$/i.test(v)) return null;
  return v;
}
