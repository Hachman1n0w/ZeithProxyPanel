/**
 * Client fuer das ZenithProxyWebAPI-Plugin.
 *
 * Endpunkt: POST /api/command  mit Header "Authorization: <token>"
 * Body:      { "command": "status" }
 *
 * Das Plugin hat ab Werk einen Rate-Limiter (30 Requests/Min). Wir halten uns
 * daran mit einem Token-Bucket pro Instanz, damit wir nicht in 429 laufen.
 */

export interface ZenithResponse {
  embed?: string;
  embedComponent?: string;
  multiLineOutput?: string[];
}

export class ZenithError extends Error {
  constructor(
    message: string,
    readonly status?: number,
  ) {
    super(message);
    this.name = 'ZenithError';
  }
}

class TokenBucket {
  private tokens: number;
  private last: number;

  constructor(
    private readonly capacity: number,
    private readonly refillPerMs: number,
  ) {
    this.tokens = capacity;
    this.last = Date.now();
  }

  async take(): Promise<void> {
    for (;;) {
      const now = Date.now();
      this.tokens = Math.min(this.capacity, this.tokens + (now - this.last) * this.refillPerMs);
      this.last = now;
      if (this.tokens >= 1) {
        this.tokens -= 1;
        return;
      }
      const waitMs = Math.max(20, Math.ceil((1 - this.tokens) / this.refillPerMs));
      await new Promise((r) => setTimeout(r, waitMs));
    }
  }
}

export class ZenithClient {
  private bucket: TokenBucket;

  constructor(
    private readonly port: number,
    private readonly token: string,
    requestsPerMinute = 30,
  ) {
    this.bucket = new TokenBucket(requestsPerMinute, requestsPerMinute / 60_000);
  }

  private get baseUrl(): string {
    return `http://127.0.0.1:${this.port}`;
  }

  /** Nur im Docker-Setup: alle Instanzen teilen sich den Loopback-Namespace. */
  get endpoint(): string {
    return this.baseUrl;
  }

  private async request(pathname: string, init: RequestInit = {}, timeoutMs = 15_000): Promise<Response> {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      return await fetch(`${this.baseUrl}${pathname}`, {
        ...init,
        signal: ctrl.signal,
        headers: {
          Authorization: this.token,
          'Content-Type': 'application/json',
          ...(init.headers ?? {}),
        },
      });
    } finally {
      clearTimeout(timer);
    }
  }

  /** Einen ZenithProxy-Befehl ausfuehren und die Roh-Antwort bekommen. */
  async command(cmd: string): Promise<ZenithResponse> {
    await this.bucket.take();
    const res = await this.request('/api/command', {
      method: 'POST',
      body: JSON.stringify({ command: cmd }),
    });
    if (!res.ok) {
      const body = await res.text().catch(() => '');
      throw new ZenithError(
        `ZenithProxy antwortete mit ${res.status}: ${body.slice(0, 300)}`,
        res.status,
      );
    }
    return (await res.json()) as ZenithResponse;
  }

  /** Kurztest, ob die Web-API antwortet. Wird vom Treiber beim Start benutzt. */
  async probe(timeoutMs = 4000): Promise<boolean> {
    try {
      await this.command('status');
      return true;
    } catch {
      return false;
    }
  }
}

/** Klartext-Ausgabe aus einer Antwort ziehen - bevorzugt zeilenweise. */
export function extractText(res: ZenithResponse): string {
  if (Array.isArray(res.multiLineOutput) && res.multiLineOutput.length > 0) {
    return res.multiLineOutput.join('\n');
  }
  if (typeof res.embed === 'string') return res.embed;
  if (typeof res.embedComponent === 'string') {
    // Notloesung: die Komponente rendern, damit zumindest Text uebrig bleibt.
    return renderComponent(res.embedComponent);
  }
  return '';
}

/**
 * Minimales Rendern eines Kyori-Adventure-Components zu reinem Text.
 * Kein vollstaendiger Parser - reicht, um aus einem Response zu lesen, was
 * zur Not angezeigt werden soll.
 */
function renderComponent(json: string): string {
  try {
    const node = JSON.parse(json) as { text?: string; extra?: unknown[] };
    const parts: string[] = [];
    const walk = (n: unknown): void => {
      if (typeof n === 'string') {
        parts.push(n);
        return;
      }
      if (n && typeof n === 'object') {
        const o = n as { text?: string; extra?: unknown[] };
        if (typeof o.text === 'string') parts.push(o.text);
        if (Array.isArray(o.extra)) o.extra.forEach(walk);
      }
    };
    walk(node);
    return parts.join('');
  } catch {
    return '';
  }
}

export function defaultRequestsPerMinute(): number {
  return 30;
}
