import fs from 'node:fs/promises';
import path from 'node:path';

/**
 * ZenithProxy laeuft nicht direkt, sondern ueber ein `./launch`-Skript, das
 * wiederum eine JVM startet. Beendet man nur den direkten Kindprozess, laeuft
 * die JVM weiter: sie haelt den MC-Port, den WebAPI-Port und die `.lock` in
 * der Instanz, und jeder weitere Startversuch bricht mit "Multiple ZenithProxy
 * Instances Open" ab.
 *
 * Deshalb bekommen Instanzen eine eigene Prozessgruppe (detached) und werden
 * gruppenweise beendet. Diese Funktion ist die zweite Haelfte davon: sie raeumt
 * auf, was ein harter Abbruch (SIGKILL, Docker-Notkill, Panic) uebrig laesst.
 *
 * Linux-only, genau wie das restliche Projekt - Docker laeuft auf jammy, der
 * Entwicklungsrechner ist CachyOS.
 */

interface ProcInfo {
  pid: number;
  cmdline: string;
}

/** Alle Prozesse, deren Kommandozeile `needle` enthaelt. */
async function findProcs(needle: string): Promise<ProcInfo[]> {
  const out: ProcInfo[] = [];
  let entries: string[];
  try {
    entries = await fs.readdir('/proc');
  } catch {
    return out;
  }

  for (const entry of entries) {
    if (!/^\d+$/.test(entry)) continue;
    const pid = Number(entry);
    if (pid === process.pid) continue;

    let cmdline: string;
    try {
      // Die Kommandozeile ist NUL-getrennt; fuer unseren Zweck reicht ein
      // Ersetzen, damit der Pfad als ein zusammenhaengender String auftaucht.
      cmdline = (await fs.readFile(`/proc/${entry}/cmdline`, 'utf8')).replace(/\0/g, ' ');
    } catch {
      continue; // Prozess weg oder kein Zugriff
    }
    if (cmdline.includes(needle)) out.push({ pid, cmdline });
  }
  return out;
}

function alive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

async function waitGone(pids: number[], ms: number): Promise<boolean> {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    if (pids.every((p) => !alive(p))) return true;
    await new Promise((r) => setTimeout(r, 250));
  }
  return pids.every((p) => !alive(p));
}

/**
 * Alle Prozesse beenden, die zu dieser Instanz gehoeren, und die veraltete
 * `.lock` entfernen.
 *
 * Gibt zurueck, was beendet wurde - das taucht im Log auf, weil "Instanz
 * laeuft noch" und "Instanz haengt in einer Waise" sonst nicht unterscheidbar
 * sind.
 */
export async function reapInstanceProcesses(dir: string, timeoutMs = 8000): Promise<number[]> {
  // Der Instanzpfad kommt in beiden Kommandozeilen vor: beim `./launch` als
  // cwd nicht zwingend, bei der JVM aber als -jar-Argument. Der Zusatz
  // "ZenithProxy.jar" greift nur echte Instanzprozesse ab.
  const needle = `${path.join(dir, 'launcher')}/ZenithProxy.jar`;
  const found = await findProcs(needle);
  if (found.length === 0) {
    // Nur die `.lock` wegräumen, wenn wirklich kein Prozess laeuft - sonst
    // raeumen wir einem noch lebenden Prozess die Datei weg.
    await fs.rm(path.join(dir, '.lock'), { force: true }).catch(() => {});
    return [];
  }

  const pids = found.map((p) => p.pid);
  for (const pid of pids) {
    try {
      process.kill(pid, 'SIGTERM');
    } catch {
      /* schon weg */
    }
  }
  if (!(await waitGone(pids, timeoutMs))) {
    for (const pid of pids) {
      if (alive(pid)) {
        try {
          process.kill(pid, 'SIGKILL');
        } catch {
          /* schon weg */
        }
      }
    }
    await waitGone(pids, 2000);
  }
  await fs.rm(path.join(dir, '.lock'), { force: true }).catch(() => {});
  return pids;
}
