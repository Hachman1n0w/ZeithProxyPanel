/**
 * Die Schutz- und Automatik-Module von ZenithProxy als schaltbare Liste.
 *
 * Jedes Modul folgt derselben Konvention: `<modul> on/off` schaltet,
 * `<modul>` ohne Argument meldet den Zustand - und zwar ausfuehrlich, mit
 * allen Untereinstellungen. Die erste Zeile ist der Modulname, die zweite der
 * Zustand ("on"/"off"). Davor steht noch "Invalid command usage", weil das
 * blosse Abfragen kein gueltiger Aufruf ist - der Zustand steht trotzdem drin.
 *
 * Beispiel (echte Ausgabe von `antiAFK`):
 *
 *     Invalid command usage
 *     AntiAFK
 *     on
 *     Rotate
 *     on - Delay: 300
 *     ...
 *
 * Die Liste hier ist bewusst kuratiert statt vollstaendig: was einen Schalter
 * verdient (Schutz, Essen, Fischen, Verbindungsautomaten), steht drin. Der
 * Rest - stalk, autoReply, spammer und Co. - bleibt ueber die Konsole in der
 * Detailansicht erreichbar.
 */

export interface ModuleDef {
  /** Exakter Befehlsname in ZenithProxy. */
  id: string;
  /** Anzeigename im Dashboard. */
  label: string;
  /** Ein Satz, was der Schalter bewirkt. */
  hint: string;
}

export const MODULES: ModuleDef[] = [
  {
    id: 'antiAFK',
    label: 'Anti-AFK',
    hint: 'Bewegt den Bot (Schwingen, Laufen, Drehen), damit 2b2t ihn nicht wegen Inaktivität kickt.',
  },
  {
    id: 'antiKick',
    label: 'Anti-Kick',
    hint: 'Kickt steuernde Spieler vom Proxy, wenn sie zu lange untätig sind.',
  },
  {
    id: 'antiLeak',
    label: 'Anti-Leak',
    hint: 'Blockt Chat-Nachrichten, die versehentlich Koordinaten verraten könnten.',
  },
  {
    id: 'coordObf',
    label: 'Koordinaten-Verschleierung',
    hint: 'Zeigt zuschauenden Spielern gefälschte Koordinaten und Biome.',
  },
  {
    id: 'autoEat',
    label: 'Auto-Essen',
    hint: 'Isst automatisch, wenn Leben oder Hunger unter die Schwelle fallen.',
  },
  {
    id: 'autoFish',
    label: 'Auto-Angeln',
    hint: 'Wirft aus und holt ein. Zählt selbst als Anti-AFK - beides zusammen ist zu viel.',
  },
  // autoArmor fehlt bewusst: `autoArmor` ohne Argument meldet keinen Zustand,
  // nur die Hilfe. Ein Schalter ohne Anzeige waere blind - das Modul bleibt
  // ueber die Konsole schaltbar (`autoArmor on/off`).
  {
    id: 'autoTotem',
    label: 'Auto-Totem',
    hint: 'Steckt bei niedrigem Leben ein Totem in die Zweithand.',
  },
  {
    id: 'autoMend',
    label: 'Auto-Mending',
    hint: 'Hält beschädigte Mending-Items in der Hand zum Reparieren, z.B. an der XP-Farm.',
  },
  {
    id: 'autoRespawn',
    label: 'Auto-Respawn',
    hint: 'Respawnt automatisch nach dem Tod.',
  },
  {
    id: 'autoReconnect',
    label: 'Auto-Reconnect',
    hint: 'Verbindet den Bot nach einem Disconnect von selbst neu.',
  },
  {
    id: 'autoDisconnect',
    label: 'Auto-Disconnect',
    hint: 'Trennt bei Gefahr (wenig Leben, fremder Spieler, Totem-Pop) und optional ohne Reconnect.',
  },
  {
    id: 'autoDrop',
    label: 'Auto-Drop',
    hint: 'Wirft konfigurierte Items automatisch aus dem Inventar.',
  },
  {
    id: 'spectator',
    label: 'Zuschauer-Modus',
    hint: 'Lässt Spieler auf der Zuschauer-Liste durch die Augen des Bots zusehen.',
  },
  {
    id: 'visualRange',
    label: 'Sichtweiten-Melder',
    hint: 'Meldet, wenn Spieler in Sichtweite kommen oder gehen.',
  },
];

export function isKnownModule(id: string): boolean {
  return MODULES.some((m) => m.id === id);
}

/**
 * An/Aus aus einer Modul-Statusausgabe lesen. null, wenn das Format nicht
 * passt - dann zeigt die Oberfläche "unbekannt" statt zu raten.
 *
 * Zwei Formen kommen vor: die übliche (Modulname, dann "on"/"off" in der
 * naechsten Zeile) und antiKick mit `Enabled` / `Off!` - inklusive
 * Ausrufezeichen. Beides ist verifiziert, der Rest ist raten und liefert null.
 */
export function parseModuleState(text: string): boolean | null {
  const lines = stripAnsi(text)
    .split('\n')
    .map((l) => l.trim())
    .filter((l) => l.length > 0 && !/^invalid command usage$/i.test(l));
  if (lines.length < 2) return null;
  // Der Zustand steht in den ersten Zeilen - aber nicht immer in derselben:
  // meist Zeile zwei ("AntiAFK" / "on"), bei antiKick ist Zeile eins schon das
  // Label ("Enabled" / "Off!") und bei coordObf wiederholt sich erst der Titel
  // ("Coordinate Obfuscation" zweimal, dann "off"). Deshalb: die ersten drei
  // Zeilen nach einem Zustandswort absuchen, exakter Treffer, kein Enthalten.
  for (let i = 0; i < Math.min(3, lines.length); i++) {
    const word = lines[i]!.toLowerCase().replace(/!+$/, '');
    const isState = word === 'on' || word === 'off' || word === 'enabled' || word === 'disabled';
    if (!isState) continue;
    // Label+Wert-Form ("Enabled" / "Off!"): dann gilt die naechste Zeile.
    if (i === 0 && lines.length > 1) {
      const next = lines[1]!.toLowerCase().replace(/!+$/, '');
      if (next === 'on' || next === 'off' || next === 'enabled' || next === 'disabled') {
        return next === 'on' || next === 'enabled';
      }
    }
    return word === 'on' || word === 'enabled';
  }
  return null;
}

/**
 * Spieler aus `visualRange list` lesen.
 *
 * Ohne Spieler in Reichweite meldet ZenithProxy "No players in visual range",
 * mit Spielern stehen die Namen als Zeilen unter der Kopfzeile
 * "VisualRange Players". Alles ab der naechsten bekannten Einstellungszeile
 * (VisualRange, Enter Alerts, ...) gehoert nicht mehr dazu. Das Format mit
 * Spielern drin haben wir noch nie live gesehen - deshalb defensiv: nur
 * Zeilen, die wie Spielernamen aussehen, sonst nichts.
 */
export function parseVisualRange(text: string): string[] {
  const lines = stripAnsi(text).split('\n').map((l) => l.trim());
  const start = lines.findIndex((l) => /^visualrange players$/i.test(l));
  if (start < 0) return [];
  const names: string[] = [];
  for (const line of lines.slice(start + 1)) {
    if (!line) continue;
    if (/^no players in visual range$/i.test(line)) return [];
    if (isSettingLine(line)) break;
    if (/^[A-Za-z0-9_]{3,16}$/.test(line)) names.push(line);
    // Unbekannte Zeilen ignorieren statt raten - lieber ein Name zu wenig
    // als ein Einstellungs-Text als Spieler.
  }
  return names;
}

/** Einstellungszeilen, die eine Namensliste beenden. */
function isSettingLine(line: string): boolean {
  return /^(visualrange|enter |leave |logout |ignore |replay |yaw|pitch)\b/i.test(line);
}

/**
 * Spieler aus `tablist` lesen. Die Ausgabe ist ein Code-Block mit
 * whitespace-getrennter Tabelle - Namen herausziehen, Rest verwerfen.
 */
export function parseTablist(text: string): string[] {
  const names: string[] = [];
  for (const raw of stripAnsi(text).split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('```')) continue;
    for (const part of line.split(/\s+/)) {
      if (/^[A-Za-z0-9_]{3,16}$/.test(part)) names.push(part);
    }
  }
  return [...new Set(names)];
}

/**
 * Namen aus `whitelist list` oder `spectator whitelist list` lesen.
 *
 * Beide Antworten sind Abschnitte in einer laengeren Ausgabe:
 *
 *     Whitelist List
 *     Whitelist            <- header
 *     CptSeeBear           <- Namen, eine Zeile pro Spieler
 *                            <- (leer)
 *     Auto Add Zenith Account   <- naechste Einstellung, Ende des Abschnitts
 *     on
 *
 * Leere Listen meldet ZenithProxy als einzelne Zeile "Empty". Die wird
 * ausdruecklich ausgeschlossen: sie sieht aus wie ein Spielername, ist aber
 * keiner. Ebenso die Abschnitts-Abschluesse ("Spectators", "on"/"off").
 */
export function parseAccessList(text: string, header: 'whitelist' | 'spectator'): string[] {
  const lines = stripAnsi(text)
    .split('\n')
    .map((l) => l.trim());
  const headerLine = header === 'whitelist' ? 'whitelist' : 'spectator whitelist';
  const start = lines.findIndex((l) => l.toLowerCase() === headerLine);
  if (start < 0) return [];
  const names: string[] = [];
  for (const line of lines.slice(start + 1)) {
    if (!line) continue;
    const lower = line.toLowerCase();
    // Leere Liste, Abschnittsende oder Ein/Zustand - alles keine Spieler.
    if (lower === 'empty') return [];
    if (lower === 'spectators' || lower === 'on' || lower === 'off') break;
    if (!/^[A-Za-z0-9_]{3,16}$/.test(line)) break;
    names.push(line);
  }
  return [...new Set(names)];
}

/** true, wenn die Ausgabe eine Berechtigungs-Verweigerung ist. */
export function isNotAuthorized(text: string): boolean {
  return /not authorized/i.test(text);
}

function stripAnsi(text: string): string {
  // eslint-disable-next-line no-control-regex
  return text.replace(/\x1b\[[0-9;]*m/g, '');
}
