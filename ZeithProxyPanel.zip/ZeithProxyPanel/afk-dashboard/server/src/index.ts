import Fastify from 'fastify';
import fastifyCookie from '@fastify/cookie';
import fastifyStatic from '@fastify/static';
import fs from 'node:fs';
import { config } from './config';
import { attachAuth, ensureBootstrapUser } from './routes/auth';
import { registerAccountRoutes } from './routes/accounts';
import { supervisor } from './supervisor';

async function main(): Promise<void> {
  if (!config.encryptionKey) {
    console.error(
      'ENCRYPTION_KEY fehlt. Bitte .env aus .env.example kopieren und den Wert eintragen.\n' +
        'Beispiel erzeugen:  openssl rand -hex 32',
    );
    process.exit(1);
  }

  ensureBootstrapUser();

  const app = Fastify({
    logger: {
      level: process.env.LOG_LEVEL ?? 'info',
      transport: process.env.NODE_ENV === 'production' ? undefined : undefined,
    },
    // 2b2t-Daten koennen gelegentlich gross werden (Tablist, Chat-Historie).
    bodyLimit: 2 * 1024 * 1024,
  });

  // Muss vor den Routen stehen: Fastify haengt den Error-Handler an den
  // Kontext, in dem er gesetzt wird. So sitzt er sicher auf der Wurzel und
  // gilt fuer alles, was danach registriert wird.
  app.setErrorHandler((err: Error & { statusCode?: number }, _req, reply) => {
    app.log.error({ err }, 'Unbehandelter Fehler');
    return reply.code(err.statusCode ?? 500).send({ error: err.message });
  });

  await app.register(fastifyCookie);
  attachAuth(app);
  await registerAccountRoutes(app);

  // Gebautes Frontend ausliefern, dazu die SPA-Fallback-Route.
  if (fs.existsSync(config.webDist)) {
    await app.register(fastifyStatic, { root: config.webDist, prefix: '/' });
    app.setNotFoundHandler((req, reply) => {
      if (req.url.startsWith('/api/')) {
        return reply.code(404).send({ error: 'Unbekannter API-Endpunkt' });
      }
      return reply.sendFile('index.html');
    });
  } else {
    app.setNotFoundHandler((req, reply) =>
      reply.code(404).send({ error: 'Frontend ist nicht gebaut. Siehe web/README bzw. Dockerfile.' }),
    );
  }

  await app.listen({ port: config.port, host: config.host });
  app.log.info(`Dashboard laeuft auf http://${config.host}:${config.port}`);

  supervisor.start();

  // Sauber herunterfahren, damit die ZenithProxy-Kinder mit SIGTERM bekommen
  // und nicht hart gekillt werden.
  const shutdown = async (signal: string): Promise<void> => {
    app.log.info(`${signal} empfangen - fahre herunter`);
    await supervisor.shutdown().catch(() => {});
    await app.close().catch(() => {});
    process.exit(0);
  };
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));

  // Docker-Watchdog: bei unerwartetem Hängen hilft nur ein Neustart, aber der
  // soll wenigstens sauber protokolliert sein.
  process.on('unhandledRejection', (reason) => {
    app.log.error({ reason }, 'Unbehandelte Promise-Ablehnung');
  });
}

main().catch((err) => {
  console.error('Start fehlgeschlagen:', err);
  process.exit(1);
});
