import { DatabaseSync } from 'node:sqlite';
import { randomBytes, randomUUID } from 'node:crypto';
import { config, dbPath } from './config';
import type { Account, AuthType, Edition, StatusSample } from './types';
import fs from 'node:fs';
import path from 'node:path';

fs.mkdirSync(config.dataDir, { recursive: true });

/**
 * SQLite ueber das eingebaute Modul `node:sqlite` - kein better-sqlite3.
 *
 * Grund: better-sqlite3 ist eine native Abhaengigkeit und braucht einen
 * C-Compiler. Im Docker-Image ist das eine weitere Fehlerquelle, und nicht
 * jedes Node-Release hat ein fertiges Binary da. `node:sqlite` ist ab Node 22
 * Teil der Laufzeit, verhaelt sich weitgehend gleich und macht das Image
 * deutlich robuster.
 */
export const db = new DatabaseSync(dbPath);
db.exec('PRAGMA journal_mode = WAL');
db.exec('PRAGMA foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id         TEXT PRIMARY KEY,
  user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS accounts (
  id             TEXT PRIMARY KEY,
  label          TEXT NOT NULL,
  edition        TEXT NOT NULL CHECK (edition IN ('java','bedrock')),
  username       TEXT NOT NULL,
  server_host    TEXT NOT NULL,
  server_port    INTEGER NOT NULL,
  enabled        INTEGER NOT NULL DEFAULT 1,
  auto_reconnect INTEGER NOT NULL DEFAULT 1,
  mc_port        INTEGER,
  webapi_port    INTEGER,
  webapi_token   TEXT,
  auth_dir       TEXT,
  secret         TEXT,
  auth_type      TEXT NOT NULL DEFAULT 'deviceCode',
  created_at     INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_accounts_enabled ON accounts(enabled);

CREATE TABLE IF NOT EXISTS status_history (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  account_id     TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  ts             INTEGER NOT NULL,
  online         INTEGER NOT NULL,
  ping           INTEGER,
  health         REAL,
  queue_position INTEGER,
  playtime_sec   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_history_account_ts ON status_history(account_id, ts DESC);
`);

// Spalten nachziehen, falls eine aeltere Datenbank schon existiert.
// CREATE TABLE IF NOT EXISTS laeuft naemlich an einer bestehenden Tabelle
// ins Leere, und eine fehlende Spalte faellt dann erst zur Laufzeit auf.
addColumnIfMissing('accounts', 'auth_type', "TEXT NOT NULL DEFAULT 'deviceCode'");

function addColumnIfMissing(table: string, column: string, definition: string): void {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all() as Array<{ name: string }>;
  if (cols.some((c) => c.name === column)) return;
  db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
}

// ---------------------------------------------------------------- Accounts

interface AccountRow {
  id: string;
  label: string;
  edition: string;
  username: string;
  server_host: string;
  server_port: number;
  enabled: number;
  auto_reconnect: number;
  mc_port: number | null;
  webapi_port: number | null;
  webapi_token: string | null;
  auth_dir: string | null;
  secret: string | null;
  auth_type: string;
  created_at: number;
}

function toAccount(r: AccountRow): Account {
  return {
    id: r.id,
    label: r.label,
    edition: r.edition as Edition,
    username: r.username,
    serverHost: r.server_host,
    serverPort: r.server_port,
    enabled: r.enabled === 1,
    autoReconnect: r.auto_reconnect === 1,
    mcPort: r.mc_port,
    webapiPort: r.webapi_port,
    webapiToken: r.webapi_token,
    authDir: r.auth_dir,
    authType: (r.auth_type === 'prism' ? 'prism' : 'deviceCode') as AuthType,
    createdAt: r.created_at,
  };
}

const selAccount = db.prepare('SELECT * FROM accounts WHERE id = ?');
const selAccounts = db.prepare('SELECT * FROM accounts ORDER BY created_at ASC');
/**
 * node:sqlite gibt generische Zeilen zurueck. Statt an jeder Stelle zu casten
 * machen wir das hier einmal zentral - die Spaltennamen in AccountRow
 * entsprechen der SELECT-Liste.
 *
 * Wichtig: `.get()` liefert EIN Objekt, `.all()` ein Array. Die beiden Casts
 * sind deshalb bewusst getrennt.
 */
const asRows = (rows: unknown): AccountRow[] => rows as AccountRow[];
const asRow = (row: unknown): AccountRow | undefined =>
  row === undefined || row === null ? undefined : (row as AccountRow);
const insAccount = db.prepare(`
  INSERT INTO accounts (id,label,edition,username,server_host,server_port,
                        enabled,auto_reconnect,mc_port,webapi_port,webapi_token,auth_dir,secret,
                        auth_type,created_at)
  VALUES (@id,@label,@edition,@username,@server_host,@server_port,
          @enabled,@auto_reconnect,@mc_port,@webapi_port,@webapi_token,@auth_dir,@secret,
          @auth_type,@created_at)
`);
const delAccount = db.prepare('DELETE FROM accounts WHERE id = ?');
const updEnabled = db.prepare('UPDATE accounts SET enabled = ? WHERE id = ?');
const updPorts = db.prepare('UPDATE accounts SET mc_port = ?, webapi_port = ?, webapi_token = ? WHERE id = ?');
const updSecret = db.prepare('UPDATE accounts SET secret = ? WHERE id = ?');
const updServer = db.prepare('UPDATE accounts SET server_host = ?, server_port = ? WHERE id = ?');

export function getAccount(id: string): Account | null {
  const row = asRow(selAccount.get(id));
  return row ? toAccount(row) : null;
}

export function listAccounts(): Account[] {
  return asRows(selAccounts.all()).map(toAccount);
}

export interface NewAccount {
  label: string;
  edition: Edition;
  username: string;
  serverHost: string;
  serverPort: number;
  autoReconnect?: boolean;
  mcPort?: number | null;
  webapiPort?: number | null;
  webapiToken?: string | null;
  authDir?: string | null;
  secret?: string | null;
  authType?: AuthType;
}

export function createAccount(input: NewAccount): Account {
  const id = randomUUID();
  const authDir = input.authDir ?? path.join(config.instanceRoot, id);
  insAccount.run({
    id,
    label: input.label,
    edition: input.edition,
    username: input.username,
    server_host: input.serverHost,
    server_port: input.serverPort,
    enabled: 1,
    auto_reconnect: input.autoReconnect === false ? 0 : 1,
    mc_port: input.mcPort ?? null,
    webapi_port: input.webapiPort ?? null,
    webapi_token: input.webapiToken ?? null,
    auth_dir: authDir,
    secret: input.secret ?? null,
    auth_type: input.authType ?? 'deviceCode',
    created_at: Date.now(),
  });
  const acc = getAccount(id);
  if (!acc) throw new Error('Account konnte nicht angelegt werden');
  return acc;
}

export function deleteAccount(id: string): void {
  delAccount.run(id);
}

export function setAccountEnabled(id: string, enabled: boolean): void {
  updEnabled.run(enabled ? 1 : 0, id);
}

export function setAccountPorts(
  id: string,
  mcPort: number | null,
  webapiPort: number | null,
  webapiToken: string | null,
): void {
  updPorts.run(mcPort, webapiPort, webapiToken);
}

export function setAccountSecret(id: string, secret: string | null): void {
  updSecret.run(secret);
}

export function setAccountServer(id: string, host: string, port: number): void {
  updServer.run(host, port);
}

// ------------------------------------------------------------------ Secret

export function getAccountSecret(id: string): string | null {
  const row = db.prepare('SELECT secret FROM accounts WHERE id = ?').get(id) as
    | { secret: string | null }
    | undefined;
  return row?.secret ?? null;
}

// --------------------------------------------------------- Statusverlauf

const insHistory = db.prepare(`
  INSERT INTO status_history (account_id,ts,online,ping,health,queue_position,playtime_sec)
  VALUES (?,?,?,?,?,?,?)
`);

export function recordStatus(accountId: string, s: StatusSample): void {
  insHistory.run(
    accountId,
    s.ts,
    s.online ? 1 : 0,
    s.ping,
    s.health,
    s.queuePosition,
    s.playtimeSec,
  );
}

export function pruneHistory(accountId: string, keep = 5000): void {
  db.prepare(
    `DELETE FROM status_history
      WHERE account_id = ?
        AND id NOT IN (
          SELECT id FROM status_history WHERE account_id = ? ORDER BY ts DESC LIMIT ?
        )`,
  ).run(accountId, accountId, keep);
}

export function historySince(accountId: string, since: number, limit = 500): StatusSample[] {
  const rows = db
    .prepare(
      `SELECT ts, online, ping, health, queue_position, playtime_sec
         FROM status_history
        WHERE account_id = ? AND ts >= ?
        ORDER BY ts ASC
        LIMIT ?`,
    )
    .all(accountId, since, limit) as Array<{
    ts: number;
    online: number;
    ping: number | null;
    health: number | null;
    queue_position: number | null;
    playtime_sec: number | null;
  }>;
  return rows.map((r) => ({
    ts: r.ts,
    online: r.online === 1,
    ping: r.ping,
    health: r.health,
    queuePosition: r.queue_position,
    playtimeSec: r.playtime_sec,
  }));
}

// ------------------------------------------------------------------ Users

export function countUsers(): number {
  const row = db.prepare('SELECT COUNT(*) AS n FROM users').get() as { n: number };
  return row.n;
}

export function createUser(username: string, passwordHash: string): string {
  const id = randomUUID();
  db.prepare('INSERT INTO users (id,username,password_hash,created_at) VALUES (?,?,?,?)').run(
    id,
    username,
    passwordHash,
    Date.now(),
  );
  return id;
}

export function getUserByName(username: string): { id: string; password_hash: string } | null {
  return (
    (db.prepare('SELECT id, password_hash FROM users WHERE username = ?').get(username) as
      | { id: string; password_hash: string }
      | undefined) ?? null
  );
}

export function createSession(userId: string, ttlMs: number): string {
  const id = randomBytes(32).toString('hex');
  const now = Date.now();
  db.prepare('INSERT INTO sessions (id,user_id,created_at,expires_at) VALUES (?,?,?,?)').run(
    id,
    userId,
    now,
    now + ttlMs,
  );
  return id;
}

export function resolveSession(sessionId: string): string | null {
  const row = db
    .prepare('SELECT user_id, expires_at FROM sessions WHERE id = ?')
    .get(sessionId) as { user_id: string; expires_at: number } | undefined;
  if (!row) return null;
  if (row.expires_at < Date.now()) {
    db.prepare('DELETE FROM sessions WHERE id = ?').run(sessionId);
    return null;
  }
  return row.user_id;
}

export function destroySession(sessionId: string): void {
  db.prepare('DELETE FROM sessions WHERE id = ?').run(sessionId);
}
