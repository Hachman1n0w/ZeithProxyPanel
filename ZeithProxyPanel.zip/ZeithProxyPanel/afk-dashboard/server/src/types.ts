/**
 * Gemeinsame Typen. Die Datei ist die einzige Stelle, an der sich die beiden
 * Editionen (Java / Bedrock) wirklich unterscheiden - alles darueber ist
 * edition-agnostisch.
 */

export type Edition = 'java' | 'bedrock';

/** Anmeldeweg fuer Java-Instanzen, siehe Account.authType. */
export type AuthType = 'deviceCode' | 'prism';

/**
 * Wie der Status eines Accounts von aussen wirkt. Die Farbcodierung im
 * Dashboard haengt direkt an diesen Zustaenden.
 */
export type AccountState =
  | 'stopped' // Prozess laeuft nicht
  | 'starting' // Prozess hochgefahren, noch nicht verbunden
  | 'connecting' // Verbindung zu 2b2t steht, Login/Queue laeuft
  | 'queued' // In der Warteschlange
  | 'online' // Im Spiel
  | 'error'; // Fehler, siehe lastError

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

export interface QueueInfo {
  priority: number | null;
  regular: number | null;
  /** Position in der eigenen Queue (Prio oder Regular, je nachdem wo man steht). */
  position: number | null;
  estimatedWaitSec: number | null;
}

export interface AccountStatus {
  state: AccountState;
  /** Aktuell eingeloggter echter Spieler auf dem Proxy, oder null im Bot-Betrieb. */
  connectedPlayer: string | null;
  /**
   * Nur Java: Adresse, auf der der ZenithProxy lauscht, so wie ZenithProxy sie
   * selbst meldet - meist "127.0.0.1:25565".
   *
   * Das ist die Adresse, an die sich ein Client verbinden muesste, und damit
   * auch das Ziel, das ein playit-Tunnel durchreichen soll. Bei Bedrock gibt
   * es sie nicht: der Bot nimmt Verbindungen an, sondern stellt keine her.
   */
  proxyIp: string | null;
  ping: number | null;
  health: number | null;
  position: Vec3 | null;
  dimension: string | null;
  queue: QueueInfo | null;
  playtimeSec: number | null;
  /**
   * Nur Java: Spieler in Sichtweite des Bots (`visualRange list`).
   *
   * count ist die Anzahl, names die ersten paar Namen fuer die Kartenansicht.
   * null, solange nichts bekannt ist - also bei gestoppten Instanzen, bei
   * Bedrock und wenn die Web-API gerade nicht antwortet. Das ist kein
   * Fehlerzustand, sondern "keine Daten".
   */
  nearby: { count: number; names: string[] } | null;
  /** Wie der Status erhoben wurde - "webapi" ist der gute, "logtail" der Notfallfall. */
  source: 'webapi' | 'logtail' | 'bedrock' | 'process' | 'none';
  /**
   * Nur Java: Anmeldelink von ZenithProxy, solange die Anmeldung offen ist.
   *
   * Steht bewusst am Status und nicht nur in der Detailansicht: wer auf
   * "Starten" drueckt und dann nichts weiter anklickt, muss den Link trotzdem
   * zu sehen bekommen - sonst steht die Instanz scheinbar grundlos herum.
   *
   * Nur die URL, kein Code zum Abtippen: Microsoft steckt in `otc` bereits
   * alles drin, was noetig ist.
   */
  authUrl: string | null;
  lastError: string | null;
  updatedAt: number;
}

export function emptyStatus(): AccountStatus {
  return {
    state: 'stopped',
    connectedPlayer: null,
    proxyIp: null,
    ping: null,
    health: null,
    position: null,
    dimension: null,
    queue: null,
    playtimeSec: null,
    nearby: null,
    source: 'none',
    authUrl: null,
    lastError: null,
    updatedAt: Date.now(),
  };
}

export interface Account {
  id: string;
  label: string;
  edition: Edition;
  /**
   * Java: Microsoft-E-Mail, mit der sich ZenithProxy anmeldet.
   * Bedrock: Gamertag.
   *
   * Bei Java ist das bewusst die E-Mail und nicht der Minecraft-Name: die
   * Anmeldung laeuft ueber Microsoft, und der Spielname ergibt sich erst aus
   * der authentifizierten Sitzung. Eine hinterlegte E-Mail findet man beim
   * Start auch dann wieder, wenn der Name wechselt.
   */
  username: string;
  serverHost: string;
  serverPort: number;
  enabled: boolean;
  autoReconnect: boolean;
  /** Nur Java: Port auf dem der ZenithProxy-MC-Server laeuft. */
  mcPort: number | null;
  /** Nur Java: Port der ZenithProxy-Web-API. */
  webapiPort: number | null;
  /** Nur Java: Token fuer POST /api/command. Nie an den Browser ausliefern. */
  webapiToken: string | null;
  /** Bedrock: Ablage fuer den gecachten Xbox-Live-Token. */
  authDir: string | null;
  /**
   * Nur Java: wie ZenithProxy sich anmeldet.
   *
   *   deviceCode - Microsoft-Geraetecode, Nutzer bestaetigt im Browser. Kein
   *                Passwort auf der Platte. Standard.
   *   prism      - E-Mail und Passwort direkt. Nur sinnvoll, wenn deviceCode
   *                nicht moeglich ist; das Passwort liegt dann verschluesselt
   *                in der Datenbank.
   */
  authType: AuthType;
  createdAt: number;
}

/**
 * Was die Oberflaeche von einem Account sieht.
 *
 * `webapiToken` ist ein Vollzugriffs-Token auf die Instanz und `authDir` ein
 * interner Dateipfad - beides hat der Browser nichts zu tun und wird deshalb
 * bewusst nicht mitgeschickt.
 */
export interface AccountView extends Omit<Account, 'webapiToken' | 'authDir'> {
  status: AccountStatus;
  pid: number | null;
  uptimeSec: number | null;
  /** Nur bei Bedrock: ist der Xbox-Login durch? */
  bedrockAuthed: boolean;
}

export interface CommandResult {
  ok: boolean;
  output: string;
  error?: string;
}

/**
 * Der Vertrag, den beide Treiber erfuellen. Jede Aktion, die das Dashboard
 * anbietet, laeuft ueber diese Schnittstelle.
 */
export interface Driver {
  readonly edition: Edition;
  start(): Promise<void>;
  stop(): Promise<void>;
  status(): Promise<AccountStatus>;
  /** Roh-Befehl an den Account. Bei Bedrock nicht unterstuetzt -> Fehler. */
  command(cmd: string): Promise<CommandResult>;
  isRunning(): boolean;
  dispose(): Promise<void>;
}

export interface StatusSample {
  ts: number;
  online: boolean;
  ping: number | null;
  health: number | null;
  queuePosition: number | null;
  playtimeSec: number | null;
}
