import { config } from '../config';
import {
  getAccount,
  listAccounts,
  pruneHistory,
  recordStatus,
  setAccountEnabled,
  setAccountPorts,
} from '../db';
import { authState } from '../bedrock/auth';
import { newWebapiToken } from '../zenith/launcher';
import type { Account, AccountStatus, AccountView, CommandResult, Driver } from '../types';
import { emptyStatus } from '../types';
import { BedrockDriver } from '../drivers/bedrock';
import { ZenithDriver } from '../drivers/zenith';
import { portUsage } from './ports';

/**
 * Haelt fuer jeden Account genau einen Treiber, pollt den Status, startet
 * aktivierte Accounts nach einem Neustart neu und meldet sich ueber SSE.
 *
 * Warum ein Supervisor und nicht nur Prozesse: die Instanzen muessen einen
 * Container-Neustart ueberleben, und der Bedrock-Treiber laeuft im selben
 * Prozess wie das Backend. Der Supervisor ist die einzige Stelle, die weiss,
 * was laeuft.
 */

type Listener = (accounts: AccountView[]) => void;

interface Entry {
  driver: Driver;
  status: AccountStatus;
  lastPoll: number;
  startedAt: number | null;
}

class Supervisor {
  private entries = new Map<string, Entry>();
  private listeners = new Set<Listener>();
  private pollTimer: NodeJS.Timeout | null = null;
  private watchTimer: NodeJS.Timeout | null = null;
  private starting = false;

  start(): void {
    if (this.pollTimer) return;
    this.pollTimer = setInterval(() => void this.pollAll(), config.statusPollMs);
    this.pollTimer.unref?.();
    this.watchTimer = setInterval(() => void this.watchdog(), config.watchdogIntervalMs);
    this.watchTimer.unref?.();
    void this.bootstrap();
  }

  /** Nach einem Containerstart alle aktivierten Accounts hochfahren. */
  private async bootstrap(): Promise<void> {
    if (this.starting) return;
    this.starting = true;
    try {
      for (const account of listAccounts()) {
        if (!account.enabled) continue;
        try {
          await this.startAccount(account.id);
        } catch (err) {
          console.error(`[supervisor] Start von ${account.label} fehlgeschlagen:`, err);
        }
      }
    } finally {
      this.starting = false;
    }
  }

  async shutdown(): Promise<void> {
    if (this.pollTimer) clearInterval(this.pollTimer);
    if (this.watchTimer) clearInterval(this.watchTimer);
    this.pollTimer = null;
    this.watchTimer = null;
    for (const entry of this.entries.values()) {
      await entry.driver.dispose().catch(() => {});
    }
    this.entries.clear();
  }

  // ------------------------------------------------------------- Steuerung

  async startAccount(id: string): Promise<void> {
    const existing = this.entries.get(id);
    if (existing?.driver.isRunning()) return;

    const account = getAccount(id);
    if (!account) throw new Error('Account nicht gefunden');

    const driver = this.createDriver(account);
    this.entries.set(id, {
      driver,
      status: emptyStatus(),
      // lastPoll auf "jetzt" setzen, nicht auf 0: der Watchdog rechnet
      // Date.now() - lastPoll, und 0 wuerde eine gerade gestartete Instanz
      // sofort als haengend einstufen und nach sptestens einem Watchdog-Takt
      // wieder killen. Der erste echte Status kommt ohnehin erst nach dem
      // Boot, der bei ZenithProxy gut eine Minute dauert.
      lastPoll: Date.now(),
      startedAt: Date.now(),
    });
    this.broadcast();

    try {
      await driver.start();
    } catch (err) {
      const entry = this.entries.get(id);
      if (entry) {
        entry.status = { ...entry.status, state: 'error', lastError: (err as Error).message };
      }
    }
    this.broadcast();
  }

  private createDriver(account: Account): Driver {
    if (account.edition === 'bedrock') return new BedrockDriver(account);
    return new ZenithDriver(account, this.tokenFor(account));
  }

  /**
   * Web-API-Token fuer eine Instanz.
   *
   * Wird in `webapi_token` gehalten, nicht im `secret`-Feld: dort liegt
   * inzwischen das verschluesselte Microsoft-Passwort (authType "prism"), und
   * beide Werte wuerden sich sonst gegenseitig ueberschreiben.
   */
  private tokenFor(account: Account): string {
    if (account.webapiToken) return account.webapiToken;
    const token = newWebapiToken();
    setAccountPorts(account.id, account.mcPort, account.webapiPort, token);
    return token;
  }

  async stopAccount(id: string): Promise<void> {
    const entry = this.entries.get(id);
    if (!entry) return;
    await entry.driver.stop().catch(() => {});
    entry.status = { ...emptyStatus(), source: entry.status.source };
    entry.startedAt = null;
    this.broadcast();
  }

  async restartAccount(id: string): Promise<void> {
    await this.stopAccount(id);
    await this.startAccount(id);
  }

  async command(id: string, cmd: string): Promise<CommandResult> {
    const entry = this.entries.get(id);
    if (!entry) return { ok: false, output: '', error: 'Account laeuft nicht' };
    return entry.driver.command(cmd);
  }

  setEnabled(id: string, enabled: boolean): void {
    setAccountEnabled(id, enabled);
    if (!enabled) void this.stopAccount(id);
    else void this.startAccount(id);
  }

  // --------------------------------------------------------------- Status

  private async pollAll(): Promise<void> {
    for (const [id, entry] of this.entries) {
      try {
        entry.status = await entry.driver.status();
        entry.lastPoll = Date.now();
        this.persist(id, entry.status);
      } catch (err) {
        entry.status = { ...entry.status, lastError: (err as Error).message };
      }
    }
    this.broadcast();
  }

  private persist(id: string, status: AccountStatus): void {
    recordStatus(id, {
      ts: status.updatedAt,
      online: status.state === 'online',
      ping: status.ping,
      health: status.health,
      queuePosition: status.queue?.position ?? null,
      playtimeSec: status.playtimeSec,
    });
    // Historie nicht ewig aufbewahren - sonst waechst die DB unbegrenzt.
    if (Math.random() < 0.05) pruneHistory(id);
  }

  /**
   * Haengt ein Instanzprozess, ohne sich zu beenden, schiessen wir ihn nach
   * kurzer Zeit ab und starten neu. Sonst haengt ein Account still, ohne dass
   * man es im Dashboard sieht.
   */
  private async watchdog(): Promise<void> {
    for (const [id, entry] of this.entries) {
      // Deaktivierte Accounts gehoeren nicht in diese Schleife. Ohne diese
      // Zeile startet der Auto-Reconnect sie wieder und das Abschalten im
      // Dashboard waerte genau einen Watchdog-Takt - bei 30s also eine halbe
      // Minute, in der die Instanz laeuft, obwohl sie ausgeschaltet ist.
      const account = getAccount(id);
      if (!account?.enabled) continue;

      if (!entry.driver.isRunning()) {
        // Prozess weg: Auto-Reconnect nur, wenn der Account es auch will.
        if (account.autoReconnect) {
          console.warn(`[watchdog] ${account.label} ist beendet - starte neu`);
          await this.startAccount(id).catch(() => {});
        }
        continue;
      }
      // Erwartetes Status-Update verpasst -> Kandidat fuer einen Neustart.
      // Grosszuegig angesetzt: der erste Status einer frischen Instanz laesst
      // den kompletten ZenithProxy-Boot plus WebAPI-Probe auf sich warten.
      if (Date.now() - entry.lastPoll > config.statusPollMs * 4) {
        console.warn(`[watchdog] ${account.label} liefert keinen Status - Neustart`);
        await this.restartAccount(id).catch(() => {});
      }
    }
  }

  view(id: string): AccountView | null {
    const account = getAccount(id);
    if (!account) return null;
    const entry = this.entries.get(id);
    const running = entry?.driver.isRunning() ?? false;
    // Token und interner Pfad bleiben im Backend - beides geht nicht raus.
    const { webapiToken: _token, authDir: _dir, ...rest } = account;

    return {
      ...rest,
      status: entry?.status ?? emptyStatus(),
      pid: running ? pidOf(entry!.driver) : null,
      uptimeSec: entry?.startedAt && running ? Math.floor((Date.now() - entry.startedAt) / 1000) : null,
      // Bei Bedrock ist "angemeldet" eine eigene Frage - der Treiber kann
      // laufen, ohne dass der Xbox-Login durch ist.
      bedrockAuthed: account.edition === 'bedrock' && authState(account.id).status === 'ready',
    };
  }

  viewAll(): AccountView[] {
    return listAccounts()
      .map((a) => this.view(a.id))
      .filter((v): v is AccountView => v !== null);
  }

  driverFor(id: string): Driver | null {
    return this.entries.get(id)?.driver ?? null;
  }

  // ------------------------------------------------------------------ SSE

  subscribe(fn: Listener): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private broadcast(): void {
    if (this.listeners.size === 0) return;
    const payload = this.viewAll();
    for (const fn of this.listeners) {
      try {
        fn(payload);
      } catch {
        /* abgestorbener Listener */
      }
    }
  }

  ports() {
    return portUsage(listAccounts());
  }
}

function pidOf(driver: Driver): number | null {
  return 'pid' in driver && typeof (driver as { pid?: number | null }).pid === 'number'
    ? ((driver as { pid?: number | null }).pid ?? null)
    : null;
}

export const supervisor = new Supervisor();
