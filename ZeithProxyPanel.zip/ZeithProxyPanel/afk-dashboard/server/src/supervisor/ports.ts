/**
 * Port-Zuteilung fuer die Java-Instanzen.
 *
 * Jede ZenithProxy-Instanz braucht zwei freie Ports: einen fuer ihren eigenen
 * MC-Server (damit du dich selbst einloggen kannst) und einen fuer die
 * Web-API. Die Bloecke sind bewusst klein gehalten (5 fuer MC, 5 fuer API) -
 * auf einem Container ist alles im selben Namespace, da kollidiert schnell
 * etwas.
 */

import { config } from '../config';
import type { Account } from '../types';

function range(start: number, end: number): number[] {
  const out: number[] = [];
  for (let p = start; p <= end; p++) out.push(p);
  return out;
}

export function allocatePorts(accounts: Account[]): { mcPort: number; webapiPort: number } | null {
  const usedMc = new Set(accounts.map((a) => a.mcPort).filter((p): p is number => p !== null));
  const usedApi = new Set(
    accounts.map((a) => a.webapiPort).filter((p): p is number => p !== null),
  );

  const mcFree = range(config.ports.mcStart, config.ports.mcEnd).find((p) => !usedMc.has(p));
  const apiFree = range(config.ports.apiStart, config.ports.apiEnd).find((p) => !usedApi.has(p));

  if (mcFree === undefined || apiFree === undefined) return null;
  return { mcPort: mcFree, webapiPort: apiFree };
}

export function portUsage(accounts: Account[]): {
  mc: { used: number; total: number; free: number[] };
  api: { used: number; total: number; free: number[] };
} {
  const usedMc = new Set(accounts.map((a) => a.mcPort).filter((p): p is number => p !== null));
  const usedApi = new Set(
    accounts.map((a) => a.webapiPort).filter((p): p is number => p !== null),
  );
  const mcAll = range(config.ports.mcStart, config.ports.mcEnd);
  const apiAll = range(config.ports.apiStart, config.ports.apiEnd);
  return {
    mc: {
      used: usedMc.size,
      total: mcAll.length,
      free: mcAll.filter((p) => !usedMc.has(p)),
    },
    api: {
      used: usedApi.size,
      total: apiAll.length,
      free: apiAll.filter((p) => !usedApi.has(p)),
    },
  };
}
