import type { FastifyInstance } from 'fastify';
import { config } from '../config';
import {
  createAccount,
  deleteAccount,
  getAccount,
  historySince,
  listAccounts,
} from '../db';
import { authState, clearCachedLogin, hasCachedLogin } from '../bedrock/auth';
import { supervisor } from '../supervisor';
import { allocatePorts } from '../supervisor/ports';
import { newWebapiToken } from '../zenith/launcher';
import {
  MODULES,
  isKnownModule,
  isNotAuthorized,
  parseAccessList,
  parseModuleState,
  parseTablist,
  parseVisualRange,
} from '../zenith/modules';
import { purgeInstance } from '../instances';
import { encryptSecret } from '../crypto';
import type { AuthType, Edition } from '../types';

/**
 * Erste Zeile einer Ausgabe, die auf ein Muster passt. Fuer Fehlermeldungen
 * aus ZenithProxy, die wir unverfaelscht an die Oberflaeche reichen wollen.
 */
function firstLineMatching(text: string, pattern: RegExp): string | null {
  for (const raw of text.split('\n')) {
    const line = raw.trim();
    if (line && pattern.test(line)) return line;
  }
  return null;
}

/**
 * Array mit begrenzter Parallelitaet abarbeiten.
 *
 * Promise.all auf 15 Modulabfragen wuerde 15 gleichzeitige HTTP-Anfragen an
 * eine Instanz schicken, deren Rate-Limiter bei 30 pro Minute liegt. Mit
 * 4 nebenlaeufig ist der Abruf in wenigen Sekunden durch, ohne den Limiter
 * zu reizen oder den laufenden Status-Abruf zu verdrängen.
 */
async function mapLimit<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let next = 0;
  const workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) {
      const i = next++;
      out[i] = await fn(items[i]!);
      // Kurz warten statt sofort den naechsten: der Rate-Limiter zaehlt
      // Anfragen pro Minute, und 15 Befehle im selben Augenblick reizen ihn
      // eher als dieselben 15 ueber ein paar Sekunden verteilt.
      await new Promise((r) => setTimeout(r, 250));
    }
  });
  await Promise.all(workers);
  return out;
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

/** Frische-Dauer fuer gelesene Modulzustaende: ein Abruf kostet 14 Befehle. */
const MODULE_TTL_MS = 60_000;
/** Harte Obergrenze fuer einen Modulabruf, bevor "?" zurueckkommt. */
const MODULE_OVERALL_TIMEOUT_MS = 25_000;

interface CachedModules {
  at: number;
  states: { id: string; enabled: boolean | null }[];
}

/**
 * Gelesene Zustaende pro Account. Ein laufender Abruf pro Account
 * (Singleflight): wer waehrenddessen fragt, haengt sich dran statt weitere
 * 14 Befehle zu verursachen.
 */
const moduleCache = new Map<string, CachedModules>();
const moduleInflight = new Map<string, Promise<CachedModules['states']>>();

/**
 * Alle Modulzustaende einer Instanz lesen. Wirft nie: im Zweifel steht
 * enabled auf null ("?"), aber die Anfrage bekommt immer eine Antwort.
 *
 * Ein Versuch pro Modul plus eine Wiederholung bei leerem Ergebnis - die
 * fruehere zweite Komplett-Runde ist gestrichen: Sie hat bei knappem Budget
 * mehr geschadet als genutzt, weil sie das Budget erst recht erschoepft hat.
 */
async function refreshModules(
  id: string,
  isAborted: () => boolean,
): Promise<CachedModules['states']> {
  const read = async (m: { id: string }): Promise<{ id: string; enabled: boolean | null }> => {
    try {
      if (isAborted()) return { id: m.id, enabled: null };
      const first = await supervisor.command(id, m.id);
      let enabled = first.ok ? parseModuleState(first.output) : null;
      if (enabled === null && !isAborted()) {
        await sleep(2000);
        if (!isAborted()) {
          const second = await supervisor.command(id, m.id);
          enabled = second.ok ? parseModuleState(second.output) : null;
        }
      }
      return { id: m.id, enabled };
    } catch {
      return { id: m.id, enabled: null };
    }
  };
  const states = await mapLimit(MODULES, 4, read);
  // Nur echte Ergebnisse cachen: Abbrueche duerfen den naechsten Abruf nicht
  // 60 s lang blockieren, und ein komplett leeres Ergebnis ist kein Wissen.
  if (!isAborted() && states.some((s) => s.enabled !== null)) {
    moduleCache.set(id, { at: Date.now(), states });
  }
  return states;
}

/** Modulzustaende verwerfen, z.B. nach dem Umschalten oder Loeschen. */
function dropModuleCache(id: string): void {
  moduleCache.delete(id);
}

/**
 * Ergebnisversprechen mit harter Obergrenze.
 *
 * Faellt die Abfrage in ein Budget-Loch (Rate-Limiter gedrosselt, Instanz
 * traege), darf der Endpunkt trotzdem nicht minutenlang haengen - der Browser
 * gibt irgendwann auf, und die Arbeit liefe unsichtbar weiter und frisst das
 * knappe Minutenbudget. Lieber nach 25 s das bisherige (ggf. leere)
 * zurueckgeben; der naechste Aufruf trifft dann auf einen freien Limiter.
 */
function withTimeout<T>(task: Promise<T>, ms: number, fallback: () => T): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const limit = new Promise<T>((resolve) => {
    timer = setTimeout(() => resolve(fallback()), ms);
  });
  return Promise.race([task, limit]).finally(() => clearTimeout(timer));
}

interface CreateBody {
  label?: string;
  edition?: Edition;
  /**
   * Java: Microsoft-E-Mail. Bedrock: Gamertag.
   */
  username?: string;
  /**
   * Java mit authType "prism": das Microsoft-Passwort. Wird verschluesselt
   * gespeichert und niemals zurueckgegeben. Bei "deviceCode" (Standard) wird
   * es nicht gebraucht - dort bestaetigt der Nutzer die Anmeldung im Browser.
   */
  password?: string;
  /** Nur Java. Default "deviceCode". */
  authType?: AuthType;
  serverHost?: string;
  serverPort?: number;
  autoReconnect?: boolean;
}

export async function registerAccountRoutes(app: FastifyInstance): Promise<void> {
  // ------------------------------------------------------------- Übersicht

  app.get('/api/accounts', { preHandler: app.requireAuth }, async () => ({
    accounts: supervisor.viewAll(),
    ports: supervisor.ports(),
  }));

  app.get('/api/accounts/:id', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const view = supervisor.view(id);
    if (!view) return reply.code(404).send({ error: 'Account nicht gefunden' });
    const driver = supervisor.driverFor(id);
    const log =
      driver && 'recentLog' in driver ? (driver as { recentLog(n?: number): string[] }).recentLog(150) : [];
    const account = getAccount(id);
    return {
      account: view,
      auth: authState(id),
      log,
      bedrockAuthed: account?.edition === 'bedrock' ? await hasCachedLogin(account.authDir ?? '') : false,
      ticks: driver && 'tickStats' in driver ? (driver as { tickStats(): unknown }).tickStats() : null,
    };
  });

  // ---------------------------------------------------------------- Anlegen

  app.post('/api/accounts', { preHandler: app.requireAuth }, async (req, reply) => {
    const body = req.body as CreateBody;
    const label = body.label?.trim();
    const username = body.username?.trim();
    const edition = body.edition;
    const authType: AuthType = body.authType === 'prism' ? 'prism' : 'deviceCode';

    if (!label) return reply.code(400).send({ error: 'Name fehlt' });
    if (!username) {
      return reply.code(400).send({
        error: edition === 'java' ? 'Microsoft-E-Mail fehlt' : 'Gamertag fehlt',
      });
    }
    if (edition !== 'java' && edition !== 'bedrock') {
      return reply.code(400).send({ error: 'Edition muss "java" oder "bedrock" sein' });
    }
    if (listAccounts().some((a) => a.label.toLowerCase() === label.toLowerCase())) {
      return reply.code(409).send({ error: 'Ein Account mit diesem Namen existiert bereits' });
    }
    if (edition === 'java' && authType === 'prism' && !body.password) {
      return reply.code(400).send({
        error: 'Anmeldung mit Passwort verlangt auch ein Passwort',
      });
    }

    if (edition === 'java') {
      const ports = allocatePorts(listAccounts());
      if (!ports) {
        return reply.code(507).send({
          error:
            'Keine freien Ports mehr. Der Server ist fuer 5 Java-Instanzen ausgelegt ' +
            'sollten aber hier keine reichen, laesst sich MC_PORT_END / API_PORT_END in der .env erhoehen.',
        });
      }
      const account = createAccount({
        label,
        edition,
        username,
        serverHost: body.serverHost?.trim() || '2b2t.org',
        serverPort: body.serverPort ?? 25565,
        autoReconnect: body.autoReconnect,
        mcPort: ports.mcPort,
        webapiPort: ports.webapiPort,
        webapiToken: newWebapiToken(),
        authType,
        // Nur bei "prism" wird ueberhaupt ein Geheimnis gespeichert. Beim
        // Geraetecode-Flow liegt hier bewusst nichts.
        secret: authType === 'prism' && body.password ? encryptSecret(body.password) : null,
      });
      return reply.code(201).send({ account: supervisor.view(account.id) });
    }

    const account = createAccount({
      label,
      edition,
      username,
      serverHost: body.serverHost?.trim() || config.bedrock.defaultHost,
      serverPort: body.serverPort ?? config.bedrock.defaultPort,
      autoReconnect: body.autoReconnect,
    });
    return reply.code(201).send({ account: supervisor.view(account.id) });
  });

  // ---------------------------------------------------------------- Loeschen

  app.delete('/api/accounts/:id', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const account = getAccount(id);
    if (!account) return reply.code(404).send({ error: 'Account nicht gefunden' });

    // Reihenfolge ist wichtig: erst den Prozess stoppen, dann die Dateien
    // loeschen, und erst ganz zuletzt den Datenbankeintrag. Wuerde es
    // dazwischen einen Fehler geben, ist der Account noch da und man kann es
    // erneut versuchen - im umgekehrten Fall waere der Eintrag weg, der
    // Prozess aber nicht.
    await supervisor.stopAccount(id).catch(() => {});
    const purge = await purgeInstance(id);
    deleteAccount(id);
    dropModuleCache(id);

    return {
      ok: true,
      removedInstanceData: purge.removed,
      // Der Datenbankeintrag ist in jedem Fall weg. Das Verzeichnis melden wir
      // nur als Warnung mit, statt die Loeschung zu verweigern - sonst koennte
      // ein falsch gesetzter Dateizugriff den Account unloeschbar machen.
      ...(purge.error ? { warning: purge.error } : {}),
    };
  });

  // -------------------------------------------------------------- Steuerung

  app.post('/api/accounts/:id/start', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    if (!getAccount(id)) return reply.code(404).send({ error: 'Account nicht gefunden' });
    await supervisor.startAccount(id);
    return { ok: true, account: supervisor.view(id) };
  });

  app.post('/api/accounts/:id/stop', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    await supervisor.stopAccount(id);
    return { ok: true, account: supervisor.view(id) };
  });

  app.post('/api/accounts/:id/restart', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    await supervisor.restartAccount(id);
    return { ok: true, account: supervisor.view(id) };
  });

  app.post('/api/accounts/:id/enabled', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const body = req.body as { enabled?: boolean };
    if (!getAccount(id)) return reply.code(404).send({ error: 'Account nicht gefunden' });
    supervisor.setEnabled(id, Boolean(body?.enabled));
    return { ok: true };
  });

  app.post('/api/accounts/:id/command', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const body = req.body as { command?: string };
    const cmd = body?.command?.trim();
    if (!cmd) return reply.code(400).send({ error: 'Kein Befehl angegeben' });
    if (cmd.length > 200) return reply.code(400).send({ error: 'Befehl zu lang' });
    const result = await supervisor.command(id, cmd);
    return result;
  });

  // ------------------------------------------------------------- Bedrock-Login

  app.get('/api/accounts/:id/auth', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    return { auth: authState(id) };
  });

  /**
   * Anmeldung neu anstossen. Loesst vorher den Token-Cache, damit Microsoft
   * nach einem abgelehnten Login wieder nach einem Device-Code fragt.
   */
  app.post('/api/accounts/:id/reauth', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const account = getAccount(id);
    if (!account) return reply.code(404).send({ error: 'Account nicht gefunden' });
    if (account.edition !== 'bedrock') {
      return reply.code(400).send({ error: 'Neu anmelden gibt es nur bei Bedrock-Accounts' });
    }
    await clearCachedLogin(account.authDir ?? '');
    await supervisor.stopAccount(id);
    await supervisor.startAccount(id);
    // Der Device-Code braucht einen Moment - nach 1,5 s steht er fast immer.
    await new Promise((r) => setTimeout(r, 1500));
    return { ok: true, auth: authState(id) };
  });

  // ------------------------------------------------------------- Verlauf

  app.get('/api/accounts/:id/history', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const query = req.query as { hours?: string } | undefined;
    const hours = Math.min(Number(query?.hours ?? 24) || 24, 24 * 30);
    if (!getAccount(id)) return reply.code(404).send({ error: 'Account nicht gefunden' });
    return { history: historySince(id, Date.now() - hours * 3600_000, 1000) };
  });

  // ----------------------------------------------- Spieler, Zugriff, Module
  // Alles hier ist Java-only: es sind ZenithProxy-Befehle, die ueber die
  // Web-API der Instanz laufen. Bei Bedrock gibt es weder Proxy noch Module.

  /**
   * Befehl mit Wiederholungsversuchen.
   *
   * Zwei Limiter spielen mit: unser Token-Bucket (wartet von selbst) und der
   * im Plugin (antwortet 429). Beide lassen 30/min durch, laufen aber
   * phasenverschoben - ein einzelner Fehlschlag heisst deshalb meist nur "zu
   * schnell", nicht "kaputt". Bis zu dreimal versuchen mit wachsendem
   * Abstand, danach gilt das Ergebnis.
   */
  async function run(id: string, cmd: string) {
    const waits = [0, 2000, 6000];
    let last = await supervisor.command(id, cmd);
    for (const wait of waits.slice(1)) {
      if (last.ok) return last;
      await new Promise((r) => setTimeout(r, wait));
      last = await supervisor.command(id, cmd);
    }
    return last;
  }

  /**
   * Wie run(), aber prueft zusaetzlich die Vollstaendigkeit der Antwort.
   *
   * Das Plugin antwortet manchmal mit HTTP 200 und einer abgebrochenen
   * Ausgabe - verifiziert: `whitelist list` kommt als blosses
   * "\nWhitelist List" (15 Zeichen) zurueck, obwohl die Liste existiert. Als
   * leere Liste parsen waere gelogen, als Fehler melden waere falsch - also
   * erneut versuchen, bis `isComplete` die Antwort abnimmt oder die Versuche
   * aufgebraucht sind.
   */
  async function runComplete(id: string, cmd: string, isComplete: (output: string) => boolean) {
    const waits = [0, 1500, 4000];
    let last = await supervisor.command(id, cmd);
    for (const wait of waits.slice(1)) {
      if (last.ok && isComplete(last.output)) return last;
      await new Promise((r) => setTimeout(r, wait));
      last = await supervisor.command(id, cmd);
    }
    return last;
  }

  /** Account laden und Edition pruefen, sonst 404/400. */
  function javaOnly(id: string):
    | { ok: true; id: string }
    | { ok: false; code: number; error: string } {
    const account = getAccount(id);
    if (!account) return { ok: false, code: 404, error: 'Account nicht gefunden' };
    if (account.edition !== 'java') {
      return { ok: false, code: 400, error: 'Spieler, Zugriff und Module gibt es nur bei Java-Accounts' };
    }
    return { ok: true, id };
  }

  /**
   * Spieler in Sichtweite plus Serverliste.
   *
   * Zwei Befehle, parallel geschickt: `visualRange list` (wer steht neben dem
   * Bot) und `tablist` (wer ist ueberhaupt auf dem Server). Die Tablist kann
   * auf grossen Servern mehrere hundert Namen haben - deshalb gekuerzt, die
   * vollstaendige Liste braucht niemand zum Nachschauen.
   */
  app.get('/api/accounts/:id/players', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const gate = javaOnly(id);
    if (!gate.ok) return reply.code(gate.code).send({ error: gate.error });
    const [near, tab] = await Promise.all([
      // Vollstaendig heisst: die Einstellungszeilen sind dabei, nicht nur die
      // Kopfzeile. Abgebrochene Antworten (nur Titel, keine Daten) erneut holen.
      runComplete(id, 'visualRange list', (o) => /enter alerts|no players in visual range/i.test(o)),
      runComplete(id, 'tablist', (o) => o.includes('```')),
    ]);
    const nearby = near.ok ? parseVisualRange(near.output) : [];
    const server = tab.ok ? parseTablist(tab.output).slice(0, 200) : [];
    return { nearby, server, truncated: server.length >= 200 };
  });

  /**
   * Zugriffslisten: Vollzugriff (whitelist), Zuschauer (spectator whitelist),
   * Blockiert (blacklist).
   *
   * Das ist das Berechtigungssystem von ZenithProxy - mehr Stufen gibt es
   * nicht. Wer auf der Whitelist steht, darf den Account steuern und zusehen;
   * wer auf der Zuschauer-Liste steht, sieht nur zu; wer auf der Blacklist
   * steht, kommt gar nicht erst drauf.
   */
  app.get('/api/accounts/:id/access', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const gate = javaOnly(id);
    if (!gate.ok) return reply.code(gate.code).send({ error: gate.error });
    const [wl, spec] = await Promise.all([
      // Vollstaendig heisst: der Konfigurationsanhang ist dabei. Das Plugin
      // bricht Antworten manchmal nach der Kopfzeile ab (nur "\nWhitelist
      // List") - ohne Pruefung stuende die Liste fälschlich leer da.
      runComplete(id, 'whitelist list', (o) => /auto add zenith account/i.test(o)),
      runComplete(id, 'spectator whitelist list', (o) => /spectators/i.test(o)),
    ]);
    // Die Zuschauer-Liste braucht Account-Owner-Rechte in der Web-API. Steht
    // die Berechtigung nicht, kommt "Not Authorized" - das melden wir als
    // Hinweis statt als leere Liste, sonst sieht es aus, als duerfe niemand
    // zusehen, obwohl die Liste nur nicht lesbar ist.
    //
    // Die Blacklist hat keinen list-Befehl (weder `whitelist blacklist list`
    // noch nackt geben sie her - beide antworten mit der Whitelist). Sie ist
    // deshalb nur schreibbar: blockieren und entblocken geht, anzeigen nicht.
    return {
      whitelist: wl.ok ? parseAccessList(wl.output, 'whitelist') : [],
      spectator: spec.ok && !isNotAuthorized(spec.output) ? parseAccessList(spec.output, 'spectator') : [],
      spectatorBlocked: !spec.ok || isNotAuthorized(spec.output),
      blacklist: [],
      blacklistReadable: false,
    };
  });

  type AccessLevel = 'full' | 'watch' | 'blocked' | 'none';

  /**
   * Zugriffsstufe eines Spielers setzen.
   *
   * Ein Spieler steht immer auf hoechstens einer Liste: vor dem Eintragen
   * wird er von den anderen beiden entfernt. Die Entfernungen duerfen
   * fehlschlagen (er stand dort schlicht nicht) - nur das Eintragen selbst
   * muss klappen, sonst war alles umsonst.
   */
  app.post('/api/accounts/:id/access', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const gate = javaOnly(id);
    if (!gate.ok) return reply.code(gate.code).send({ error: gate.error });
    const body = req.body as { player?: string; level?: AccessLevel };
    const player = body.player?.trim() ?? '';
    const level = body.level;
    if (!/^[A-Za-z0-9_]{3,16}$/.test(player)) {
      return reply.code(400).send({ error: 'Ungültiger Spielername' });
    }
    if (level !== 'full' && level !== 'watch' && level !== 'blocked' && level !== 'none') {
      return reply
        .code(400)
        .send({ error: 'Stufe muss full, watch, blocked oder none sein' });
    }
    const remove: Record<AccessLevel, string[]> = {
      full: ['spectator whitelist del', 'whitelist blacklist del'],
      watch: ['whitelist del', 'whitelist blacklist del'],
      blocked: ['whitelist del', 'spectator whitelist del'],
      none: ['whitelist del', 'spectator whitelist del', 'whitelist blacklist del'],
    };
    for (const cmd of remove[level]) {
      await supervisor.command(id, `${cmd} ${player}`).catch(() => null);
    }
    if (level === 'none') return { ok: true };
    const add =
      level === 'full'
        ? `whitelist add ${player}`
        : level === 'watch'
          ? `spectator whitelist add ${player}`
          : `whitelist blacklist add ${player}`;
    const result = await run(id, add);
    if (!result.ok || isNotAuthorized(result.output)) {
      return reply.code(502).send({
        error: isNotAuthorized(result.output)
          ? 'ZenithProxy verweigert den Befehl (Not Authorized). Instanz neu starten, damit die Web-API-Berechtigung greift.'
          : (result.error || 'Befehl wurde nicht angenommen'),
      });
    }
    // Der HTTP-Aufruf kann klappen, waehrend ZenithProxy den Spieler
    // ablehnt: Namen werden ueber Mojang aufgeloest, und ein Tippfehler oder
    // ein nicht existierender Name endet in "Failed to add user ... Unable to
    // lookup profile". Das waere als ok:true gelogen - deshalb hier pruefen
    // und die Zeile von ZenithProxy direkt melden.
    const failed = firstLineMatching(
      result.output,
      /failed to add|unable to lookup|unknown player|player not found|invalid/i,
    );
    if (failed) {
      return reply.code(502).send({ error: failed });
    }
    return { ok: true };
  });

  /**
   * Modulzustaende mit Cache und Singleflight.
   *
   * Ein kompletter Abruf kostet 14 Befehle aus einem Budget von 30 pro Minute -
   * ohne Cache wuerde jedes Oeffnen des Menues das Budget fuer eine halbe
   * Minute belegen und alles andere (Status, Whitelist) verhungern lassen.
   * Darum: 60 s Cache, gleichzeitige Anfragen teilen sich einen laufenden
   * Abruf, und nach 25 s kommt zurueck, was da ist, statt endlos zu haengen.
   * Nach dem Umschalten wird der Cache verworfen (siehe POST unten).
   */
  app.get('/api/accounts/:id/modules', { preHandler: app.requireAuth }, async (req, reply) => {
    const { id } = req.params as { id: string };
    const gate = javaOnly(id);
    if (!gate.ok) return reply.code(gate.code).send({ error: gate.error });
    // Der Browser ist weg (Tab zu, Modal geschlossen): keine weiteren Befehle
    // verbrennen. Vorher lief eine abgebrochene Anfrage unsichtbar weiter und
    // hat minutenlang das Minutenbudget belegt.
    let aborted = false;
    req.raw.on('close', () => {
      aborted = true;
    });
    const cached = moduleCache.get(id);
    if (cached && Date.now() - cached.at < MODULE_TTL_MS) {
      return { modules: cached.states };
    }
    let inflight = moduleInflight.get(id);
    if (!inflight) {
      inflight = refreshModules(id, () => aborted);
      moduleInflight.set(id, inflight);
      // Nur aus der Karte nehmen, nie ablehnen lassen: refreshModules wirft
      // nicht, es liefert hoechstens null-Zustaende.
      void inflight.finally(() => {
        if (moduleInflight.get(id) === inflight) moduleInflight.delete(id);
      });
    }
    const states = await withTimeout(inflight, MODULE_OVERALL_TIMEOUT_MS, () =>
      cached ? cached.states : MODULES.map((m) => ({ id: m.id, enabled: null as boolean | null })),
    );
    return { modules: states };
  });

  /** Ein Modul an- oder ausschalten. */
  app.post(
    '/api/accounts/:id/modules/:module',
    { preHandler: app.requireAuth },
    async (req, reply) => {
      const { id, module } = req.params as { id: string; module: string };
      const gate = javaOnly(id);
      if (!gate.ok) return reply.code(gate.code).send({ error: gate.error });
      if (!isKnownModule(module)) {
        return reply.code(400).send({ error: 'Unbekanntes Modul' });
      }
      const body = req.body as { enabled?: boolean };
      if (typeof body?.enabled !== 'boolean') {
        return reply.code(400).send({ error: 'enabled muss true oder false sein' });
      }
      const result = await supervisor.command(id, `${module} ${body.enabled ? 'on' : 'off'}`);
      if (!result.ok) {
        return reply.code(502).send({ error: result.error || 'Befehl wurde nicht angenommen' });
      }
      // Der gelesene Zustand ist jetzt falsch - naechster Abruf liest neu.
      dropModuleCache(id);
      return { ok: true };
    },
  );

  // ------------------------------------------------------------ Live-Feed (SSE)

  app.get('/api/events', { preHandler: app.requireAuth }, async (req, reply) => {
    reply.raw.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no', // wichtig hinter einem Reverse Proxy
    });

    const send = (accounts: unknown): void => {
      reply.raw.write(`data: ${JSON.stringify(accounts)}\n\n`);
    };

    send(supervisor.viewAll());
    const unsubscribe = supervisor.subscribe(send);
    // Heartbeat, damit Proxies und Browser die Verbindung nicht schliessen.
    const heartbeat = setInterval(() => reply.raw.write(': ping\n\n'), 25_000);

    req.raw.on('close', () => {
      clearInterval(heartbeat);
      unsubscribe();
    });
  });

  // -------------------------------------------------------------- System

  app.get('/api/health', async () => ({ ok: true, uptime: process.uptime() }));

  app.get('/api/system', { preHandler: app.requireAuth }, async () => ({
    accounts: supervisor.viewAll().length,
    running: supervisor.viewAll().filter((a) => a.status.state === 'online').length,
    ports: supervisor.ports(),
    memory: process.memoryUsage(),
    node: process.version,
    editionDefaults: {
      java: { host: '2b2t.org', port: 25565, channel: config.zenith.platform, mcVersion: config.zenith.mcVersion },
      bedrock: { host: config.bedrock.defaultHost, port: config.bedrock.defaultPort },
    },
  }));
}
