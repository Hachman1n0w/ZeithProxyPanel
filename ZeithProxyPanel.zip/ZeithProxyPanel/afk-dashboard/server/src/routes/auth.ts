import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { randomBytes } from 'node:crypto';
import { config } from '../config';
import { hashPassword, verifyPassword } from '../crypto';
import { countUsers, createSession, createUser, destroySession, getUserByName, resolveSession } from '../db';

const COOKIE = 'afk_session';

/**
 * `requireAuth` wird per decorate() angehaengt und in allen Routen als
 * preHandler benutzt. Damit TypeScript das kennt, erweitern wir hier die
 * FastifyInstance-Schnittstelle.
 */
declare module 'fastify' {
  interface FastifyInstance {
    requireAuth: (req: FastifyRequest, reply: FastifyReply) => Promise<unknown>;
  }
  interface FastifyRequest {
    userId?: string;
  }
}

/**
 * Beim allerersten Start gibt es noch keinen Benutzer. Wir legen einen an und
 * drucken das Passwort ins Log - im LAN ist das ein vertraeglicher Weg, und
 * Passwoerter muessen nirgends in einer Datei auf der Platte liegen.
 */
export function ensureBootstrapUser(): void {
  if (countUsers() > 0) return;
  const password = randomBytes(12).toString('base64url');
  createUser(config.bootstrapUser, hashPassword(password));
  console.warn(
    [
      '',
      '================================================================',
      ' ERSTER START - Zugangsdaten fuer das Dashboard',
      `   Benutzername: ${config.bootstrapUser}`,
      `   Passwort:     ${password}`,
      ' Das Passwort wird nicht gespeichert - bitte jetzt notieren',
      ' und danach im Dashboard aendern.',
      '================================================================',
      '',
    ].join('\n'),
  );
}

function readSession(req: FastifyRequest): string | null {
  const fromCookie = req.cookies?.[COOKIE];
  if (fromCookie) return fromCookie;
  // EventSource kann keine Header setzen, SSE haengt deshalb am Query-Token.
  const q = (req.query as { token?: string } | undefined)?.token;
  return q ?? null;
}

export function attachAuth(app: FastifyInstance): void {
  /** Pre-Handler: ohne gueltige Session kein Zugriff. */
  app.decorate('requireAuth', async (req: FastifyRequest, reply: FastifyReply) => {
    const sid = readSession(req);
    const userId = sid ? resolveSession(sid) : null;
    if (!userId) {
      return reply.code(401).send({ error: 'Nicht angemeldet' });
    }
    (req as FastifyRequest & { userId?: string }).userId = userId;
  });

  app.post('/api/auth/login', async (req, reply) => {
    const body = req.body as { username?: string; password?: string } | undefined;
    const username = body?.username?.trim();
    const password = body?.password ?? '';
    if (!username || !password) {
      return reply.code(400).send({ error: 'Benutzername und Passwort noetig' });
    }
    const user = getUserByName(username);
    if (!user || !verifyPassword(password, user.password_hash)) {
      // Absichtlich keine Unterscheidung zwischen "unbekannt" und "falsches
      // Passwort" - das wuerde Usern verraten, welche Namen existieren.
      return reply.code(401).send({ error: 'Benutzername oder Passwort falsch' });
    }
    const sid = createSession(user.id, config.sessionTtlMs);
    reply.setCookie(COOKIE, sid, {
      path: '/',
      httpOnly: true,
      sameSite: 'lax',
      secure: false, // LAN ohne TLS; bei HTTPS-Reverse-Proxy auf true setzen
      maxAge: Math.floor(config.sessionTtlMs / 1000),
    });
    return { ok: true, username };
  });

  app.post('/api/auth/logout', async (req, reply) => {
    const sid = readSession(req);
    if (sid) destroySession(sid);
    reply.clearCookie(COOKIE, { path: '/' });
    return { ok: true };
  });

  app.get('/api/auth/me', async (req, reply) => {
    const sid = readSession(req);
    const userId = sid ? resolveSession(sid) : null;
    if (!userId) return reply.code(401).send({ error: 'Nicht angemeldet' });
    return { ok: true };
  });
}
