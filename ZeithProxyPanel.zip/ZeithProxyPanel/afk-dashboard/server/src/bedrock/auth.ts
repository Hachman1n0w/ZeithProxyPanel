import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';

/**
 * Verwaltung der Xbox-Live-Anmeldung fuer Bedrock-Accounts.
 *
 * Die eigentliche Auth-Kette macht `bedrock-protocol` ueber `prismarine-auth`:
 * Device-Code-Flow bei Microsoft, danach Live/XBL/XSTS/PlayFab automatisch.
 * Wir muessen nur den Device-Code auffangen und dem Dashboard geben, damit der
 * Benutzer ihn bestaetigen kann - ohne die Kette selbst nachzubauen.
 *
 * Das ist der Grund, warum der Bedrock-Teil machbar ist: die heikle Arbeit
 * liegt in einer gepflegten Bibliothek und nicht in unserem Code.
 */

export type AuthStatus = 'unknown' | 'waiting' | 'ready' | 'failed';

export interface DeviceCode {
  userCode: string;
  verificationUri: string;
  verificationUriComplete: string | null;
  expiresAt: number;
}

export interface AuthState {
  status: AuthStatus;
  deviceCode: DeviceCode | null;
  error: string | null;
  /** Xbox-Profilname, sobald wir ihn kennen. */
  profileName: string | null;
}

const states = new Map<string, AuthState>();

function get(id: string): AuthState {
  let s = states.get(id);
  if (!s) {
    s = { status: 'unknown', deviceCode: null, error: null, profileName: null };
    states.set(id, s);
  }
  return s;
}

export function authState(id: string): AuthState {
  return { ...get(id) };
}

export function setWaiting(id: string, code: DeviceCode): void {
  states.set(id, { status: 'waiting', deviceCode: code, error: null, profileName: null });
}

export function setReady(id: string, profileName: string | null): void {
  states.set(id, { status: 'ready', deviceCode: null, error: null, profileName });
}

export function setFailed(id: string, error: string): void {
  states.set(id, { status: 'failed', deviceCode: null, error, profileName: null });
}

export function resetAuth(id: string): void {
  states.set(id, { status: 'unknown', deviceCode: null, error: null, profileName: null });
}

/**
 * Callback, den wir an bedrock-protocol reichen. Die Antwort kommt direkt vom
 * Microsoft-Device-Code-Endpoint; wir picken nur die Felder, die das UI braucht.
 */
export function makeMsaCallback(id: string): (data: unknown) => void {
  return (data: unknown) => {
    const d = (data ?? {}) as Record<string, unknown>;
    const userCode = typeof d.user_code === 'string' ? d.user_code : null;
    if (!userCode) return;
    const expiresIn = typeof d.expires_in === 'number' ? d.expires_in : 900;
    setWaiting(id, {
      userCode,
      verificationUri: typeof d.verification_uri === 'string' ? d.verification_uri : 'https://microsoft.com/devicelogin',
      verificationUriComplete:
        typeof d.verification_uri_complete === 'string' ? d.verification_uri_complete : null,
      expiresAt: Date.now() + expiresIn * 1000,
    });
  };
}

/**
 * Gibt es schon einen gecachten Login? prismarine-auth legt je Kette eine
 * Datei im profilesFolder ab. Ein vorhandener "live"-Cache heisst: Microsoft
 * wurde schon bestaetigt, der Token laesst sich refreshen ohne erneuten Code.
 */
export async function hasCachedLogin(authDir: string): Promise<boolean> {
  try {
    const entries = await fsp.readdir(authDir);
    return entries.some((e) => e.includes('_live-cache.json') || e.includes('_msa-cache.json'));
  } catch {
    return false;
  }
}

export async function authFiles(authDir: string): Promise<string[]> {
  try {
    return (await fsp.readdir(authDir)).filter((e) => e.endsWith('.json'));
  } catch {
    return [];
  }
}

/** Caches loeschen - noetig wenn Microsoft eine Anmeldung zurueckgewiesen hat. */
export async function clearCachedLogin(authDir: string): Promise<void> {
  const files = await authFiles(authDir);
  await Promise.all(
    files.map((f) => fsp.rm(path.join(authDir, f), { force: true }).catch(() => {})),
  );
  resetAuthByDir(authDir);
}

function resetAuthByDir(_authDir: string): void {
  // Der Zustand haengt an der Account-ID, nicht am Ordner. Wer den Cache
  // leert, setzt ihn zurueck - die ID ermittelt der Aufrufer.
  for (const [id, state] of states) {
    if (state.status !== 'ready') states.set(id, { ...state, status: 'unknown', deviceCode: null, error: null });
  }
}

/** Alle bekannten Auth-Zustaende - fuer Debug/Health. */
export function allAuthStates(): Record<string, AuthState> {
  return Object.fromEntries([...states].map(([k, v]) => [k, { ...v }]));
}

export function authDirExists(authDir: string): boolean {
  return fs.existsSync(authDir);
}
