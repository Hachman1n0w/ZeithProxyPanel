import type { Vec3 } from '../types';

/**
 * Bedrock-Bots muessen im Takt Position melden, sonst wirft der Server sie
 * raus. Java ist da forgiving, Bedrock nicht: es gibt keine "stehe einfach still"
 * -Option, es wird erwartet, dass ca. 20x pro Sekunde ein PlayerAuthInput
 * kommt.
 *
 * Wir senden deshalb einen Tick-Loop mit sehr kleinem Pendeln. Das hat zwei
 * Gruende:
 *
 *  1. Der Bot ist dann fuer den Server ein normaler, lebender Spieler.
 *  2. ViaBedrock auf 2b2t macht Verhaltenspruefungen. Ein Bot, der exakt
 *     starr steht, faellt auf.
 *
 * WICHTIG - versionssensitiv: Die Feldnamen von PlayerAuthInput haben sich
 * zwischen den Bedrock-Versionen geaendert (z.B. wurde `rotation` in
 * `pitchRot`/`yawRot` umbenannt). Wir senden beide-varianten Felder, damit wir
 * nicht an jedem Protokollupdate kleben. Sollte der Server das Paket trotzdem
 * ablehnen, landet der Fehler in lastError und ist im UI sichtbar - wir
 * schlucken ihn nicht still.
 */

export interface TickStats {
  ticks: number;
  lastError: string | null;
  lastTickAt: number;
}

const TICK_MS = 50; // 20 Hz

export class MovementTicker {
  private timer: NodeJS.Timeout | null = null;
  private phase = 0;
  private origin: Vec3 = { x: 0, y: 0, z: 0 };
  private synced = false;

  ticks = 0;
  lastError: string | null = null;
  lastTickAt = 0;

  constructor(
    private readonly client: {
      write: (name: string, params: unknown) => void;
      queue: (name: string, params: unknown) => void;
    },
    private readonly amplitude: number,
    private readonly intervalMs = TICK_MS,
  ) {}

  /** Basisposition setzen, sobald der Server uns unsere Koordinaten meldet. */
  setOrigin(pos: Vec3): void {
    this.origin = pos;
    this.synced = true;
  }

  get syncedToServer(): boolean {
    return this.synced;
  }

  start(): void {
    if (this.timer) return;
    this.timer = setInterval(() => this.tick(), this.intervalMs);
    // Verhindert, dass der Loop den Node-Prozess am Leben haelt.
    this.timer.unref?.();
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }

  get running(): boolean {
    return this.timer !== null;
  }

  private tick(): void {
    try {
      // Sinusfoermig hin und her, damit die Bewegung organic wirkt statt wie
      // ein starrer Roboter.
      this.phase += 0.05;
      const dx = Math.sin(this.phase) * this.amplitude;

      const pos = {
        x: this.origin.x + dx,
        y: this.origin.y,
        z: this.origin.z,
      };

      this.client.write('player_auth_input', {
        pos: [pos.x, pos.y, pos.z],
        delta: [dx, 0, 0],
        // Aeltere Protokolle...
        position: [pos.x, pos.y, pos.z],
        positionDelta: [dx, 0, 0],
        rotation: { x: 0, y: 0 },
        // ...und neuere.
        pitchRot: 0,
        yawRot: 0,
        bodyYawRot: 0,
        headYawRot: 0,
        inputMode: 0,
        interactMode: 0,
        interactModeLite: 0,
        inputFlags: {
          isSneaking: false,
          isSprinting: false,
          isSwimming: false,
          isJumping: false,
          isInClimbable: false,
          isSneakingDown: false,
          isImmobile: false,
        },
        // Ohne korrekte Unique-IDs lehnt manche Serverversionen das Paket ab.
        moveActorUniqueId: BigInt(1),
        interactActorUniqueId: BigInt(0),
        tick: BigInt(this.ticks + 1),
      });

      this.ticks += 1;
      this.lastTickAt = Date.now();
      this.lastError = null;
    } catch (err) {
      // Nicht weiter werfen - der Verbindungszustand ist die eigentliche
      // Information, und der Fehler steht im UI.
      this.lastError = (err as Error).message;
    }
  }

  stats(): TickStats {
    return { ticks: this.ticks, lastError: this.lastError, lastTickAt: this.lastTickAt };
  }
}
