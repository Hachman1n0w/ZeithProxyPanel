import { config } from '../config';
import type { Account, AccountStatus, CommandResult, Driver } from '../types';
import { makeMsaCallback, resetAuth, setFailed, setReady } from '../bedrock/auth';
import { MovementTicker } from '../bedrock/movement';

/**
 * Treiber fuer Bedrock-Accounts.
 *
 * Anders als bei Java gibt es hier keinen externen Prozess: der Bot laeuft
 * direkt im Node-Prozess. Das ist deutlich leichter (~150 MB statt ~600 MB),
 * bringt aber eine Eigenschaft mit - faellt der Node-Prozess aus, sind alle
 * Bedrock-Accounts weg. Deshalb startet der Supervisor sie nach einem
 * Neustart automatisch neu.
 *
 * `bedrock-protocol` ist eine optionale Abhaengigkeit. Fehlt das Paket
 * (native RakNet-Backend nicht gebaut), meldet der Treiber das klar, statt
 * einen leeren Account zu zeigen.
 */

type BedrockClient = {
  on: (event: string, cb: (...args: never[]) => void) => void;
  write: (name: string, params: unknown) => void;
  close: () => void;
  disconnect: (reason?: string) => void;
  username?: string;
  profile?: { name: string; xuid: number };
  options: Record<string, unknown>;
};

let bedrockModule: typeof import('bedrock-protocol') | null | undefined;

function loadBedrock(): typeof import('bedrock-protocol') | null {
  if (bedrockModule !== undefined) return bedrockModule;
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    bedrockModule = require('bedrock-protocol') as typeof import('bedrock-protocol');
  } catch (err) {
    bedrockModule = null;
    console.error(
      '[bedrock] bedrock-protocol nicht ladbar. Bedrock-Accounts bleiben offline. Ursache:',
      (err as Error).message,
    );
  }
  return bedrockModule;
}

export class BedrockDriver implements Driver {
  readonly edition = 'bedrock' as const;

  private client: BedrockClient | null = null;
  private ticker: MovementTicker | null = null;
  private state: AccountStatus['state'] = 'stopped';
  private connectedPlayer: string | null = null;
  private ping: number | null = null;
  private health: number | null = null;
  private position: { x: number; y: number; z: number } | null = null;
  private playtimeSec: number | null = null;
  private lastError: string | null = null;
  private connectedAt: number | null = null;
  private stopping = false;
  private reconnectTimer: NodeJS.Timeout | null = null;

  constructor(private readonly account: Account) {}

  isRunning(): boolean {
    return this.client !== null;
  }

  async start(): Promise<void> {
    if (this.client) return;
    const bedrock = loadBedrock();
    if (!bedrock) {
      this.lastError =
        'bedrock-protocol ist nicht installiert. Bitte das Image neu bauen oder das Paket nachinstallieren.';
      this.state = 'error';
      return;
    }

    const authDir = this.account.authDir ?? config.instanceRoot;
    this.stopping = false;
    this.state = 'starting';
    this.lastError = null;

    // Den Anmeldezustand vor dem Verbindungsversuch zuruecksetzen. onMsaCode
    // setzt ihn auf "waiting", sobald Microsoft wirklich nach einem Code fragt.
    // Ohne dieses Zuruecksetzen zeigte die UI nach einem Neustart noch den
    // alten, laengst abgelaufenen Code an.
    resetAuth(this.account.id);

    let client: BedrockClient;
    try {
      client = bedrock.createClient({
        host: this.account.serverHost,
        port: this.account.serverPort,
        username: this.account.username,
        profilesFolder: authDir,
        offline: false,
        onMsaCode: makeMsaCallback(this.account.id),
        // Reine JS-Variante: raknet-native muesste im Image kompiliert werden
        // und scheitert regelmaessig. Siehe config.ts.
        raknetBackend: config.bedrock.raknetBackend as 'jsp-raknet',
      }) as unknown as BedrockClient;
    } catch (err) {
      this.state = 'error';
      this.lastError = `Verbindung konnte nicht aufgebaut werden: ${(err as Error).message}`;
      setFailed(this.account.id, this.lastError);
      return;
    }

    this.client = client;
    this.wireEvents(client, bedrock);
  }

  private wireEvents(
    client: BedrockClient,
    bedrock: typeof import('bedrock-protocol'),
  ): void {
    const ping = async (): Promise<void> => {
      // Die RakNet-Antwort enthaelt keinen brauchbaren Ping-Wert (UDP auf
      // 2b2t ist zu unzuverlaessig). Wir messen deshalb selbst, wie lange der
      // Roundtrip zum Server wirklich dauert.
      const started = Date.now();
      try {
        await bedrock.ping({ host: this.account.serverHost, port: this.account.serverPort });
        this.ping = Date.now() - started;
      } catch {
        this.ping = null;
      }
    };

    client.on('connect' as never, (() => {
      this.state = 'connecting';
      this.connectedPlayer = null;
      void ping();
    }) as never);

    client.on('login' as never, (() => {
      this.state = 'connecting';
    }) as never);

    client.on('join' as never, (() => {
      this.state = 'connecting';
    }) as never);

    client.on('spawn' as never, (() => {
      this.state = 'online';
      this.connectedAt = Date.now();
      this.lastError = null;
      setReady(this.account.id, client.profile?.name ?? this.account.username);
      this.startTicker(client);
    }) as never);

    client.on('session' as never, ((profile: { name?: string }) => {
      if (profile?.name) this.connectedPlayer = profile.name;
    }) as never);

    client.on('disconnect' as never, ((packet: { message?: string }) => {
      const reason = packet?.message ? `Server hat getrennt: ${packet.message}` : 'Vom Server getrennt';
      this.handleDrop(reason, true);
    }) as never);

    client.on('close' as never, (() => {
      this.handleDrop('Verbindung geschlossen', false);
    }) as never);

    client.on('error' as never, ((err: Error) => {
      this.lastError = err.message;
      this.state = 'error';
      setFailed(this.account.id, err.message);
    }) as never);

    // Lebenserwartung
    client.on('health' as never, ((packet: unknown) => {
      const p = packet as { health?: number };
      if (typeof p?.health === 'number') this.health = p.health;
    }) as never);

    client.on('move_player' as never, ((packet: unknown) => {
      const p = packet as { position?: { x: number; y: number; z: number } };
      if (p?.position) {
        this.position = p.position;
        this.ticker?.setOrigin(p.position);
      }
    }) as never);
  }

  private startTicker(client: BedrockClient): void {
    if (this.ticker?.running) return;
    this.ticker = new MovementTicker(
      client as never,
      config.bedrock.wanderAmplitude,
      50,
    );
    this.ticker.start();
  }

  private handleDrop(reason: string, serverInitiated: boolean): void {
    this.ticker?.stop();
    this.ticker = null;
    this.client = null;
    this.state = 'stopped';
    this.health = null;
    this.position = null;
    this.connectedAt = null;
    this.connectedPlayer = null;
    this.lastError = reason;

    if (serverInitiated) {
      // 2b2t trennt nach einer Weile Inaktivitaet oder bei Regelverstoss. Das
      // ist ein Signal, dass man dem Account nachsehen sollte.
      setFailed(this.account.id, reason);
    }

    if (this.stopping || !this.account.autoReconnect) return;
    if (this.reconnectTimer) return;
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      void this.start().catch(() => {});
    }, config.bedrock.reconnectDelayMs);
    this.reconnectTimer.unref?.();
  }

  async stop(): Promise<void> {
    this.stopping = true;
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.ticker?.stop();
    this.ticker = null;
    const client = this.client;
    this.client = null;
    this.state = 'stopped';
    if (client) {
      try {
        client.disconnect('Dashboard: gestoppt');
      } catch {
        /* egal */
      }
      setTimeout(() => {
        try {
          client.close();
        } catch {
          /* egal */
        }
      }, 500).unref?.();
    }
  }

  async status(): Promise<AccountStatus> {
    let playtime: number | null = null;
    if (this.connectedAt) {
      playtime = Math.floor((Date.now() - this.connectedAt) / 1000);
    }
    // Wenn der Ticker Fehler schmeisst, ist das wichtiger als der Zustand.
    const tickError = this.ticker?.lastError ?? null;
    return {
      state: this.state,
      connectedPlayer: this.connectedPlayer,
      // Der Bedrock-Bot nimmt Verbindungen an, statt eine anzubieten. Es gibt
      // also keine Adresse, die man weiterreichen koennte.
      proxyIp: null,
      // Kein Proxy, keine Sichtweite.
      nearby: null,
      ping: this.ping,
      health: this.health,
      position: this.position,
      dimension: null,
      queue: null,
      playtimeSec: playtime,
      source: 'bedrock',
      // Bedrock meldet seinen Device-Code ueber die eigene Auth-Kette, nicht
      // ueber das Log. Der kommt aus authState()/AuthPanel.
      authUrl: null,
      lastError: this.lastError ?? tickError,
      updatedAt: Date.now(),
    };
  }

  async command(): Promise<CommandResult> {
    return {
      ok: false,
      output: '',
      error:
        'Bedrock-Bots kennen keine Befehlszeile. Steuerung laeuft ueber die automatische ' +
        'Warteschlange; ZenithProxy-Befehle gibt es nur bei Java-Accounts.',
    };
  }

  tickStats(): { ticks: number; lastError: string | null } {
    return this.ticker?.stats() ?? { ticks: 0, lastError: null };
  }

  async dispose(): Promise<void> {
    await this.stop().catch(() => {});
  }
}
