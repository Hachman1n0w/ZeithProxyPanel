import { spawn, type ChildProcess } from 'node:child_process';
import fs from 'node:fs';
import { config } from '../config';
import { decryptSecret } from '../crypto';
import { getAccountSecret, setAccountServer } from '../db';
import type { Account, AccountStatus, CommandResult, Driver } from '../types';
import { ZenithClient, ZenithError, extractText } from '../zenith/client';
import { LogTailer } from '../zenith/logtail';
import {
  findLogFile,
  instanceDir,
  prepareInstance,
  processLogPath,
  readPluginConfig,
} from '../zenith/launcher';
import { reapInstanceProcesses } from '../zenith/procs';
import {
  isLoggedIn,
  parseDeviceCode,
  withAuthUrl,
  type ParsedDeviceCode,
} from '../zenith/devicecode';
import { parseVisualRange } from '../zenith/modules';
import {
  parseConnectedPlayer,
  parseCoords,
  parseDimension,
  parseDuration,
  parseHealth,
  parsePing,
  parseProxyIp,
  parsePriorityQueue,
  parseQueue,
  parseServerAddress,
  parseZenithOutput,
} from '../zenith/parse';

/**
 * Treiber fuer Java-Accounts: startet eine ZenithProxy-Instanz als Kindprozess
 * und steuert sie ueber das WebAPI-Plugin.
 *
 * Steuerung hat zwei Wege, weil es einen echten Haken gibt:
 *
 *  1. "webapi"  - die Web-API antwortet. Volle Kontrolle, alle Befehle,
 *                 exakte Statuswerte. Das ist der Normalfall.
 *  2. "logtail" - die Web-API kam nicht hoch (Plugin nicht geladen, Port
 *                 belegt, ...). Wir parsen dann das Logfile und liewen einen
 *                 groberen, als ungefaehr markierten Status.
 *
 * Welcher Weg aktiv ist, steht in AccountStatus.source und wird im UI angezeigt.
 * Man kann ihn niestumm sehen - ein stillschweigend degradiertes Dashboard waere
 * schlimmer als ein rotes.
 */
export class ZenithDriver implements Driver {
  readonly edition = 'java' as const;

  private proc: ChildProcess | null = null;
  private client: ZenithClient | null = null;
  private tailer = new LogTailer();
  private control: 'webapi' | 'logtail' = 'logtail';
  private bootError: string | null = null;
  private logStream: fs.WriteStream | null = null;
  private stopping = false;
  /** Anmeldelink, den ZenithProxy ins Log geschrieben hat, falls einer kam. */
  private authLink: ParsedDeviceCode | null = null;

  constructor(
    private readonly account: Account,
    private readonly token: string,
  ) {}

  isRunning(): boolean {
    return this.proc !== null && this.proc.exitCode === null && !this.proc.killed;
  }

  get pid(): number | null {
    return this.proc?.pid ?? null;
  }

  get controlMode(): 'webapi' | 'logtail' {
    return this.control;
  }

  async start(): Promise<void> {
    if (this.isRunning()) return;
    this.stopping = false;
    this.bootError = null;
    this.control = 'logtail';
    this.authLink = null;

    const dir = instanceDir(this.account);
    // Reste eines harten Abbruchs beseitigen. Ein Waise-Prozess haelt den
    // MC-Port, den WebAPI-Port und die .lock - jeder weitere Startversuch
    // bricht dann mit "Multiple ZenithProxy Instances Open" ab, und weil das
    // Dashboard den Fehler nur im Instanz-Log sieht, wirkt es wie ein
    // Startproblem statt wie ein Aufraeumproblem.
    const strays = await reapInstanceProcesses(dir);
    if (strays.length > 0) {
      this.logStream?.write(
        `Bereinigt: ${strays.length} verwaiste(n) Prozess(e) dieser Instanz beendet\n`,
      );
    }

    await prepareInstance(this.account, this.token);

    const logPath = processLogPath(dir);
    this.logStream = fs.createWriteStream(logPath, { flags: 'a' });
    this.logStream.write(`\n===== Start ${new Date().toISOString()} =====\n`);

    const env: NodeJS.ProcessEnv = {
      ...process.env,
      // Ohne Discord brauchen wir die restlichen ZENITH_DISCORD_* nicht.
      ZENITH_DISCORD_DISABLED: 'true',
      ZENITH_MC_VERSION: config.zenith.mcVersion,
      ZENITH_PLATFORM: config.zenith.platform,
      ZENITH_PORT: String(this.account.mcPort ?? 25565),
      ZENITH_IP: '127.0.0.1',
    };

    this.proc = spawn('./launch', ['--unattended'], {
      cwd: dir,
      env,
      stdio: ['pipe', 'pipe', 'pipe'],
      // Eigene Prozessgruppe: ./launch startet die JVM als Kindprozess, und
      // proc.kill() erreicht Enkel nicht. Mit eigener Gruppe koennen wir
      // beides zusammen beenden - siehe stop().
      detached: true,
    });

    this.proc.stdout?.on('data', (c: Buffer) => this.onOutput(c));
    this.proc.stderr?.on('data', (c: Buffer) => this.onOutput(c));
    this.proc.on('exit', (code, signal) => {
      this.logStream?.write(`===== Beendet: code=${code} signal=${signal} =====\n`);
      this.proc = null;
    });
    this.proc.on('error', (err) => {
      this.bootError = `Prozess konnte nicht gestartet werden: ${err.message}`;
      this.proc = null;
    });

    // Log der ZenithProxy-Instanz mitbeobachten, falls es eins gibt.
    const own = await findLogFile(dir);
    if (own) this.tailer.watch(own);

    const ready = await this.probeWebApi();
    if (ready) await this.joinServer();
  }

  private onOutput(chunk: Buffer): void {
    const text = chunk.toString('utf8');
    this.logStream?.write(text);
    this.tailer.push(text);
    // Der Geraetecode steht nur im Log. Ihn hier abgreifen, damit die
    // Oberflaeche ihn anzeigen kann, ohne dass man das Log aufklappen muss -
    // sonst wartet der Instanz-Start scheinbar grundlos auf eine Eingabe.
    const code = parseDeviceCode(text);
    if (code && code.url !== this.authLink?.url) {
      this.authLink = code;
    }
    // Sobald die Anmeldung durch ist, hat der Code ausgedient. Ohne das
    // bliebe er als abgelaufener Hinweis in der Kartenansicht stehen, waehrend
    // der Account laengst laeuft.
    if (this.authLink && isLoggedIn(text)) {
      this.authLink = null;
    }
  }

  /**
   * Herausfinden, ob die Web-API erreichbar ist, und sie notfalls auf den
   * zugewiesenen Port umhaengen.
   *
   * Ablauf: plugins/config/web-api.json lesen (dort stehen Port und authToken)
   * -> zugewiesenen Port testen -> als Alternative 8080 testen und die
   * Instanz von dort aus auf den richtigen Port schieben.
   *
   * Liefert true, wenn die Web-API am Ende steht. Dann ist this.client
   * gesetzt und Befehle koennen raus.
   */
  private async probeWebApi(): Promise<boolean> {
    const deadline = Date.now() + config.zenith.startupProbeMs;
    const wanted = this.account.webapiPort ?? 8080;

    while (Date.now() < deadline) {
      if (!this.isRunning()) {
        this.control = 'logtail';
        return false;
      }

      const plugin = await readPluginConfig(instanceDir(this.account)).catch(() => null);
      const token = plugin?.authToken ?? this.token;
      const port = plugin?.port ?? wanted;

      if (await this.tryClient(port, token)) {
        this.control = 'webapi';
        return true;
      }

      // Laeuft sie noch auf dem Default-Port 8080? Dann von dort umhaengen.
      if (port !== 8080 && (await this.tryClient(8080, token))) {
        try {
          await this.client!.command(`webApi port ${wanted}`);
          await new Promise((r) => setTimeout(r, 1500));
          if (await this.tryClient(wanted, token)) {
            this.control = 'webapi';
            return true;
          }
        } catch {
          /* Umhaengen hat nicht geklappt -> logtail */
        }
      }

      await new Promise((r) => setTimeout(r, 2000));
    }

    this.control = 'logtail';
    this.bootError = this.bootError ?? 'Web-API antwortet nicht - Status wird aus dem Log gelesen';
    return false;
  }

  /**
   * Anmelden, Zielserver setzen, verbinden.
   *
   * Das ist der Teil, der eine Java-Instanz erst brauchbar macht. Ohne die
   * Schritte hier startet sie zwar sauber, meldet sich aber nie an und
   * verbindet sich zu nichts - sie sieht im Dashboard dann aus, als laeufe sie,
   * ist aber nutzlos.
   *
   * Alles laeuft ueber die Web-API, die ZenithProxy dafuer selbst anbietet:
   *   auth type prism|deviceCode   Anmeldeweg
   *   auth email/password          Zugangsdaten (nur prism)
   *   server <host> <port>         Zielserver
   *   connect                      verbinden
   *
   * `antiAFK` wird bewusst NICHT eingeschaltet. Es ist zwar der naheliegende
   * Kandidat fuer genau dieses Vorhaben, aber der Bot soll stillstehen wie
   * ein normaler Spieler - das Modul schwingt und laeuft aktiv herum und ist
   * damit eher das auffaelligste, was man machen kann. Wer es doch will,
   * schickt `antiAFK on` ueber die Konsole in der Detailansicht.
   *
   * Fehler werden nicht geworfen, sondern in bootError gelegt: Eine Instanz,
   * die laeuft und deren Status man sehen kann, ist nuetzlicher als eine, die
   * beim Start abbricht und aus dem Log erraten werden muss.
   */
  private async joinServer(): Promise<void> {
    if (!this.client) return;
    const send = async (cmd: string): Promise<void> => {
      await this.client!.command(cmd).catch(() => {
        this.bootError = `Befehl fehlgeschlagen: ${cmd}`;
      });
    };

    // 1. Anmeldeweg. deviceCode nutzt den Microsoft-Geraetecode-Flow, bei dem
    //    kein Passwort gespeichert werden muss - deshalb der Standard.
    await send(`auth type ${this.account.authType === 'prism' ? 'prism' : 'deviceCode'}`);

    // 2. Zugangsdaten, falls Klartext-Anmeldung gewaehlt ist.
    if (this.account.authType === 'prism') {
      const password = getAccountSecret(this.account.id);
      if (password) {
        await send(`auth email ${this.account.username}`);
        await send(`auth password ${decryptSecret(password)}`);
        // 2b2t verlangt bei Prismarine gelegentlich eine zweite Anmeldung.
        await send('auth attempts 3');
      } else {
        this.bootError =
          'Anmeldung ist auf prism gestellt, aber es ist kein Passwort hinterlegt.';
      }
    }

    // 3. Zielserver. Auch wenn er schon in config.json steht: das `server`
    //    ist der Weg, den ZenithProxy selbst dokumentiert, und es faengt
    //    Konfigurationsfehler in config.json ab.
    await send(`server ${this.account.serverHost} ${this.account.serverPort}`);

    // 4. Verbinden.
    await send('connect');
  }

  private async tryClient(port: number, token: string): Promise<boolean> {
    const client = new ZenithClient(port, token);
    if (await client.probe(3000)) {
      this.client = client;
      return true;
    }
    return false;
  }

  async stop(): Promise<void> {
    this.stopping = true;
    const proc = this.proc;
    const dir = instanceDir(this.account);
    if (!proc) {
      // Auch ohne eigenen Kindprozess aufräumen - nach einem harten Abbruch
      // kann die JVM noch laufen, dann wäre ein späterer Start blockiert.
      await reapInstanceProcesses(dir);
      return;
    }

    // Erst ordentlich trennen, damit die Instanz sauber aus der Queue geht.
    try {
      if (this.client && this.control === 'webapi') {
        await this.client.command('disconnect').catch(() => {});
      }
    } catch {
      /* egal, SIGTERM gleich */
    }

    // Die Prozessgruppe beenden, nicht nur ./launch: die JVM ist ein
    // Enkelprozess und wuerde sonst weiterlaufen, den MC-Port halten und die
    // .lock blockieren. Das negative pid signalisiert genau diese Gruppe.
    const pid = proc.pid;
    if (pid) {
      try {
        process.kill(-pid, 'SIGTERM');
      } catch {
        proc.kill('SIGTERM');
      }
    }
    const killed = await waitForExit(proc, 15_000);
    if (!killed) {
      try {
        if (pid) process.kill(-pid, 'SIGKILL');
        else proc.kill('SIGKILL');
      } catch {
        /* schon weg */
      }
    }
    this.proc = null;

    // Nachsorge: was die Gruppe nicht erwischt hat.
    await reapInstanceProcesses(dir);
  }

  async status(): Promise<AccountStatus> {
    if (!this.isRunning()) {
      const base = this.tailer.status(false);
      if (this.bootError) base.lastError = this.bootError;
      return withAuthUrl(base, this.authLink);
    }

    if (this.control === 'webapi' && this.client) {
      try {
        const res = await this.client.command('status');
        const status = this.mapStatus(extractText(res));
        if (this.bootError) status.lastError = this.bootError;
        // Ein Befehl mehr pro Abruf (Limit: 30/min) - dafuer weiss die Karte
        // ohne Extra-Klick, ob jemand neben dem Bot steht.
        status.nearby = await this.readNearby();
        return withAuthUrl(status, this.authLink);
      } catch (err) {
        if (err instanceof ZenithError && (err.status === 401 || err.status === 403)) {
          // Token passt nicht mehr - zurueck auf Log-Modus statt zu raten.
          this.control = 'logtail';
        }
        const fallback = this.tailer.status(true);
        fallback.lastError = `Web-API nicht erreichbar (${(err as Error).message})`;
        return withAuthUrl(fallback, this.authLink);
      }
    }

    const s = this.tailer.status(true);
    if (this.bootError) s.lastError = this.bootError;
    return withAuthUrl(s, this.authLink);
  }



  /**
   * Spieler in Sichtweite lesen.
   *
   * Laeuft als zweiter Befehl im Status-Abruf. Absichtlich eine eigene
   * Methode: Sichtweite ist Zusatzinfo, und wenn sie scheitert, darf das den
   * Hauptstatus nicht mitreissen - deshalb das try/catch mit null.
   */
  private async readNearby(): Promise<AccountStatus['nearby']> {
    if (!this.client || this.control !== 'webapi') return null;
    try {
      const res = await this.client.command('visualRange list');
      const names = parseVisualRange(extractText(res));
      return { count: names.length, names: names.slice(0, 6) };
    } catch {
      // Sichtweite ist Zusatzinfo: wenn der Befehl scheitert, bleibt der
      // Rest des Status trotzdem gueltig.
      return null;
    }
  }

  /** Klartext aus `status` in unser Statusobjekt uebersetzen. */
  private mapStatus(text: string): AccountStatus {
    const raw = parseZenithOutput({
      embed: text,
      multiLineOutput: text.split('\n'),
    });

    const statusRaw = raw['Status']?.trim() ?? '';
    const connectedPlayer = parseConnectedPlayer(raw['Connected Player']);
    const hasPriority = parsePriorityQueue(raw['Priority Queue']);
    const queue = parseQueue(raw['2b2t Queue']);

    // ZenithProxy meldet im Feld "Status" unter anderem "Online",
    // "Connected" (mit dem Zielserver verbunden, aber noch nicht im Spiel -
    // etwa weil man in der 2b2t-Queue steht) und "Disconnected".
    //
    // "Online" hat Vorrang vor der Queue: das Feld "2b2t Queue" nennt die
    // Warteschlangen des Servers, nicht die eigene Position. Auf Donutsmp
    // steht dort dauerhaft "Regular: 555", waehrend man selbst längst im
    // Spiel ist - wer die Queue zuerst prueft, haelt einen laufenden Bot
    // ewig fuer wartend.
    let state: AccountStatus['state'] = 'starting';
    if (/^disconnected/i.test(statusRaw)) {
      state = 'starting';
    } else if (/^online/i.test(statusRaw)) {
      state = 'online';
    } else if (/^connect/i.test(statusRaw)) {
      state = queue && (queue.priority !== null || queue.regular !== null) ? 'queued' : 'connecting';
    }
    if (connectedPlayer) state = 'online';

    const playtimeSec = parseDuration(raw['Online Duration'] ?? raw['Online For']);
    const server = parseServerAddress(raw['Server']);

    // Meldet ZenithProxy einen anderen Zielserver als konfiguriert, uebernehmen
    // wir das - sonst zeigt das Dashboard dauerhaft etwas Falsches an.
    if (server && server.host !== this.account.serverHost) {
      setAccountServer(this.account.id, server.host, server.port);
    }

    return {
      state,
      connectedPlayer,
      proxyIp: parseProxyIp(raw['Proxy IP']),
      // Sichtweite legt readNearby() in status() darueber; hier nur der
      // Platzhalter, damit die Form vollstaendig ist.
      nearby: null,
      ping: parsePing(raw['Ping']),
      health: parseHealth(raw['Health']),
      position: parseCoords(raw['Coordinates']),
      dimension: parseDimension(raw['Dimension']),
      queue: queue
        ? { ...queue, estimatedWaitSec: null }
        : hasPriority === false
          ? { priority: null, regular: null, position: null, estimatedWaitSec: null }
          : null,
      playtimeSec,
      source: 'webapi',
      // Der Link wird von withAuthUrl() in status() daruebergelegt; hier nur
      // der Platzhalter, damit die Form vollstaendig ist.
      authUrl: null,
      lastError: this.bootError,
      updatedAt: Date.now(),
    };
  }

  async command(cmd: string): Promise<CommandResult> {
    if (this.control !== 'webapi' || !this.client) {
      return {
        ok: false,
        output: '',
        error:
          'Web-API ist nicht verfuegbar, Befehle koennen nicht gesendet werden. ' +
          'Siehe Account-Log - vermutlich laeuft die Instanz ohne das Plugin.',
      };
    }
    try {
      const res = await this.client.command(cmd);
      return { ok: true, output: extractText(res) };
    } catch (err) {
      return { ok: false, output: '', error: (err as Error).message };
    }
  }

  /** Letzte Logzeilen fuer die Log-Ansicht im UI. */
  recentLog(n = 120): string[] {
    return this.tailer.recentLines(n);
  }

  async dispose(): Promise<void> {
    await this.stop().catch(() => {});
    this.tailer.close();
    this.logStream?.end();
    this.logStream = null;
  }
}

function waitForExit(proc: ChildProcess, timeoutMs: number): Promise<boolean> {
  if (proc.exitCode !== null) return Promise.resolve(true);
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      proc.off('exit', onExit);
      resolve(false);
    }, timeoutMs);
    function onExit() {
      clearTimeout(timer);
      resolve(true);
    }
    proc.once('exit', onExit);
  });
}
