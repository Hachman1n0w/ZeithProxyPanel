# AFK-Dashboard

Web-Dashboard, das Minecraft-Accounts auf einem Server online haelt - Java
ueber ZenithProxy, Bedrock ueber das RakNet-Protokoll. Ein Docker-Container,
LAN-Zugriff, kein TLS.

## Schnellstart

```bash
cp .env.example .env

# Pflicht: Verschluesselungsschluessel erzeugen und eintragen
sed -i "s/^ENCRYPTION_KEY=.*/ENCRYPTION_KEY=$(openssl rand -hex 32)/" .env

docker compose up -d --build
docker compose logs -f dashboard   # Passwort der Erstanmeldung steht hier
```

Dashboard dann auf `http://<server-ip>:3000`.

**Das Passwort der ersten Anmeldung wird beim allerersten Start einmalig ins
Log geschrieben** und nicht gespeichert. Wer es verliert, muss das Volume
leeren und neu anlegen:

```bash
docker compose down && docker volume rm afk-dashboard-data
```

## Aufbau

Ein Container beherbergt alles: Backend, Frontend, die ZenithProxy-Instanzen
als Kindprozesse und die Bedrock-Bots direkt im Node-Prozess.

Bewusst **kein** Container pro Account. Das waere nur ueber den
Docker-Daemon zu steuern - und noetigte, dem Web-Login den Docker-Socket zu
mounten. Ein Web-Login mit Socket-Zugriff ist praktisch root auf dem Host.

```
dashboard/
  server/         Fastify + SQLite (node:sqlite), Treiber, Supervisor
    src/drivers/  zenith.ts (Java), bedrock.ts (Bedrock)
    src/zenith/   WebAPI-Client, Status-Parser, Instanz-Verwaltung
    src/bedrock/  Auth-Kette, Movement-Ticker
  web/            React + Vite + Tailwind
  deploy/         fetch-assets.sh
  seed/           optionale Offline-Artefakte
```

## Die zwei Treiber

Beide erfuellen dieselbe Schnittstelle (`src/types.ts`). Das Dashboard kennt
den Unterschied nicht, ausser es zeigt ihn an.

### Java - ZenithProxy

Pro Account eine Instanz im eigenen Ordner mit eigenem `config.json` und
eigenen Ports. Steuerung laeuft ueber das **WebAPI-Plugin**:
`POST http://127.0.0.1:<port>/api/command` mit Header `Authorization: <token>`.

Drei Entscheidungen dahinter:

- **Channel `java` ist Pflicht**, nicht `linux`. Nur `java` unterstuetzt
  Plugins, und das WebAPI-Plugin ist ein Plugin. Kostet ~600 MB statt ~250 MB
  pro Instanz - bei fuenf Instanzen also rund 1,7 GB mehr. Ohne diesen Kanal
  waere der Account nicht steuerbar.
- **Port und Token liegen in `plugins/config/web-api.json`**, nicht in
  `config.json`. Das Plugin liest seine eigene Datei neben dem Jar und
  ignoriert die Sektion in `config.json` voellig - Port und Token dort zu
  setzen sieht aus wie Erfolg und bewirkt nichts. `readPluginConfig` bevorzugt
  darum die echte Datei und nutzt `config.json` nur noch als Rueckfall.
- **Zwei Ports pro Instanz**: einer fuer den MC-Server (25565-25569, damit du
  dich selbst einloggen kannst), einer fuer die Web-API (8081-8085).

#### Spieler, Zugriff, Module

Die Detailansicht eines Java-Accounts hat drei Bereiche oberhalb der Konsole:

- **Spieler in der Nähe** (`visualRange list` plus `tablist`). Die Karte zeigt
  die Anzahl und die ersten Namen schon ohne Klick.
- **Zugriff (Whitelist).** Drei Stufen, mehr kennt ZenithProxy nicht:
  Vollzugriff (steuern und zusehen), Zuschauer (nur zusehen), Blockiert.
  Ein Spieler steht immer auf hoechstens einer Liste.
- **Module.** Schalter fuer antiAFK, antiKick, antiLeak, Koordinaten-
  Verschleierung, autoEat, autoFish, autoTotem, autoMend, autoRespawn,
  autoReconnect, autoDisconnect, autoDrop, Zuschauer-Modus und
  Sichtweiten-Melder. Die Zustaende kommen live aus der Instanz, nicht aus der
  Datenbank. Feineinstellungen (`antiAFK walkDistance`, `autoEat hunger` ...)
  sowie autoArmor, stalk und autoReply laufen ueber die Konsole.

#### Anmeldung

ZenithProxy meldet sich selbst bei Microsoft an, das Dashboard reicht nur die
Befehle durch. Zwei Wege, waehlbar pro Konto:

- **Bestaetigungscode** (Standard, `authType: deviceCode`). ZenithProxy schreibt
  einen Microsoft-Geraetecode ins Log; das Dashboard faengt ihn ab und zeigt ihn
  als klickbaren Link an. Einmal bestaetigen, dann laeuft die Instanz ohne
  Eingriff. **Auf dem Server wird kein Passwort gespeichert.**
- **E-Mail und Passwort** (`authType: prism`). Vollautomatisch, aber das
  Passwort liegt verschluesselt in der Datenbank und Microsoft kann bei
  ungewoehnlichen Anmeldungen eine Mailbestaetigung verlangen. Deshalb nicht der
  Standard.

Beide Wege nutzen dieselbe ZenithProxy-Befehlsfolge: `auth type` ->
`auth email`/`auth password` -> `server <host> <port>` -> `connect`. Ohne diese
Folge startet eine Instanz sauber und steht dann nur herum - sie sieht intakt
aus und ist nutzlos. `antiAFK` wird bewusst nicht mitgeschaltet: Der Bot soll
stillstehen wie ein normaler Spieler. Wer es will, schaltet es im Modul-Menue
oder per `antiAFK on` in der Konsole ein.

Faellt die Web-API aus, faellt der Treiber auf **Log-Parsing** zurueck statt
den Account blind zu lassen. Der Status ist dann grober und im UI als
`aus Log geschaetzt` markiert. Welcher Weg aktiv ist, steht in
`AccountStatus.source` - ein still degradiertes Dashboard waere schlimmer als
ein sichtbares.

### Bedrock - RakNet

Laeuft direkt im Node-Prozess, keine Kindprozesse. Leichter (~150 MB) und ohne
Java, aber: faellt der Node-Prozess aus, sind alle Bedrock-Accounts weg. Der
Supervisor startet sie deshalb nach einem Neustart neu.

Zwei Punkte, die Aufmerksamkeit verdienen:

- **Die Auth-Kette kommt aus `bedrock-protocol`** (`prismarine-auth`:
  Device-Code, dann Live/XBL/XSTS/PlayFab). Wir bauen sie nicht selbst nach.
  Ueber `onMsaCode` faengt der Treiber genau den Device-Code ab, den das UI
  anzeigt. Das ist der Grund, warum der Bedrock-Teil machbar ist.
- **RakNet-Backend `jsp-raknet`**, nicht `raknet-native`. Letzteres ist ein
  C++-Modul und laesst sich im Image nicht zuverlaessig bauen. `jsp-raknet` ist
  reines JavaScript. Umschaltbar ueber `BEDROCK_RAKNET_BACKEND`.

Bedrock-Bots senden im Takt `player_auth_input`. Das ist bei Bedrock Pflicht -
anders als bei Java gibt es kein "einfach stillstehen", der Server erwartet
~20 Meldungen pro Sekunde. Die Feldnamen dieses Pakets haben sich zwischen den
Protokollversionen geaendert; wir senden beide Varianten und zeigen einen
Fehler im UI, statt ihn zu schlucken.

## Ports

| Port | Zweck | Veroeffentlicht |
|------|-------|----------------|
| 3000 | Dashboard | ja |
| 25565-25569 | ZenithProxy-MC-Server | optional, auskommentiert |
| 8081-8085 | ZenithProxy-Web-API | **nein** |

Die Web-API-Ports bleiben bewusst im Container. Ihr Token ist ein
Vollzugriffs-Token auf die Instanz; das Backend greift intern ueber Loopback
darauf zu. Wer sie nach aussen mapped, gibt die Kontrolle weg.

Sich selbst einloggen (z.B. um einen Account zu besetzen, ohne ihn zu stoppen):
in `docker-compose.yml` die Zeile `'25565-25569:25565-25569'` aktivieren.

## Offline-Betrieb

Launcher und Plugin werden beim ersten Start aus dem Internet geholt. Ohne
Internetzugang vorher einmalig:

```bash
./deploy/fetch-assets.sh     # legt seed/launcher.zip und seed/web-api.jar an
docker compose up -d --build  # COPY seed/ baut sie ins Image
```

Liegt eine der Dateien in `/app/seed`, wird sie benutzt und **nichts** mehr
heruntergeladen. Seed gewinnt immer vor dem Download.

## Konfiguration

Alle Variablen sind in `.env.example` kommentiert. Die wichtigsten:

| Variable | Standard | Bedeutung |
|----------|----------|-----------|
| `ENCRYPTION_KEY` | - | **Pflicht.** Verschluesselt gespeicherte Login-Secrets |
| `ZENITH_MC_VERSION` | `1.21.4` | Minecraft-Version der Instanzen |
| `ZENITH_PLATFORM` | `java` | Nur `java` ist steuerbar |
| `BEDROCK_RAKNET_BACKEND` | `jsp-raknet` | RakNet-Implementierung |
| `STATUS_POLL_MS` | `60000` | Statusabruf pro Instanz |
| `SEED_DIR` | `/app/seed` | Offline-Artefakte |

`STATUS_POLL_MS` sollte nicht kleiner als ~2000 sein: das WebAPI erlaubt
30 Requests pro Minute pro Instanz, der Treiber hält sich mit einem
Token-Bucket daran.

## Bekannte Eigenheiten

- **Die Warteschlangenposition ist eine Naeherung.** ZenithProxy gibt in
  `status` nur die Anzahlen (`Priority: 15`, `Regular: 688`) aus, nicht die
  eigene Position. Angezeigt wird der hoehere Wert. Wer es genau braucht,
  nutzt den Befehl `queueStatus` in der Detailansicht.
- **Ein Prozess pro Instanz, und ZenithProxy ist zwei Prozesse.** Das
  `./launch`-Skript startet eine JVM darunter. Beendet man nur den direkten
  Kindprozess, laeuft die JVM weiter, haelt MC- und WebAPI-Port und die
  `.lock`, und jeder weitere Start bricht mit `Multiple ZenithProxy Instances
  Open` ab - was wie ein Startfehler aussieht und keiner ist. Deshalb bekommen
  Instanzen eine eigene Prozessgruppe und werden gruppenweise beendet;
  `zenith/procs.ts` raeumt auf, was nach einem harten Abbruch uebrig bleibt.
- **Ausschalten heisst ausschalten.** Deaktivierte Accounts werden vom
  Watchdog uebersprungen. Sonst startet der Auto-Reconnect sie wieder, und im
  Dashboard war das Abschalten nur fuer einen Watchdog-Takt (30 s) wirksam.
- **Kein TLS.** Das Dashboard ist fuers LAN gedacht. Session-Cookie ist
  `httpOnly` + `SameSite=Lax`; `secure` ist bewusst aus, solange kein HTTPS
  davorsteht.
- **Die Web-API bricht Antworten manchmal ab.** Verifiziert: `whitelist list`
  kommt gelegentlich als blosses `"\nWhitelist List"` mit HTTP 200 zurueck,
  obwohl die Liste existiert. Die Zugriffs- und Spieler-Endpunkte pruefen
  darum die Vollstaendigkeit (Konfigurationsanhang dabei?) und versuchen es
  erneut, statt eine halbe Antwort als leer zu verkaufen.
- **Modulzustaende werden 60 s zwischengespeichert.** Ein Abruf kostet 14 von
  30 Befehlen pro Minute - ohne Cache wuerde jedes Oeffnen des Menues das
  Budget belegen und Status und Whitelist verhungern lassen. Gleichzeitige
  Abrufe teilen sich einen laufenden, nach 25 s kommt zurueck, was da ist,
  und ein geschlossener Tab bricht die Arbeit ab statt unsichtbar weiter
  Befehle zu verbrennen.
- **Die Blacklist ist nur schreibbar.** Weder `whitelist blacklist list` noch
  der nackte Befehl geben sie her - beide antworten mit der Whitelist.
  Blockieren und Entblocken geht, Anzeigen nicht.
- **Spielernamen werden ueber Mojang aufgeloest.** `whitelist add` mit einem
  Tippfehler oder Fantasienamen scheitert mit `Failed to add user ... Unable
  to lookup profile`. Der Endpunkt reicht die Zeile als Fehler durch, statt
  Erfolg zu melden.
- **`spectator whitelist` braucht Owner-Rechte in der Web-API.** Ohne
  `commandsAccountOwnerPerms: true` in `plugins/config/web-api.json` antwortet
  das Plugin mit `Not Authorized`. `writePluginConfig` setzt das Flag; es
  greift ab dem naechsten Instanzstart.

## Betrieb ohne Docker (auf dem Rechner selbst)

Zum Ausprobieren auf dem Entwicklungsrechner, ohne Docker:

```bash
./run-local.sh build     # einmalig Server + Frontend bauen
./run-local.sh start     # im Hintergrund starten
./run-local.sh logs      # Logverlauf mitverfolgen
./run-local.sh stop
./run-local.sh password # Erstpasswort nochmal anzeigen
```

Das Skript liest `.env` selbst ein, legt `DATA_DIR`, `SEED_DIR` und
`ENCRYPTION_KEY` auf lokale Verzeichnisse um und schreibt PID sowie Log nach
`.run/`.

**Java-Instanzen brauchen ein JDK auf dem PATH.** ZenithProxy startet sonst
nicht, das Dashboard selbst laeuft auch ohne. Zwei Wege:

```bash
sudo pacman -S jre21-openjdk-headless      # global, dann ist nichts zu tun
```

oder ein JDK an anderer Stelle in der `.env` eintragen:

```
JAVA_HOME_DIR=/home/DEIN-NAME/.jdks/jdk-21
```

## Entwicklung

```bash
# Backend
cd server && pnpm install && pnpm run dev    # Port 3000

# Frontend (parallel, mit Proxy auf 3000)
cd web && pnpm install && pnpm run dev      # Port 5173
```

pnpm 11 liest seine Einstellungen aus `pnpm-workspace.yaml`, nicht mehr aus dem
`pnpm`-Feld der `package.json`. Dort steht auch, warum
`blockExoticSubdeps: false` noetig ist (`bedrock-protocol` zieht eine
Git-Abhaengigkeit) und welche drei Pakete Build-Skripte brauchen.

SQLite laeuft ueber das eingebaute `node:sqlite` statt `better-sqlite3` -
letzteres ist eine native Abhaengigkeit mit Compiler-Bedarf und im Image eine
zusaetzliche Fehlerquelle.

## Hinweise zur Nutzung

- Automatisierung von Minecraft-Accounts verstoesst gegen die Mojang-EULA.
  Automatisierte Accounts koennen gesperrt werden.
- 2b2t begrenzt die Anzahl der Accounts pro IP. Zehn Accounts von einer IP
  sind auffaellig.
- Der Bedrock-Login haengt an Microsofts OAuth-Kette. Aendert Microsoft etwas
  daran, muss der Token neu geholt werden - dafuer gibt es "Neu anmelden" in
  der Detailansicht.
